//
//  Checkout.h
//  AllParkTickets
//
//  Created by Admin on 7/5/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
@interface Checkout : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong) NSManagedObject *device;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (weak, nonatomic) IBOutlet UITableView *tableVieww;

@property (weak, nonatomic) IBOutlet UILabel *countlbl;
@property (weak, nonatomic) IBOutlet UIView *cartView;
@property (weak, nonatomic) IBOutlet UILabel *shippinglbl;
@property (weak, nonatomic) IBOutlet UILabel *totalcountlbl;


@end
