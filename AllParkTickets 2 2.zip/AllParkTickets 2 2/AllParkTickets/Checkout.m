//
//  Checkout.m
//  AllParkTickets
//
//  Created by Admin on 7/5/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "Checkout.h"
#import "AppDelegate.h"
#import "CheckoutCell.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "FirstView.h"
#import "Common.h"
#import "LoginView.h"
#import "MBProgressHUD.h"
#import "NSString+HTML.h"
#import "JSON.h"

@interface Checkout ()<MBProgressHUDDelegate>
{
    AppDelegate *appdelegate;
    NSMutableArray *ChannelDBArray;
    NSArray *image;
     NSArray *tittle;
     NSArray *price;
    NSArray *childs;
    NSArray *adults;
    NSArray *results;
    NSDictionary *dictionary;
    NSArray *basePrice;
    NSString *carcount;
     NSArray *childprice;
      NSArray *adultprice;
     NSString *adultsnum;
    NSString *childsnum;
    NSString *user_id;
      NSString *pricccc;
     int countt;
    NSArray *item_id;
        MBProgressHUD *HUD;
    NSArray *response;
    NSDictionary *dict2;
    NSString *addData ;
    NSString *priccc;
}
@property(nonatomic,strong)IBOutlet MyImageView *image1;
@end

@implementation Checkout

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];

   user_id = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"user_id"];
    [self get_fetchthedatails];
       // Do any additional setup after loading the view.
}


-(void)get_fetchthedatails
{
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSManagedObjectContext *context =[delegate managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
    
    NSError *error = nil;
    results = [context executeFetchRequest:request error:&error];
    
    
    
    ChannelDBArray=[[NSMutableArray alloc]init];
    
    for (NSManagedObject *obj in results) {
        
        
        NSArray *keys = [[[obj entity] attributesByName] allKeys];
        dictionary = [obj dictionaryWithValuesForKeys:keys];
        NSLog(@"dictionary %@",dictionary);
        
        //  NSArray *arrasy =[dictionary valueForKey:@"project_name"];
        [ChannelDBArray addObject:dictionary];
    }
    if (error != nil) {
        
        //Deal with failure
    }
    else {
        
        
        image =[ChannelDBArray valueForKey:@"image"];
        tittle =[ChannelDBArray valueForKey:@"tittle"];
        childs =[ChannelDBArray valueForKey:@"child"];
        adults =[ChannelDBArray valueForKey:@"adult"];
        price =[ChannelDBArray valueForKey:@"price"];
        item_id =[ChannelDBArray valueForKey:@"id"];
        adultprice =[ChannelDBArray valueForKey:@"adultprice"];
        
        childprice =[ChannelDBArray valueForKey:@"childPrice"];
        
        NSLog(@"item_id %@",item_id);
        
        NSMutableArray *rr =[[NSMutableArray alloc]init];
        NSMutableArray *outputArray=[NSMutableArray new];
        int i;
        for (i = 0; i < [price count]; i++) {
            
            NSArray *dd ;
            
            dd =[price objectAtIndex:i];
            NSString *ddd =[NSString stringWithFormat:@"%@",dd];
            NSArray *gf =[ddd componentsSeparatedByString:@"$"];
            
            NSString *ddff =[gf objectAtIndex:1];
            [outputArray addObject:ddff];
       
                }
    
        
                            
        NSInteger sum = 0;
        for (NSNumber *num in outputArray) {
            sum += [num intValue];
        }
        
        _totalcountlbl.text =[NSString stringWithFormat:@"$%ld",(long)sum];
        _countlbl.text =[NSString stringWithFormat:@"$%ld",(long)sum];

        basePrice =[ChannelDBArray valueForKey:@"basefee"];
        // _Pricelbl.text
        
        NSLog(@"images %@",image);
        NSLog(@"tittle %@",tittle);
        NSLog(@"childs %@",childs);
        NSLog(@"adults %@",adults);
        NSLog(@"price %@",price);
          NSLog(@"adultprice %@",adultprice);
          NSLog(@"childprice %@",childprice);
     
        NSLog(@"Baseprice %@",basePrice);
        
        
        
        
        if (image.count==0) {
            _cartView.hidden =NO;
            _tableVieww.hidden =YES;
        }
        else{
            
            _cartView.hidden =YES;
            _tableVieww.hidden =NO;
        }
        
        
        [self.tableVieww reloadData];
        //self->_tableViewList.hidden = NO;
        // [self.tableViewList reloadData];
        // NSLog(@"dictionary %@",dictionary);
        //Deal with success
    }
    
    
    

    
    
}

-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)cart_emty:(id)sender{
    
    FirstView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"FirstView"];
    [self.navigationController pushViewController:controller animated:YES];
}


-(IBAction)checkout_button:(id)sender{
  
    
    
    if (user_id == nil || [user_id isKindOfClass:[NSNull class]]) {
        [Common AlertShowWithErrorMsg:@"Please Login"];
        
        LoginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginView"];
        [self.navigationController pushViewController:controller animated:YES];

            }
    else{
        
        
        if ([_totalcountlbl.text isEqualToString:@"$0"]) {
            [Common AlertShowWithErrorMsg:@"Sorry Your cart is emty ,Please Select from list of tourse"];
            
            FirstView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"FirstView"];
            [self.navigationController pushViewController:controller animated:YES];

        }else{
        
       
            [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"CarCount"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        
        AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        NSManagedObjectContext *context =[delegate managedObjectContext];
        
        
        
        NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
        
        NSError *error = nil;
        results = [context executeFetchRequest:request error:&error];
        
        ;
        //error handling goes here
        for (NSManagedObject *car in results) {
            [context deleteObject:car];
        }
        NSError *saveError = nil;
        [context save:&saveError];
        
          [HUD show:YES];
           
            childs =[ChannelDBArray valueForKey:@"child"];
            adults =[ChannelDBArray valueForKey:@"adult"];
            price =[ChannelDBArray valueForKey:@"price"];
            
            NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"dd/MM/yyyy"];
            // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
            NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
            
            
            NSMutableArray *arrays =[[NSMutableArray alloc]init];
            
            
            
            for (countt = 0; countt < [item_id count]; countt++) {
                NSString *item =[item_id objectAtIndex:countt];
                 NSString *adult =[adults objectAtIndex:countt];
                 NSString *child =[childs objectAtIndex:countt];
                  NSString *date =[NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
                priccc =[price objectAtIndex:countt];
              //  NSString *sd =[NSString stringWithFormat:@"%@",child];
                
            
                addData =[NSString stringWithFormat:@"%@,%@,%@,%@",item,adult,child,date];;
                NSString *ddf;
                
                
                               //[arrays addObject:ddf];
                [self web_servicesCalling];
                
                           }
            
            
        
        FirstView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"FirstView"];
        [self.navigationController pushViewController:controller animated:YES];
  [Common AlertShowWithErrorMsg:@"Thankyou for Requests your Orders, we will contact to you soon"];
        
        }
        
        
       }
    
}

-(void)web_servicesCalling
{
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/order_details.php?cust_id=%@&net_amount=%@&products=%@",user_id,priccc,addData];
        
    
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response = [dict2 valueForKey:@"response"];
            
            NSLog(@"main response %@",response);
            
                       
            [HUD hide:YES];
        });
    });

    
    
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 150;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [image  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"CheckoutCell";
    
    
    
    
    CheckoutCell  *cell = (CheckoutCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[CheckoutCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CheckoutCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
     cell.tiitlelbl.text =[tittle objectAtIndex:indexPath.row];
    
        cell.childlbl.text =[childs objectAtIndex:indexPath.row];
    
    childsnum =[NSString stringWithFormat:@"%@",cell.childlbl.text];
      cell.adultbl.text =[adults objectAtIndex:indexPath.row];
     adultsnum =[NSString stringWithFormat:@"%@",cell.adultbl.text];
    // NSString *childsnum;
      cell.pricelbl.text =[price objectAtIndex:indexPath.row];
    
    
    pricccc =[NSString stringWithFormat:@"%@",cell.pricelbl.text];
    _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[image objectAtIndex:indexPath.row];
    
    cell.increasebutton.tag = indexPath.row;
    [cell.increasebutton addTarget:self action:@selector(increase:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.increasebutton_child.tag = indexPath.row;
    [cell.increasebutton_child addTarget:self action:@selector(increase_child:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    cell.decreasebutton.tag = indexPath.row;
    [cell.decreasebutton addTarget:self action:@selector(decrease:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.deletecart.tag = indexPath.row;
    [cell.deletecart addTarget:self action:@selector(delete:) forControlEvents:UIControlEventTouchUpInside];

    
    cell.decreasechild.tag = indexPath.row;
    [cell.decreasechild addTarget:self action:@selector(decreasechild:) forControlEvents:UIControlEventTouchUpInside];
    


    // NSLog(@"path %@",path);
    
    [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];

    return cell;

}


-(void)delete:(id)sender

{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableVieww];
    NSIndexPath *indexPath = [self.tableVieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);

    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSManagedObjectContext *context =[delegate managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
    
    NSError *error = nil;
    results = [context executeFetchRequest:request error:&error];
    ;
    //error handling goes here
    for (NSManagedObject *car in results) {
        [context deleteObject:car];
    }
    NSError *saveError = nil;
    [context save:&saveError];
    
   
    
    childs =[ChannelDBArray valueForKey:@"child"];

    
    
    NSManagedObject *objectToBeDeleted =
    [results objectAtIndex:indexPath.row];
    
    [context deleteObject:objectToBeDeleted];
    
    if (![context save:&error])
    {
        NSLog(@"Error deleting movie, %@", [error userInfo]);
    }
    
    
    
    carcount = [[NSUserDefaults standardUserDefaults]
                stringForKey:@"CarCount"];
    
    
    int carcou =[carcount intValue];
    
    
    int increase ;
    increase =(int)image.count-1;
    
    NSString *decrease;
    decrease =[NSString stringWithFormat:@"%lu",(unsigned long)childs.count];
    
    
    
    // NSString *valueToSave = @"someValue";
    [[NSUserDefaults standardUserDefaults] setObject:decrease forKey:@"CarCount"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    
    [self get_fetchthedatails];
    
}

-(void)increase:(id)sender

{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableVieww];
    NSIndexPath *indexPath = [self.tableVieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);
    
    NSString *basepr =[adultprice objectAtIndex:indexPath.row];
    
    
    NSArray *gr =[basepr componentsSeparatedByString:@"$"];
    
    NSString *ddd =[gr objectAtIndex:1];

    
      NSString *Childd =[adults objectAtIndex:indexPath.row];
    
    
    int chiin =[Childd intValue];
    
    
    float basefloat =[basepr floatValue];
    
    int ch =chiin+1;
    
        
      
        

    
    NSString *child_increase =[NSString stringWithFormat: @"%d",ch];
    
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSManagedObjectContext *context =[delegate managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
    
    NSError *error = nil;

      results = [context executeFetchRequest:request error:&error];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"adult == %@",child_increase];
    [request setPredicate:predicate];
    
    
    
    NSManagedObject* favoritsGrabbed = [results objectAtIndex:indexPath.row];
    [favoritsGrabbed setValue:child_increase
                       forKey:@"adult"];
    
    
    
    
    
   
    
    int totalchild =[adultsnum intValue];
    
    
    float adulsprice =[ddd floatValue];
    
    int increse =totalchild+1;
    
    float totalcost =1*adulsprice;
    
    NSString *totaladults =[NSString stringWithFormat:@"%f",totalcost];
    
 
    
    
    NSString *bestprice =[price objectAtIndex:indexPath.row];
    
    
    
    
    NSArray *gr1 =[bestprice componentsSeparatedByString:@"$"];
    
    NSString *ddd1 =[gr1 objectAtIndex:1];
    
    int actualprice1 =[ddd1 intValue];
    
    
    int tot =totalcost+actualprice1;
    
    NSString *dd =[NSString stringWithFormat:@"$%0.2d",tot];
    
        NSString *ss;
        NSString *ddd1d;
        NSString *ss1;
        NSString *ddd11;
        
        
        ss =[[ChannelDBArray valueForKey:@"child"]objectAtIndex:indexPath.row];
        ddd1d =[[ChannelDBArray valueForKey:@"adult"]objectAtIndex:indexPath.row];
        
        
        
        
        ss1 =[[ChannelDBArray valueForKey:@"adultprice"]objectAtIndex:indexPath.row];
        
        
        NSArray *gr12 =[ss1 componentsSeparatedByString:@"$"];
        
        NSString *ddd12 =[gr12 objectAtIndex:1];
        
        ddd11 =[[ChannelDBArray valueForKey:@"childPrice"]objectAtIndex:indexPath.row];;
        
        
        
        NSArray *gr121 =[ddd11 componentsSeparatedByString:@"$"];
        
        NSString *ddd121 =[gr121 objectAtIndex:1];


        
        
        int childrr =[ss intValue];
        int childrr1 =[ddd1d intValue];

        int childrr11 =[ddd12 intValue];

        int childrr12 =[ddd121 intValue];

        
        
        int child =childrr1+1;
        
        int tto =childrr11*child;
        int tto1 =childrr*childrr12;

        
        
        int ffd =tto+tto1;
        
        NSString *dddf =[NSString stringWithFormat:@"$%d",ffd];
    
    NSManagedObject* favoritsGrabbed1 = [results objectAtIndex:indexPath.row];
    [favoritsGrabbed1 setValue:dddf
                        forKey:@"price"];

    
    
    
    
    if (![context save:&error])
    {
        NSLog(@"Error deleting movie, %@", [error userInfo]);
    }
    
    
    float total =ch*basefloat;
    
    NSLog(@"total %f",total);
    
   // basePrice
    
    
    [self get_fetchthedatails];
    



}

-(void)increase_child:(id)sender

{
    
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableVieww];
    NSIndexPath *indexPath = [self.tableVieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);
    
    NSString *basepr =[childprice objectAtIndex:indexPath.row];
    
    
    NSArray *gr =[basepr componentsSeparatedByString:@"$"];
    
    NSString *ddd =[gr objectAtIndex:1];
    
    
    NSString *Childd =[childs objectAtIndex:indexPath.row];
    
    
    int chiin =[Childd intValue];
    
    
    float basefloat =[basepr floatValue];
    
    int ch =chiin+1;
    
    
    
    NSString *child_increase =[NSString stringWithFormat: @"%d",ch];
    
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSManagedObjectContext *context =[delegate managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
    
    NSError *error = nil;
    
    results = [context executeFetchRequest:request error:&error];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"adult == %@",child_increase];
    [request setPredicate:predicate];
    
    
    
    NSManagedObject* favoritsGrabbed = [results objectAtIndex:indexPath.row];
    [favoritsGrabbed setValue:child_increase
                       forKey:@"child"];
    
    
    
    
    
    
    
    int totalchild =[childsnum intValue];
    
    
    float adulsprice =[ddd floatValue];
    
    int increse =totalchild+1;
    
    float totalcost =1*adulsprice;
    
    NSString *totaladults =[NSString stringWithFormat:@"%f",totalcost];
    
    
    
    
    NSString *bestprice =[price objectAtIndex:indexPath.row];
    
    
    
    
    NSArray *gr1 =[bestprice componentsSeparatedByString:@"$"];
    
    NSString *ddd1 =[gr1 objectAtIndex:1];
    
    int actualprice1 =[ddd1 intValue];
    
    
    int tot =totalcost+actualprice1;
    
    NSString *dd =[NSString stringWithFormat:@"$%0.2d",tot];
    
        NSString *ss;
        NSString *ddd1d;
        NSString *ss1;
        NSString *ddd11;
        
        
        ss =[[ChannelDBArray valueForKey:@"child"]objectAtIndex:indexPath.row];
        ddd1d =[[ChannelDBArray valueForKey:@"adult"]objectAtIndex:indexPath.row];
        
        
        
        
        ss1 =[[ChannelDBArray valueForKey:@"adultprice"]objectAtIndex:indexPath.row];
        
        
        NSArray *gr12 =[ss1 componentsSeparatedByString:@"$"];
        
        NSString *ddd12 =[gr12 objectAtIndex:1];
        
        ddd11 =[[ChannelDBArray valueForKey:@"childPrice"]objectAtIndex:indexPath.row];;
        
        
        
        NSArray *gr121 =[ddd11 componentsSeparatedByString:@"$"];
        
        NSString *ddd121 =[gr121 objectAtIndex:1];
        
        
        
        
        int childrr =[ss intValue];
        int childrr1 =[ddd1d intValue];
        
        int childrr11 =[ddd12 intValue];
        
        int childrr12 =[ddd121 intValue];
        
        
        
        int child =childrr1+1;
        
        int tto =childrr11*child;
        int tto1 =childrr*childrr12;
        
        
        
        int ffd =tto+tto1;
        
        NSString *dddf =[NSString stringWithFormat:@"$%d",ffd];
        
        NSManagedObject* favoritsGrabbed1 = [results objectAtIndex:indexPath.row];
        [favoritsGrabbed1 setValue:dddf
                            forKey:@"price"];
        
    
    
    
    if (![context save:&error])
    {
        NSLog(@"Error deleting movie, %@", [error userInfo]);
    }
    
    
    float total =ch*basefloat;
    
    NSLog(@"total %f",total);
    
    // basePrice
    
    
    [self get_fetchthedatails];
    
}










-(void)decreasechild:(id)sender

{
    
    
    if ([childsnum isEqualToString:@"0"]) {
        
        
    }
    else{
        
        CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableVieww];
        NSIndexPath *indexPath = [self.tableVieww indexPathForRowAtPoint:buttonPosition];
        NSLog(@"indexpath %ld",(long)indexPath.row);
        
        NSString *basepr =[adultprice objectAtIndex:indexPath.row];
        
        
        NSArray *gr =[basepr componentsSeparatedByString:@"$"];
        
        NSString *ddd =[gr objectAtIndex:1];
        
        
        NSString *Childd =[childs objectAtIndex:indexPath.row];
        
        
        int chiin =[Childd intValue];
        
        
        float basefloat =[basepr floatValue];
        
        int ch =chiin-1;
        
        
        
        NSString *child_increase =[NSString stringWithFormat: @"%d",ch];
        
        
        AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        NSManagedObjectContext *context =[delegate managedObjectContext];
        
        
        
        NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
        
        NSError *error = nil;
        
        results = [context executeFetchRequest:request error:&error];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"adult == %@",child_increase];
        [request setPredicate:predicate];
        
        
        
        NSManagedObject* favoritsGrabbed = [results objectAtIndex:indexPath.row];
        [favoritsGrabbed setValue:child_increase
                           forKey:@"child"];
        
        
        
        
        
        
        
        int totalchild =[childsnum intValue];
        
        
        float adulsprice =[ddd floatValue];
        
        int increse =totalchild-1;
        
        float totalcost =1*adulsprice;
        
        NSString *totaladults =[NSString stringWithFormat:@"%f",totalcost];
        
        
        
        
        NSString *bestprice =[price objectAtIndex:indexPath.row];
        
        
        
        
        NSArray *gr1 =[bestprice componentsSeparatedByString:@"$"];
        
        NSString *ddd1 =[gr1 objectAtIndex:1];
        
        int actualprice1 =[ddd1 intValue];
        
        
        int tot =totalcost-actualprice1;
        
        NSString *dd =[NSString stringWithFormat:@"$%0.2d",tot];
        
        
        NSString *ss;
        NSString *ddd1d;
        NSString *ss1;
        NSString *ddd11;
        
        
        ss =[[ChannelDBArray valueForKey:@"child"]objectAtIndex:indexPath.row];
        ddd1d =[[ChannelDBArray valueForKey:@"adult"]objectAtIndex:indexPath.row];
        
        
        
        
        ss1 =[[ChannelDBArray valueForKey:@"adultprice"]objectAtIndex:indexPath.row];
        
        
        NSArray *gr12 =[ss1 componentsSeparatedByString:@"$"];
        
        NSString *ddd12 =[gr12 objectAtIndex:1];
        
        ddd11 =[[ChannelDBArray valueForKey:@"childPrice"]objectAtIndex:indexPath.row];;
        
        
        
        NSArray *gr121 =[ddd11 componentsSeparatedByString:@"$"];
        
        NSString *ddd121 =[gr121 objectAtIndex:1];
        
        
        
        
        int childrr =[ss intValue];
        int childrr1 =[ddd1d intValue];
        
        int childrr11 =[ddd12 intValue];
        
        int childrr12 =[ddd121 intValue];
        
        
        
        int child =childrr-1;
        
        int tto =childrr11*childrr12;
        int tto1 =childrr1*childrr11;
        
        
        
        int ffd =tto-tto1;
        
        NSString *dddf =[NSString stringWithFormat:@"$%d",ffd];
        
        NSManagedObject* favoritsGrabbed1 = [results objectAtIndex:indexPath.row];
        [favoritsGrabbed1 setValue:dddf
                            forKey:@"price"];
        
        
        
        
        
        if (![context save:&error])
        {
            NSLog(@"Error deleting movie, %@", [error userInfo]);
        }
        
        
        float total =ch*basefloat;
        
        NSLog(@"total %f",total);
        
        // basePrice
        
        
        [self get_fetchthedatails];
        
    }
    
}



-(void)decrease:(id)sender

{
    
    
    if ([adultsnum isEqualToString:@"0"]) {
        
        
    }
    else{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableVieww];
    NSIndexPath *indexPath = [self.tableVieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);
    
    NSString *basepr =[adultprice objectAtIndex:indexPath.row];
    
    
    NSArray *gr =[basepr componentsSeparatedByString:@"$"];
    
    NSString *ddd =[gr objectAtIndex:1];
    
    
    NSString *Childd =[adults objectAtIndex:indexPath.row];
    
    
    int chiin =[Childd intValue];
    
    
    float basefloat =[basepr floatValue];
    
    int ch =chiin-1;
    
    
    
    NSString *child_increase =[NSString stringWithFormat: @"%d",ch];
    
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSManagedObjectContext *context =[delegate managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
    
    NSError *error = nil;
    
    results = [context executeFetchRequest:request error:&error];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"adult == %@",child_increase];
    [request setPredicate:predicate];
    
    
    
    NSManagedObject* favoritsGrabbed = [results objectAtIndex:indexPath.row];
    [favoritsGrabbed setValue:child_increase
                       forKey:@"adult"];
    
    
    
    
    
    
    
    int totalchild =[adultsnum intValue];
    
    
    float adulsprice =[ddd floatValue];
    
    int increse =totalchild-1;
    
    float totalcost =1*adulsprice;
    
    NSString *totaladults =[NSString stringWithFormat:@"%f",totalcost];
    
    
    
    
    NSString *bestprice =[price objectAtIndex:indexPath.row];
    
    
    
    
    NSArray *gr1 =[bestprice componentsSeparatedByString:@"$"];
    
    NSString *ddd1 =[gr1 objectAtIndex:1];
    
    int actualprice1 =[ddd1 intValue];
    
    
    int tot =totalcost-actualprice1;
    
    NSString *dd =[NSString stringWithFormat:@"$%0.2d",tot];
    
    
        NSString *ss;
        NSString *ddd1d;
        NSString *ss1;
        NSString *ddd11;
        
        
        ss =[[ChannelDBArray valueForKey:@"child"]objectAtIndex:indexPath.row];
        ddd1d =[[ChannelDBArray valueForKey:@"adult"]objectAtIndex:indexPath.row];
        
        
        
        
        ss1 =[[ChannelDBArray valueForKey:@"adultprice"]objectAtIndex:indexPath.row];
        
        
        NSArray *gr12 =[ss1 componentsSeparatedByString:@"$"];
        
        NSString *ddd12 =[gr12 objectAtIndex:1];
        
        ddd11 =[[ChannelDBArray valueForKey:@"childPrice"]objectAtIndex:indexPath.row];;
        
        
        
        NSArray *gr121 =[ddd11 componentsSeparatedByString:@"$"];
        
        NSString *ddd121 =[gr121 objectAtIndex:1];
        
        
        
        
        int childrr =[ss intValue];
        int childrr1 =[ddd1d intValue];
        
        int childrr11 =[ddd12 intValue];
        
        int childrr12 =[ddd121 intValue];
        
        
        
        int child =childrr-1;
        
        int tto =childrr11*child;
        int tto1 =childrr1*childrr12;
        
        
        
        int ffd =tto+tto1;
        
        NSString *dddf =[NSString stringWithFormat:@"$%d",ffd];
        
        NSManagedObject* favoritsGrabbed1 = [results objectAtIndex:indexPath.row];
        [favoritsGrabbed1 setValue:dddf
                            forKey:@"price"];
        
    
    
    
    
    if (![context save:&error])
    {
        NSLog(@"Error deleting movie, %@", [error userInfo]);
    }
    
    
    float total =ch*basefloat;
    
    NSLog(@"total %f",total);
    
    // basePrice
    
    
    [self get_fetchthedatails];
    
}

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
   
   }
    
    
    
- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            
            NSLog(@"Saving didn't work so well.. Error: %@, %@", error, [error userInfo]);
            abort();
        }
    }
}
  
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
