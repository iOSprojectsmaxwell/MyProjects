//
//  CheckoutCell.h
//  AllParkTickets
//
//  Created by Admin on 7/5/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

@interface CheckoutCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *tiitlelbl;
@property (weak, nonatomic) IBOutlet UILabel *pricelbl;
@property (weak, nonatomic) IBOutlet UILabel *childlbl;
@property (weak, nonatomic) IBOutlet UILabel *adultbl;
@property (weak, nonatomic) IBOutlet MyImageView *imageVieew;
@property (weak, nonatomic) IBOutlet UIButton *increasebutton;
@property (weak, nonatomic) IBOutlet UIButton *decreasebutton;
@property (weak, nonatomic) IBOutlet UIButton *increasebutton_child;
@property (weak, nonatomic) IBOutlet UIButton *deletecart;
@property (weak, nonatomic) IBOutlet UIButton *decreasechild;
@end
