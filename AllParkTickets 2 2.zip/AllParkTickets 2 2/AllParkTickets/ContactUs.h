//
//  ContactUs.h
//  AllParkTickets
//
//  Created by Admin on 7/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactUs : UIViewController
@property(nonatomic,strong)IBOutlet UIScrollView *scrollview;
@property(nonatomic,strong)IBOutlet UITextField *fullnamefeild;
@property(nonatomic,strong)IBOutlet UITextField *lastnamefeild;
@property(nonatomic,strong)IBOutlet UITextField *emailidfeild;
@property(nonatomic,strong)IBOutlet UITextField *phonenofeild;
@property(nonatomic,strong)IBOutlet UITextView *textviewfeild;

@end
