//
//  ContactUs.m
//  AllParkTickets
//
//  Created by Admin on 7/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ContactUs.h"
#import "SidemenuView.h"
#import "Common.h"
#import "MBProgressHUD.h"
#import "JSON.h"

@interface ContactUs ()<UIScrollViewDelegate,MBProgressHUDDelegate>
{
    SidemenuView *objSideMenuView;
      MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *response;
}

@end

@implementation ContactUs

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _textviewfeild.text = @"Comment";
    _textviewfeild.textColor = [UIColor lightGrayColor];
    _textviewfeild.delegate = self;
    
    CALayer *imageLayer = _textviewfeild.layer;
    [imageLayer setCornerRadius:10];
    [imageLayer setBorderWidth:1];
    imageLayer.borderColor=[[UIColor blackColor] CGColor];
    // Do any additional setup after loading the view.
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    _textviewfeild.text = @"";
    _textviewfeild.textColor = [UIColor blackColor];
    return YES;
}

-(void) textViewDidChange:(UITextView *)textView
{
    
    if(_textviewfeild.text.length == 0){
        _textviewfeild.textColor = [UIColor lightGrayColor];
        _textviewfeild.text = @"Comment";
        [_textviewfeild resignFirstResponder];
    }
}

-(void) textViewShouldEndEditing:(UITextView *)textView
{
    
    if(_textviewfeild.text.length == 0){
        _textviewfeild.textColor = [UIColor lightGrayColor];
        _textviewfeild.text = @"Comment";
        [_textviewfeild resignFirstResponder];
    }
}
-(IBAction)selected:(id)sender{
    
    if (_fullnamefeild.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your Full name"];
    }
    else if (_lastnamefeild.text.length ==0)
    {
      [Common AlertShowWithErrorMsg:@"Please enter your Last name"];
    }
    else if (_emailidfeild.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter your Emailid"];
    }
    else if (_phonenofeild.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter your Phone number"];
    }
    else if (_textviewfeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter your comment"];
    }

    else{
        
        [HUD show:YES];
        [self Get_Details];
    }
}

-(void)Get_Details
{
    
    
   
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"https://www.allparktickets.com/api/contactus.php?f_name=%@&l_name=%@&email=%@&phone=%@&comment=%@",_fullnamefeild.text,_lastnamefeild.text,_emailidfeild.text,_phonenofeild.text,_textviewfeild.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response = [dict2 valueForKey:@"response"];
            
            NSLog(@"main response %@",response);
            
            [Common AlertShowWithErrorMsg:@"Thankyou for your contact me we will contact to you soon!"];
            
            [HUD hide:YES];
        });
    });
    

    
    
}
-(void) viewDidLayoutSubviews
{
    _scrollview.contentSize = CGSizeMake(_scrollview.frame.size.width, 1000);
}
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
