//
//  ContactUsVC.m
//  AllParkTickets
//
//  Created by Admin on 7/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ContactUsVC.h"
#import "SidemenuView.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"

@interface ContactUsVC ()<UIScrollViewDelegate,MBProgressHUDDelegate>
{
     SidemenuView *objSideMenuView;
    NSArray *response;
    NSDictionary *dict2;
      MBProgressHUD *HUD;
     NSString *about_us;
    NSString *advantage;
     NSString *image;
    

}
@property (strong, nonatomic) IBOutlet MyImageView *image1;
@property(nonatomic,strong)IBOutlet UIWebView *webvieww;
@end

@implementation ContactUsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    [self calling_webservices];
    // Do any additional setup after loading the view.
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
-(void) viewDidLayoutSubviews
{
    _scrollview.contentSize = CGSizeMake(_scrollview.frame.size.width, 1500);
}
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
-(void)calling_webservices
{
    [HUD show:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"https://www.allparktickets.com/api/aboutus.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            response = [dict2 valueForKey:@"response"];
          
            
             about_us=[[response valueForKey:@"about_us"]objectAtIndex:0];
            
            
             advantage=[[response valueForKey:@"advantage"]objectAtIndex:0];
            NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[about_us dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
            
            //  NSLog(@"htmlString %@",attrStr);
            
            NSString *gfdfd =[NSString stringWithFormat:@"%@",attrStr];
            // NSLog(@"htmlString %@",gfdfd);
            
            NSArray *dddggf =[gfdfd componentsSeparatedByString:@"{"];
            
            NSString *actualstring =[dddggf objectAtIndex:0];
            
            
            
            NSAttributedString * attrStr1 = [[NSAttributedString alloc] initWithData:[advantage dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
            
            //  NSLog(@"htmlString %@",attrStr);
            
            NSString *gfdfd1 =[NSString stringWithFormat:@"%@",attrStr1];
            // NSLog(@"htmlString %@",gfdfd);
            
            NSArray *dddggf1 =[gfdfd1 componentsSeparatedByString:@"{"];
            
            NSString *actualstring1 =[dddggf1 objectAtIndex:0];
            
           
            
            NSString *str = [NSString stringWithFormat:@"%@\r%@", actualstring,actualstring1];
            
            
            
            
            NSLog(@"RealData %@",actualstring);
            
            [_webvieww loadHTMLString:str baseURL:nil];
            
            
            //advantage=[response valueForKey:@"advantage"];
             image=[[response valueForKey:@"image"]objectAtIndex:0];
            
             [_image1 addImageFrom:[image stringByURLDecode] isRound:YES isActivityIndicator:YES];
         
            [HUD hide:YES];
            
            
        });
    });
    
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [HUD hide:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
