//
//  Container1.h
//  AllParkTickets
//
//  Created by Admin on 7/3/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Container1 : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tablvieww;
@property(nonatomic,strong)NSString *df;
@end
