//
//  Container1.m
//  AllParkTickets
//
//  Created by Admin on 7/3/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "Container1.h"
#import "tablviewCell.h"
#import "tablviewCell.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "DetailsView.h"


@interface Container1 ()

{
    NSArray *arrays;
    NSMutableArray *imagesArray;
    // SBSliderView *slider;
    MBProgressHUD *HUD;
    
    NSDictionary *dict2;
    NSArray *response;
    NSArray *trending;
    NSArray *country_name;
    NSArray *state_name;
    NSArray *city;
    NSArray *image;
    NSArray *duration;
    NSArray *trendingresponse;
     NSArray *tittles;

}
@property (strong, nonatomic) IBOutlet MyImageView *image1;
@end

@implementation Container1

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    [self CallingWebServices];


    // Do any additional setup after loading the view.
}
-(IBAction)refresh:(id)sender{
    [self CallingWebServices];
 [_tablvieww reloadData];
    
}
-(void)CallingWebServices

{
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
      //  NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/tour_list.php"];
        
        
     //   NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
     //   dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
         //   response = [dict2 valueForKey:@"response"];
            if ([_df isEqualToString:@"search"]) {
              trendingresponse = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"response"] mutableCopy];  
            }
            else{
            
            trendingresponse = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"trending"] mutableCopy];
            
            }
           // trending = [response valueForKey:@"trending"];
            
            tittles =[trendingresponse valueForKey:@"title"];
            country_name = [trendingresponse valueForKey:@"country_name"];
            state_name = [trendingresponse valueForKey:@"state_name"];
            city = [trendingresponse valueForKey:@"city"];
            image = [trendingresponse valueForKey:@"image"];
            duration =[trendingresponse valueForKey:@"duration"];
          [_tablvieww reloadData];
                _tablvieww.frame =CGRectMake(0,0, _tablvieww.frame.size.width, 220*country_name.count);
          
            
            
            [HUD hide:YES];
        });
    });
    
    
    
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 220;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [image  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
    
    cell.Pricelbl.text =[tittles objectAtIndex:indexPath.row];

    cell.tittlelbl.text =[country_name objectAtIndex:indexPath.row];
    
    
    cell.tittlelbl2.text =[city objectAtIndex:indexPath.row];
      cell.tittlelbl3.text =[duration objectAtIndex:indexPath.row];
    
    _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[image objectAtIndex:indexPath.row];
    
    // NSLog(@"path %@",path);
    
    [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];

//    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
  // trending
    
    
    NSArray *getindex =[trendingresponse objectAtIndex:indexPath.row];
    DetailsView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailsView"];
    controller.trendingArray =getindex;
    [self.navigationController pushViewController:controller animated:YES];
    
   
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
