//
//  Container2.m
//  AllParkTickets
//
//  Created by Admin on 7/3/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "Container2.h"
#import "tablviewCell.h"
#import "NSString+HTML.h"
#import "DetailsView.h"
@interface Container2 (){
    NSArray *arrays;
    NSArray *offer;
     NSArray *country_name;
     NSArray *state_name;
    NSMutableArray *yourArray;
    NSArray *city;
    NSArray *title;
      NSArray *image;
    NSArray *adults_amount;
    
    NSArray *rating;
}
@property (strong, nonatomic) IBOutlet MyImageView *image1;
@end

@implementation Container2

- (void)viewDidLoad {
    [super viewDidLoad];
   
yourArray = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"offers"] mutableCopy];
    
    
    
  
       NSLog(@"offers %@",yourArray);
    title =[yourArray valueForKey:@"title"];
    country_name = [yourArray valueForKey:@"country_name"];
    state_name = [yourArray valueForKey:@"state_name"];
    city = [yourArray valueForKey:@"city"];
    image = [yourArray valueForKey:@"image"];
    adults_amount =[yourArray valueForKey:@"adults_amount"];
   // duration =[yourArray valueForKey:@"duration"];
     _tablvieww.frame =CGRectMake(0,0, _tablvieww.frame.size.width, yourArray.count*320);
    [_tablvieww reloadData];
    
    // Do any additional setup after loading the view.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 320;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
     return [image  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
        cell.tittlelbl.text =[title objectAtIndex:indexPath.row];
    
    cell.countrylbl.text =[country_name objectAtIndex:indexPath.row];
    cell.statelbl.text =[NSString stringWithFormat:@"%@ ,%@",[state_name objectAtIndex:indexPath.row],[country_name objectAtIndex:indexPath.row]];
    
    cell.Pricelbl.text =[NSString stringWithFormat:@"$%@",[adults_amount objectAtIndex:indexPath.row]];

    cell.yourbutton.tag = indexPath.row;
    [cell.yourbutton addTarget:self action:@selector(yourButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        _image1=(MyImageView*)[cell viewWithTag:1];
        NSString *path=[image objectAtIndex:indexPath.row];
    
        // NSLog(@"path %@",path);
    
        [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    //
    return cell;
}
-(void)yourButtonClicked:(id)sender

{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablvieww];
    NSIndexPath *indexPath = [self.tablvieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);
    
    NSArray *getindex =[yourArray objectAtIndex:indexPath.row];
    DetailsView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailsView"];
    controller.trendingArray =getindex;
    [self.navigationController pushViewController:controller animated:YES];

    
    
     }
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    // trending
    
    
    NSLog(@"mikee %ld",(long)indexPath.row);
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
