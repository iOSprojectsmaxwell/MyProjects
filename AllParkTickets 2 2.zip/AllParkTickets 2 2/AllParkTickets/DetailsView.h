//
//  DetailsView.h
//  AllParkTickets
//
//  Created by Admin on 7/4/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"
#import "WSCalendarView.h"
#import <CoreData/CoreData.h>

@interface DetailsView : UIViewController<WSCalendarViewDelegate>
@property(nonatomic,strong)NSArray *trendingArray;
@property (strong) NSManagedObject *device;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property(nonatomic,strong)IBOutlet MyImageView *imagevieww;
@property(nonatomic,strong)IBOutlet UILabel *tittlelbl;
@property(nonatomic,strong)IBOutlet UILabel *locationlbl;
@property(nonatomic,strong)IBOutlet UILabel *durationlbl;
@property(nonatomic,strong)IBOutlet UIWebView *content_text;
@property(nonatomic,strong)IBOutlet UILabel *Pricelbl;
@property(nonatomic,strong)IBOutlet UIScrollView*scrowl;
@property(nonatomic,strong)IBOutlet UILabel *cartlbl;

@property(weak,nonatomic)IBOutlet UIView *containerView;

@property(nonatomic,strong)IBOutlet UILabel *childpricelbl;
@property(nonatomic,strong)IBOutlet UILabel *adultpricelbl;
@property(nonatomic,strong)IBOutlet UILabel *titllelbl;

@property(nonatomic,strong)IBOutlet UITextField *SelectDateFeild;
@property(nonatomic,strong)IBOutlet UITextField *Childagefeild;
@property(nonatomic,strong)IBOutlet UITextField *Adultsagefeild;

@end
