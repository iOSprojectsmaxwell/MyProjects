//
//  DetailsView.m
//  AllParkTickets
//
//  Created by Admin on 7/4/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "DetailsView.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "tablviewCell.h"
#import "Common.h"
#import "AppDelegate.h"
#import "Checkout.h"
#import "MBProgressHUD.h"
@interface DetailsView ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,MBProgressHUDDelegate>
{
    AppDelegate *appdelegate;
    NSMutableArray *ChannelDBArray;
      MBProgressHUD *HUD;
    int count;
    NSDictionary *dictionary;
    int total_price;
    NSString *item_id;
    NSString *totalpricee;
    NSString *ss;
    NSString *dd;
    NSArray *childrensAge;
    WSCalendarView *calendarView;
    WSCalendarView *calendarViewEvent;
    NSMutableArray *eventArray;
    NSString *path;
    NSString *CartCount;
    NSString *cartcount;
}
@property(nonatomic,strong)IBOutlet UIView *blureview;
@property(nonatomic,strong)IBOutlet UIView *popview;
@property(nonatomic,strong)IBOutlet UITableView *tablvieww;
@property(nonatomic,strong)IBOutlet UITableView *tablvieww1;
@end

@implementation DetailsView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD show:YES];
    _tablvieww1.hidden=YES;
    _tablvieww.hidden=YES;
    childrensAge =[[NSArray alloc]initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20", nil];
    cartcount = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"CarCount"];
    
    _cartlbl.text =[NSString stringWithFormat:@"%@",cartcount];
    if (cartcount == (id)[NSNull null] || cartcount.length == 0)
    {
        _cartlbl.text =@"0";
        
    }
    else
    {
        _cartlbl.text =[NSString stringWithFormat:@"%@",cartcount];
    }
    


    calendarView = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    //calendarView.dayColor=[UIColor blackColor];
    //calendarView.weekDayNameColor=[UIColor purpleColor];
    //calendarView.barDateColor=[UIColor purpleColor];
    //calendarView.todayBackgroundColor=[UIColor blackColor];
    calendarView.tappedDayBackgroundColor=[UIColor whiteColor];
    calendarView.calendarStyle = WSCalendarStyleDialog;
    calendarView.isShowEvent=false;
    [calendarView setupAppearance];
    [self.view addSubview:calendarView];
    calendarView.delegate=self;
    
    
    calendarViewEvent = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    calendarViewEvent.calendarStyle = WSCalendarStyleView;
    calendarViewEvent.isShowEvent=true;
    calendarViewEvent.tappedDayBackgroundColor=[UIColor blackColor];
    calendarViewEvent.frame = CGRectMake(0, 0, self.containerView.frame.size.width, self.containerView.frame.size.height);
    [calendarViewEvent setupAppearance];
    calendarViewEvent.delegate=self;
    [self.containerView addSubview:calendarViewEvent];
    
    
    eventArray=[[NSMutableArray alloc] init];
    NSDate *lastDate;
    NSDateComponents *dateComponent=[[NSDateComponents alloc] init];
    for (int i=0; i<10; i++) {
        
        if (!lastDate) {
            lastDate=[NSDate date];
        }
        else{
            [dateComponent setDay:1];
        }
        NSDate *datein = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponent toDate:lastDate options:0];
        lastDate=datein;
        [eventArray addObject:datein];
    }
    [calendarViewEvent reloadCalendar];
    
    NSLog(@"%@",[eventArray description]);

    
    
    NSLog(@"Trending %@",_trendingArray);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSString * htmlString =[_trendingArray valueForKey:@"content"] ;
        NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
        
        //  NSLog(@"htmlString %@",attrStr);
        
        NSString *gfdfd =[NSString stringWithFormat:@"%@",attrStr];
        // NSLog(@"htmlString %@",gfdfd);
        
        NSArray *dddggf =[gfdfd componentsSeparatedByString:@"{"];
        
        NSString *actualstring =[dddggf objectAtIndex:0];
        
        NSLog(@"RealData %@",actualstring);
        
        [_content_text loadHTMLString:actualstring baseURL:nil];
        
        [HUD hide:YES];
    });

   // _content_text.text =[_trendingArray valueForKey:@"content"];
    
    _locationlbl.text =[NSString stringWithFormat:@"%@, %@",[_trendingArray valueForKey:@"state_name"],[_trendingArray valueForKey:@"country_name"]];
   
    
    item_id =[_trendingArray valueForKey:@"id"];
    _durationlbl.text =[_trendingArray valueForKey:@"duration"];
    
    _titllelbl.text =[_trendingArray valueForKey:@"title"];
    _childpricelbl.text =[NSString stringWithFormat:@"$%@",[_trendingArray valueForKey:@"child_amount"]];
    _adultpricelbl.text =[NSString stringWithFormat:@"$%@",[_trendingArray valueForKey:@"adults_amount"]];
    _Pricelbl.text =[NSString stringWithFormat:@"$%@/Per Person",[_trendingArray valueForKey:@"adults_amount"]];
  //  NSString *ff =[_trendingArray valueForKey:]
  path=[_trendingArray valueForKey:@"image"];
    
    // NSLog(@"path %@",path);
    
    [_imagevieww addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];

    
    _tittlelbl.text =[_trendingArray valueForKey:@"title"];
    
    [self.tablvieww reloadData];
    
    
    _blureview.hidden =YES;
    // Do any additional setup after loading the view.
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [HUD hide:YES];
    
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 30;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [childrensAge  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[_tablvieww1 dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"tablviewCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }

    
    
    cell.tittlelbl.text =[childrensAge objectAtIndex:indexPath.row];
    
    
    //
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    if ([dd isEqualToString:@"child"]) {
          NSArray *getindex =[childrensAge objectAtIndex:indexPath.row];
          NSString *tt =[NSString stringWithFormat:@"%@",getindex];
        tt =[childrensAge objectAtIndex:indexPath.row];
         _Adultsagefeild.text = tt;
       
    }
    else{
          NSArray *getindex =[childrensAge objectAtIndex:indexPath.row];
          NSString *ttt =[NSString stringWithFormat:@"%@",getindex];
     ttt =[childrensAge objectAtIndex:indexPath.row];
        
        _Childagefeild.text = ttt;
    }
    
    
    _tablvieww.hidden=YES;
    _tablvieww1.hidden=YES;
    
}
-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void) viewDidLayoutSubviews
{
    
_scrowl.contentSize = CGSizeMake(_scrowl.frame.size.width, 780);
   // _scrowl.contentSize = CGSizeMake(_scrowl.frame.size.width, offer.count*320+trending.count*220+89+373);
}

-(IBAction)addtoCart:(id)sender{
    
    _blureview.hidden =NO;
    
}


-(IBAction)calender_showong:(id)sender{
    
  [calendarView ActiveCalendar:sender];   
    
    
}
-(IBAction)Adults_button:(id)sender{
    
    _tablvieww1.hidden=NO;
    _tablvieww.hidden=YES;
    dd =@"child";
}

-(IBAction)child_button:(id)sender{
    
    _tablvieww1.hidden=YES;
    _tablvieww.hidden=NO;
    dd =@"Adults";
   
    
}
#pragma mark WSCalendarViewDelegate

-(NSArray *)setupEventForDate{
    return eventArray;
}

-(void)didTapLabel:(WSLabel *)lblView withDate:(NSDate *)selectedDate
{
    NSDateFormatter *monthFormatter=[[NSDateFormatter alloc] init];
    [monthFormatter setDateFormat:@"dd/MMMM/yyyy"];
    NSString *str=[monthFormatter stringFromDate:selectedDate];
    self.SelectDateFeild.text = str;
   
}

-(void)deactiveWSCalendarWithDate:(NSDate *)selectedDate{
    NSDateFormatter *monthFormatter=[[NSDateFormatter alloc] init];
    [monthFormatter setDateFormat:@"dd/MMMM/yyyy"];
    NSString *str=[monthFormatter stringFromDate:selectedDate];
    self.SelectDateFeild.text = str;
}


- (IBAction)hideKeyboard:(id)sender {
    
    [self.view endEditing:YES];
}



-(IBAction)addtocart:(id)sender{
    
    
    if (_SelectDateFeild.text.length ==0) {
      
        [Common AlertShowWithErrorMsg:@"Please Select Date"];
    }
    else if (_Adultsagefeild.text.length ==0)
    {
        
       [Common AlertShowWithErrorMsg:@"Please Select How many Members of Adults"];
    }
    else if (_Childagefeild.text ==0)
    {
        
       [Common AlertShowWithErrorMsg:@"Please Select How many Members of Childrens"];
    }
    else{
        
        int childnumbers;
        int adultnumbers;
        
        int childcost;
        int adultcost;
        
        int totalcjildprice;
        int totaladultprice;
       
        
        childnumbers =[_Childagefeild.text intValue];
        adultnumbers =[_Adultsagefeild.text intValue];
        
        childcost =[_childpricelbl.text intValue];
        adultcost =[_adultpricelbl.text intValue];
        
        NSArray *childpri =[_childpricelbl.text componentsSeparatedByString:@"$"];
        
        NSString *childcost1 =[childpri objectAtIndex:1];
        
        
        
        NSArray *adultpri =[_adultpricelbl.text componentsSeparatedByString:@"$"];
        
        NSString *adultcost1 =[adultpri objectAtIndex:1];
        
        int cc =[childcost1 intValue];
        int cc1 =[adultcost1 intValue];
        totalcjildprice =childnumbers*cc;
        totaladultprice =adultnumbers*cc1;
        
        
        total_price =totaladultprice+totalcjildprice;

        totalpricee =[NSString stringWithFormat:@"$%d",total_price];
        
        [self addingData_Core];
    }
}


-(void)addingData_Core
{
    
  
    
    int caet =[cartcount intValue];
    
    count =caet+1;
    
    
    CartCount =[NSString stringWithFormat:@"%d",count];
   // NSString *valueToSave = @"someValue";
    [[NSUserDefaults standardUserDefaults] setObject:CartCount forKey:@"CarCount"];
    [[NSUserDefaults standardUserDefaults] synchronize];
   
    AppDelegate *appDel=(AppDelegate *)[UIApplication sharedApplication].delegate;
    _managedObjectContext=[appDel managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Core"
                                              inManagedObjectContext:_managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSError *error = nil;
    NSArray  *fetchedObjects = [_managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"no object");
    }
    else
    {
        for(NSManagedObject* currentObj in fetchedObjects) {
            //[tableDataArray addObject:currentObj];
        }}
    
    
    _managedObjectContext = [appDel managedObjectContext];
    NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Core" inManagedObjectContext:_managedObjectContext];
    
    [newDevice setValue:path forKey:@"image"];
    [newDevice setValue:_titllelbl.text forKey:@"tittle"];
   
      [newDevice setValue: _Pricelbl.text forKey:@"basefee"];
    
    [newDevice setValue: _childpricelbl.text forKey:@"childPrice"];
    
    [newDevice setValue:item_id forKey:@"id"];

    [newDevice setValue: _adultpricelbl.text forKey:@"adultprice"];
    
    
     [newDevice setValue:_Adultsagefeild.text forKey:@"adult"];
     [newDevice setValue:_Childagefeild.text forKey:@"child"];
     [newDevice setValue:totalpricee forKey:@"price"];
    
    error = nil;
    if ([_managedObjectContext save:&error]) {
        NSLog(@"data saved");
        
        appdelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        
        
        
    }
    else{
        NSLog(@"Error occured while saving");
    }

    Checkout *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Checkout"];
  
    [self.navigationController pushViewController:controller animated:YES];
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    _blureview.hidden=YES;
    cartcount = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"CarCount"];
    
    

    if (cartcount == (id)[NSNull null] || cartcount.length == 0)
    {
        _cartlbl.text =@"0";
        
    }
    else
    {
        _cartlbl.text =[NSString stringWithFormat:@"%@",cartcount];
    }
    
    
    
    
}

-(IBAction)cart_button:(id)sender{
    Checkout *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Checkout"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)close_button:(id)sender{
    
    
    _blureview.hidden =YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
