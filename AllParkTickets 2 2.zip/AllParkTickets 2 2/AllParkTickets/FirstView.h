//
//  FirstView.h
//  AllParkTickets
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstView : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>
@property(nonatomic,strong)IBOutlet UIView*container1;
@property(nonatomic,strong)IBOutlet UIView*container2;
@property(nonatomic,strong)IBOutlet UIView*viee;
@property(nonatomic,strong)IBOutlet UIScrollView*scrowl;
@property(nonatomic,strong)IBOutlet UIView*Hederview;
@property(nonatomic,strong)IBOutlet UILabel*cartlbl;
@property(nonatomic,strong)IBOutlet UIView*Chekoutt;
@property(nonnull,strong)IBOutlet UITableView *tabllvieww;
@property(nonatomic,strong)IBOutlet UISearchBar*textfeildd;
@property(nonatomic,strong)IBOutlet UITextField *text;
@property(nonatomic,strong)IBOutlet UIView *myView;

@property(nonatomic,strong)IBOutlet UIButton *close_button;
@end
