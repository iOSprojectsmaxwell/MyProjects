//
//  FirstView.m
//  AllParkTickets
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "FirstView.h"
#import "Container1.h"
#import "Container2.h"
#import "tablviewCell.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Checkout.h"
#import "LoginView.h"
#import "SidemenuView.h"

@interface FirstView ()<UIScrollViewDelegate,MBProgressHUDDelegate,UISearchBarDelegate,UITextFieldDelegate>{
    NSMutableArray *imagesArray;
   // SBSliderView *slider;
    MBProgressHUD *HUD;
     SidemenuView *objSideMenuView;
    NSDictionary *dict2;
    NSArray *response;
    NSArray *trending;
    NSArray *country_name;
    NSArray *state_name;
    NSArray *city;
    NSArray *image;
    NSArray *duration;
    NSArray *offer;
    NSArray *responsecitys;
    NSArray *citys;
    NSArray *toursename;
     NSArray *offer1;
    NSArray *imagees;
    int index;
    NSArray *filteredArray;
    int responsecount;
    int nj;
    NSString *cartcount;
    NSString *Login_id;
    NSArray *namees;
    NSString *cont;
    NSArray *AutoComplistionArray;
    NSString *arr;
}
@property (weak, nonatomic) IBOutlet UISearchBar *search_box;
@property (weak, nonatomic) IBOutlet UIImageView *imagevieww;



@end

@implementation FirstView

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    [self check_out:nil];
    _tabllvieww.hidden =YES;
    cartcount = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"CarCount"];
    
    _myView.layer.shadowColor = [UIColor clearColor].CGColor;
    _myView.layer.shadowOffset = CGSizeMake(0, 5);
    _myView.layer.shadowOpacity = 7;
    _myView.layer.shadowRadius = 1.0;
    _close_button.hidden=YES;
    if (cartcount == (id)[NSNull null] || cartcount.length == 0)
    {
       _cartlbl.text =@"0";
        
    }
    else
    {
       _cartlbl.text =[NSString stringWithFormat:@"%@",cartcount];
    }
    
    
  
    
    self.navigationController.navigationBar.hidden =YES;
    _search_box.hidden =YES;
    imagees =[[NSArray alloc]initWithObjects:@"banner1",@"banner2",@"banner3",@"banner4", nil];
    
    //index=0;
    
    [NSTimer scheduledTimerWithTimeInterval:3
                                     target:self
                                   selector:@selector(animateImages)
                                   userInfo:nil
                                    repeats:YES];
    index = 1;
   // NSArray *images = [NSArray arrayWithObjects:[UIImage imageNamed:@"animated-fish-1.jpg"], [UIImage imageNamed:@"tumblr_7"], [UIImage imageNamed:@"th_nature_4.jpg"],nil];
//    _imagevieww
//    .image = [imagees objectAtIndex:index];
//    [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(changeImage) userInfo:nil repeats:YES];
    
    
    
 [self CallingWebServices];
    
    [self calling_webservices];
  
    
 
 

    // Do any additional setup after loading the view.
}
-(IBAction)search_close:(id)sender{
     cont  =@" ";
    _text.text =@" ";
    
    
    _close_button.hidden=YES;
    [self CallingWebServices];
}

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    
    
    if([text isEqualToString:@""] || text==nil) {
        [self CallingWebServices];
        
    }
    else{
    _tabllvieww.hidden =NO;
    //NSString *searchText = [text stringByReplacingCharactersInRange:range withString:text];
        NSLog(@"searchText %@",text);
    NSPredicate *bPredicate =
    [NSPredicate predicateWithFormat:@"SELF CONTAINS[c] %@",text];
    AutoComplistionArray =
    [namees filteredArrayUsingPredicate:bPredicate];
    
    
    NSArray *filteredArray;
    NSString *firstBit1;
    
    [_tabllvieww reloadData];
    
    }
    
    return YES;
}



- (BOOL)textField:(UITextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString*)string
{
    
    
    NSString *searchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    NSLog(@"cityes %@",_text);
    
   // %@", word
    
    NSPredicate *bPredicate =
    [NSPredicate predicateWithFormat:@"SELF contains[cd] %@",searchText];
   AutoComplistionArray =
    [namees filteredArrayUsingPredicate:bPredicate];
    _tabllvieww.hidden =NO;
 
    NSArray *filteredArray;
    NSString *firstBit1;
 
    [_tabllvieww reloadData];
    
 
    
   
       // [self calling_webServices];
 
    return YES;
}

-(IBAction)search:(id)sender{
    
    
}
-(void)calling_webservices
{

    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"https://www.allparktickets.com/api/list_details.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            responsecitys = [dict2 valueForKey:@"response"];
    
    
            citys =[responsecitys valueForKey:@"search"];
            namees =[citys valueForKey:@"name"];
            
            
        });
    });
    

}


-(IBAction)check_out:(id)sender
{
    
    Login_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"user_id"];
if (Login_id == nil || [Login_id isKindOfClass:[NSNull class]]) {
   
    _Chekoutt.hidden =NO;
        
}
else{
       _Chekoutt.hidden =YES;
}
}


-(IBAction)ch:(id)sender{
    LoginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginView"];
    
    [self.navigationController pushViewController:controller animated:YES];
    
}
-(IBAction)cart_button:(id)sender{
    Checkout *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Checkout"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(void)animateImages
{
    index = index + 1;
    NSString *imageName = [NSString stringWithFormat:@"banner1.png"];
 
    if(index==[imagees count]){
        index=0;
    }
//    [UIView animateWithDuration:1.0 animations:^(void) {
//        _imagevieww.alpha = 0;
//       // image2.alpha = 1;
//    }];
    
//completion:^(BOOL finished){
    //Appear
//    [UIView animateWithDuration:1.0 animations:^(void) {
        [_imagevieww setImage:[UIImage imageNamed:[imagees objectAtIndex:index]]];
//        _imagevieww.alpha = 0;
//        _imagevieww.alpha = 1;
   // }];
//};
    
    

    
}
-(void)changeImage {
    index++;
    if(index==[imagees count]){
        index=0;
    }
    _imagevieww.image = [imagees objectAtIndex:index];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [_textfeildd resignFirstResponder];
    // Do the search...
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    // do whatever you have to do
    
    [_textfeildd resignFirstResponder];
    return YES;
}
- (void)hideTextField:(UITextField *)textField {
    
    // do whatever you have to do
    
    [_textfeildd resignFirstResponder];
}
-(IBAction)search_button:(id)sender{
    
    
    _search_box.hidden =NO;
}



-(void)SearchWeb

{
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    NSString *idd =[[filteredArray valueForKey:@"id"]objectAtIndex:0];
    NSString *type_id =[[filteredArray valueForKey:@"type"]objectAtIndex:0];
    
  
    
    
    
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"https://www.allparktickets.com/api/search_details.php?search_id=%@&type_id=%@",idd,type_id];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            response = [dict2 valueForKey:@"response"];
            
            
          responsecount =(int)response.count;
            country_name = [response valueForKey:@"country_name"];
           
            if (responsecount ==0) {
             [Common AlertShowWithErrorMsg:@"There is no tourse list in this city"];
           
            [HUD hide:YES];
            }
            else{
          
            state_name = [response valueForKey:@"state_name"];
            city = [response valueForKey:@"city"];
            image = [response valueForKey:@"image"];
            duration =[response valueForKey:@"duration"];
            
            nj =(int)country_name.count;
            NSLog(@"nj %d",nj);
            [[NSUserDefaults standardUserDefaults] setObject:offer1 forKey:@"offer1"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setObject:trending forKey:@"trending"];
            [[NSUserDefaults standardUserDefaults] synchronize];
           cont  =@"search";
         
            
            [[NSUserDefaults standardUserDefaults] setObject:response forKey:@"response"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            // int ff =offer.count
            
            
            Container1 *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Container1"];
            
            vc.df =cont;
            [self addChildViewController:vc];
            vc.view.frame = CGRectMake(0, 0, self.container1.frame.size.width, self.container1.frame.size.height);
            [self.container1 addSubview:vc.view];
            [vc didMoveToParentViewController:self];
            
            
            Container2 *vc1 = [self.storyboard instantiateViewControllerWithIdentifier:@"Container2"];
            
            [[NSUserDefaults standardUserDefaults] setObject:offer forKey:@"offers"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            vc1.offers =offer;
            [self addChildViewController:vc1];
            vc.view.frame = CGRectMake(0, 0, self.container2.frame.size.width, self.container2.frame.size.height);
            [self.container2 addSubview:vc1.view];
            [vc didMoveToParentViewController:self];
            _Hederview.frame =CGRectMake(0,0, _Hederview.frame.size.width, 365);
            _container1.frame =CGRectMake(0,370, _container1.frame.size.width, responsecount*220);
            _viee.frame =CGRectMake(0,nj*220+373, _viee.frame.size.width, 89);
            
            _container2.frame =CGRectMake(0,responsecount*220+373+90, _container2.frame.size.width, responsecount*320+200);
            
            [self.scrowl addSubview:_Hederview];
            
            
            [self.scrowl addSubview:_container1];
            [self.scrowl addSubview:_viee];
            [self.scrowl addSubview:_container2];
            
            [self viewDidLayoutSubviews];
            
            }
            // [_tablvieww reloadData];
            
            
            [HUD hide:YES];
        });
    });
    
    
    
    
}


- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    
    [self.searchDisplayController setActive:NO animated:YES];
    
}



-(void)CallingWebServices

{
[HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/tour_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            response = [dict2 valueForKey:@"response"];
            offer =[response valueForKey:@"recommed"];
            
            offer1 =[response valueForKey:@"offer"];
            trending = [response valueForKey:@"trending"];
            country_name = [trending valueForKey:@"country_name"];
            state_name = [trending valueForKey:@"state_name"];
            city = [trending valueForKey:@"city"];
            image = [trending valueForKey:@"image"];
            duration =[trending valueForKey:@"duration"];
            
         nj =(int)country_name.count;
            NSLog(@"nj %d",nj);
            [[NSUserDefaults standardUserDefaults] setObject:offer1 forKey:@"offer1"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setObject:trending forKey:@"trending"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
           // int ff =offer.count
                        Container1 *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Container1"];
            
            [self addChildViewController:vc];
            vc.view.frame = CGRectMake(0, 0, self.container1.frame.size.width, self.container1.frame.size.height);
            [self.container1 addSubview:vc.view];
            [vc didMoveToParentViewController:self];
            
            
            Container2 *vc1 = [self.storyboard instantiateViewControllerWithIdentifier:@"Container2"];
            
            [[NSUserDefaults standardUserDefaults] setObject:offer forKey:@"offers"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            vc1.offers =offer;
            [self addChildViewController:vc1];
            vc.view.frame = CGRectMake(0, 0, self.container2.frame.size.width, self.container2.frame.size.height+200);
            [self.container2 addSubview:vc1.view];
            [vc didMoveToParentViewController:self];
            _Hederview.frame =CGRectMake(0,0, _Hederview.frame.size.width, 405);
            _container1.frame =CGRectMake(0,407, _container1.frame.size.width, nj*220);
            _viee.frame =CGRectMake(0,nj*220+373, _viee.frame.size.width, 89);
            
            _container2.frame =CGRectMake(0,nj*220+373+90, _container2.frame.size.width, offer.count*320);
            
            [self.scrowl addSubview:_Hederview];
           
          
            [self.scrowl addSubview:_container1];
            [self.scrowl addSubview:_viee];
              [self.scrowl addSubview:_container2];
 
            [self viewDidLayoutSubviews];
            
           // [_tablvieww reloadData];
            
            
            [HUD hide:YES];
        });
    });
    
    
    
   
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 40;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [AutoComplistionArray  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
    
    
    cell.tittlelbl.text =[AutoComplistionArray objectAtIndex:indexPath.row];

    
    //
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    arr =[AutoComplistionArray objectAtIndex:indexPath.row];
    [_text resignFirstResponder];
    _close_button.hidden=NO;
    _tabllvieww.hidden=YES;
    _text.text =arr;
   
}

-(IBAction)search_path:(id)sender{
    
    NSLog(@"arr %@",arr);
    _textfeildd.text =arr;
    filteredArray = [citys filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(name LIKE[cd] %@)",arr]];
    
    NSLog(@"filteredArray %@",filteredArray);
    _tabllvieww.hidden =YES;
    
    
    
    [self SearchWeb];
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    cartcount = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"CarCount"];
    
    
    _close_button.hidden=YES;
    if (cartcount == (id)[NSNull null] || cartcount.length == 0)
    {
        _cartlbl.text =@"0";
        
    }
    else
    {
        _cartlbl.text =[NSString stringWithFormat:@"%@",cartcount];
    }

    
    
    
}

-(void) viewDidLayoutSubviews
{
    
    NSLog(@"testing %d",nj);
    

    
    
    if ([cont isEqualToString:@"search"]) {
        _scrowl.contentSize = CGSizeMake(_scrowl.frame.size.width,offer.count*320+responsecount*220+89+373);
    }
    else{
       _scrowl.contentSize = CGSizeMake(_scrowl.frame.size.width, offer.count*320+trending.count*220+89+373);
   
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
