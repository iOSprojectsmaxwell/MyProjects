//
//  HistoryDetails.h
//  AllParkTickets
//
//  Created by Admin on 7/16/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryDetails : UIViewController
@property(nonatomic,strong)NSArray *orders;

@property(nonatomic,strong)IBOutlet UILabel
*tournamelbl;

@property(nonatomic,strong)IBOutlet UILabel
*childQlbl;

@property(nonatomic,strong)IBOutlet UILabel
*AdultsQlbl;

@property(nonatomic,strong)IBOutlet UILabel
*Childpricelbl;

@property(nonatomic,strong)IBOutlet UILabel
*adultspricelbl;

@property(nonatomic,strong)IBOutlet UILabel
*Childtotalpricelbl;

@property(nonatomic,strong)IBOutlet UILabel
*adultstotalpricelbl;
@property(nonatomic,strong)IBOutlet UILabel
*netmountlbl;
@property(nonatomic,strong)IBOutlet UILabel
*datelbl;
@property(nonatomic,strong)IBOutlet UILabel
*orderlbl;

@end
