//
//  HistoryDetails.m
//  AllParkTickets
//
//  Created by Admin on 7/16/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "HistoryDetails.h"

@interface HistoryDetails ()
{
    NSString *childsQ;
    NSString *adultQ;
    NSString *childprice;
    NSString *adultprice;
    
    NSString *adultstltprice;
    NSString *childtltprice;
    NSString *net_amount;
    NSString *orderno;
    NSString *dates;
    
     NSString *tourname;
    
}

@end

@implementation HistoryDetails

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"orders details %@",_orders);
    
    childsQ =[_orders valueForKey:@"child_qty"];
    _childQlbl.text =childsQ;
    
    adultQ =[_orders valueForKey:@"adults_qty"];
    _AdultsQlbl.text =adultQ;
    childprice =[_orders valueForKey:@"child_amount"];

    _Childpricelbl.text =childprice;
    adultprice =[_orders valueForKey:@"adults_amount"];
    _adultspricelbl.text =adultprice;
    
    
    childtltprice =[_orders valueForKey:@"child_total_amount"];
    _Childtotalpricelbl.text =childtltprice;
    adultstltprice =[_orders valueForKey:@"adults_total_amount"];
    _adultstotalpricelbl.text =adultstltprice;
    
    orderno =[_orders valueForKey:@"order_no"];
    
    _orderlbl.text =orderno;
    dates =[_orders valueForKey:@"date"];
    _datelbl.text =dates;
    net_amount =[_orders valueForKey:@"net_amount"];
    _netmountlbl.text =net_amount;
    
    
    tourname =[_orders valueForKey:@"tour_name"];
    
     NSString *capitalizedString1 = [tourname uppercaseString];
    _tournamelbl.text =capitalizedString1;
         
    // Do any additional setup after loading the view.
}
-(IBAction)back:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
