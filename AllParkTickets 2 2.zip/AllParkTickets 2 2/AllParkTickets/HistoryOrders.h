//
//  HistoryOrders.h
//  AllParkTickets
//
//  Created by Admin on 7/13/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryOrders : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tablvieww;
@property(nonatomic,strong)NSArray *offers;


@end
