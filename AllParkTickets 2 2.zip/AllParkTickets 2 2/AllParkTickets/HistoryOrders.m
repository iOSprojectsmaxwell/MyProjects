//
//  HistoryOrders.m
//  AllParkTickets
//
//  Created by Admin on 7/13/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "HistoryOrders.h"
#import "tablviewCell.h"
#import "NSString+HTML.h"
#import "DetailsView.h"
#import "SidemenuView.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "HistoryDetails.h"
@interface HistoryOrders ()<MBProgressHUDDelegate>
{
    NSArray *arrays;
    NSArray *offer;
    NSArray *country_name;
    NSArray *state_name;
    NSMutableArray *yourArray;
    NSArray *city;
    NSArray *title;
    NSArray *image;
    SidemenuView *objSideMenuView;
    NSArray *adults_amount;
     MBProgressHUD *HUD;
    NSArray *rating;
     NSArray *response;
    NSDictionary *dict2;
     NSArray *orders;
     NSArray *orders1;
    NSArray *status;
    NSArray *order_no;
    NSArray *tour_name;
    NSArray *date;
    NSArray *adults_amount1;
    NSArray *child_amount;
    NSArray *adults_qty;
    NSString *user_id;
    NSArray *child_qty;
    NSArray *adults_qty1;
    
      NSArray *net_amount;
    
}
@property (strong, nonatomic) IBOutlet MyImageView *image1;

@end

@implementation HistoryOrders

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"user_id"];
    [self calling_webservices];
    // Do any additional setup after loading the view.
}

-(void)calling_webservices
{
    [HUD show:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"https://www.allparktickets.com/api/booking_history.php?cust_id=%@",user_id];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            response = [dict2 valueForKey:@"response"];
            
           
            orders =[response valueForKey:@"payments"];
           
         
           if (orders == (id)[NSNull null] || [orders count] == 1) {
                [Common AlertShowWithErrorMsg:@"Sorry! No Orders Yet"];
                [self.navigationController popViewControllerAnimated:YES];
            }
            
            else{
            
                orders1 =[response valueForKey:@"order"];
            
         order_no =[orders valueForKey:@"order_no"];
        
                status =[orders valueForKey:@"status"];
            
            net_amount =[orders valueForKey:@"net_amount"];
                
                
                
                
            [self.tablvieww reloadData];
            }
            
            [HUD hide:YES];
         
            
                    });
    });
    
    
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
    
    
}
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 67;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [order_no  count];     //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    // cell.TourName.text =[tour_name objectAtIndex:indexPath.row];
   // cell.ordernolbl.text =[order_no objectAtIndex:indexPath.row];
    
   // cell.Adultslbl.text =[adults_qty objectAtIndex:indexPath.row];
   // cell.childlbl.text =[child_qty objectAtIndex:indexPath.row];

    cell.netamountlbl.text =[NSString stringWithFormat:@"%@",[net_amount objectAtIndex:indexPath.row]];
    cell.btnselect.tag = indexPath.row;
    [cell.btnselect addTarget:self action:@selector(yourButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    cell.ordernoslbl.text =[order_no objectAtIndex:indexPath.row];
   // NSString *capitalizedString = [[status objectAtIndex:indexPath.row] capitalizedString];
    
    NSString *capitalizedString1 = [[status objectAtIndex:indexPath.row] uppercaseString];
    cell.statuslbl.text =[NSString stringWithFormat:@"%@",capitalizedString1];
    cell.srno.text =[NSString stringWithFormat:@"%ld",(long)indexPath.row+1];
   
    return cell;
}

-(void)yourButtonClicked:(id)sender

{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablvieww];
    NSIndexPath *indexPath = [self.tablvieww indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath %ld",(long)indexPath.row);
    HistoryDetails *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"HistoryDetails"];
    controller.orders =[orders1 objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:controller animated:YES];

    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
