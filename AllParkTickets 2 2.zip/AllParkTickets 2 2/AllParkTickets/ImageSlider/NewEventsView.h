//
//  NewEventsView.h
//  ImageSlider
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Soumalya Banerjee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewEventsView : UIViewController

@end
