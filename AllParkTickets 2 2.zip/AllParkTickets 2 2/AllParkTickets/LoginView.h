//
//  LoginView.h
//  AllParkTickets
//
//  Created by Admin on 7/7/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
@interface LoginView : UIViewController
@property (strong) NSManagedObject *device;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@end
