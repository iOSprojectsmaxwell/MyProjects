//
//  LoginView.m
//  AllParkTickets
//
//  Created by Admin on 7/7/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "LoginView.h"
#import "Common.h"
#import "JSON.h"
#import "FirstView.h"
#import "RegisterView.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"
@interface LoginView ()<MBProgressHUDDelegate>
{
      AppDelegate *appdelegate;
    NSDictionary *dict2;
    NSString *response;
    MBProgressHUD *HUD;
       NSArray *results;
}
@property (weak, nonatomic) IBOutlet UITextField *Emailfeild;
@property (weak, nonatomic) IBOutlet UITextField *PasswordFeild;

@end

@implementation LoginView

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    // Do any additional setup after loading the view.
}
-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)Login:(id)sender {
     [HUD show:YES];
    
    if (_Emailfeild.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please Enter username or emailid"];
    }
    else if (_PasswordFeild.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please Enter password"];
    }
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/login.php?user_name=%@&pswd=%@",_Emailfeild.text,_PasswordFeild.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
          dispatch_async(dispatch_get_main_queue(), ^{
        
           response = [dict2 valueForKey:@"response"];
            
              
              if ([response isEqualToString:@"failed"])
              {
                  
                  
                  [Common AlertShowWithErrorMsg:@"you are not register"];
              }
              else{
                  
                  
                  [Common AlertShowWithErrorMsg:@"Thankyou for Requests your Orders, we will contact to you soon"];
                  
                  [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"CarCount"];
                  [[NSUserDefaults standardUserDefaults] synchronize];
                  
                  
                  AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
                  
                  NSManagedObjectContext *context =[delegate managedObjectContext];
                  
                  
                  
                  NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Core"];
                  
                  NSError *error = nil;
                  results = [context executeFetchRequest:request error:&error];
                  
                  ;
                  //error handling goes here
                  for (NSManagedObject *car in results) {
                      [context deleteObject:car];
                  }
                  NSError *saveError = nil;
                  [context save:&saveError];
                  

                  FirstView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"FirstView"];
                
                  [self.navigationController pushViewController:controller animated:YES];

                  [[NSUserDefaults standardUserDefaults] setObject:response forKey:@"user_id"];
                  [[NSUserDefaults standardUserDefaults] synchronize];
              }
              
               [HUD hide:YES];
    });
});

}


-(IBAction)register_button:(id)sender{
    
    RegisterView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"RegisterView"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
