//
//  RegisterView.m
//  AllParkTickets
//
//  Created by Admin on 7/7/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "RegisterView.h"
#import "Common.h"
#import "MBProgressHUD.h"
#import "JSON.h"
#import "LoginView.h"

@interface RegisterView ()<MBProgressHUDDelegate>
{
     MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSArray *response;
    
    NSString *success;
}

@end

@implementation RegisterView

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];

    // Do any additional setup after loading the view.
}
- (IBAction)CreateanAccount:(id)sender {
    
    if (_Firstname.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your first name"];
    }
    else if (_Lastname.text.length==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter your last name"];
    }
    
    else if (_emailID.text.length==0)
    {
        
      [Common AlertShowWithErrorMsg:@"Please enter your emailID"];
    }
    
    else if (![self NSStringIsValidEmail:_emailID.text])
    {
        
        [Common AlertShowWithErrorMsg:@"Please Enter Valid Emaild Address"];
        
    }

    else if (_MobileNumber.text.length==0)
    {
      [Common AlertShowWithErrorMsg:@"Please enter your Mobile number"];
        
    }
    else if (_MobileNumber.text.length != 10)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Valid Mobile Number"];
    }
    else if (_Username.text.length==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter your Username"];
    }
    else if (_Password.text.length==0)
        
    {
         [Common AlertShowWithErrorMsg:@"Please enter password"];
        
    }
    else if (_ConfoirmPassword.text.length==0)
    {
        
       [Common AlertShowWithErrorMsg:@"Please Reenter Your password"];     
        
    }
    else if (_ConfoirmPassword.text.length!=_Password.text.length)
    {
        
        [Common AlertShowWithErrorMsg:@"your password did not match"];
        
    }
    
    
    
    else{
        [self calling_webServices];
        
    }
    
    
    
}

-(void)calling_webServices
{
    
   
    [HUD show:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
         NSString *apiURLStr;
        // data processing
        apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/registration.php?f_name=%@&l_name=%@&email=%@&phone=%@&username=%@&password=%@",_Firstname.text,_Lastname.text,_emailID.text,_MobileNumber.text,_Username.text,_Password.text];
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            //response =[dict2 valueForKey:@"response"];
            success =[dict2 valueForKey:@"response"];
            
            if ([success isEqualToString:@"email id (or) username already exists"]) {
                [Common AlertShowWithErrorMsg:@"email id (or) username already exists"];
            }
            else{
                
                 [Common AlertShowWithErrorMsg:@"You have register successfully"];
                LoginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginView"];
                [self.navigationController pushViewController:controller animated:YES];
                
            }
            
            
            
            
            [HUD hide:YES];
        });
    });
    

    
}

-(IBAction)login:(id)sender{
    
    LoginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginView"];
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
