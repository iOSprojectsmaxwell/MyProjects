//
//  SidemenuView.h
//  AllParkTickets
//
//  Created by Admin on 7/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#define WIDTH_SIDEMENU  250
#define HEIGHT_SIDEMENU  700


@interface SidemenuView : UIViewController{
    SidemenuView *objesidemenuView;
    
}


@end
