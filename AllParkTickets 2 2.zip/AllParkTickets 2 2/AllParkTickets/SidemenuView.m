//
//  SidemenuView.m
//  AllParkTickets
//
//  Created by Admin on 7/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "SidemenuView.h"
#import "FirstView.h"
#import "DetailsView.h"
#import "DealsView.h"
#import "ContactUs.h"
#import "ContactUsVC.h"
#import "HistoryOrders.h"

@interface SidemenuView ()

@end

@implementation SidemenuView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(IBAction)home_button:(id)sender{
    
    FirstView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"FirstView"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)Deails_button:(id)sender{
    
    DealsView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"DealsView"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)contanct_button:(id)sender{
    
    ContactUs *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactUs"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)About_button:(id)sender{
    
    ContactUsVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactUsVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}



-(IBAction)About_butto:(id)sender{
    
    HistoryOrders *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"HistoryOrders"];
    
    [self.navigationController pushViewController:controller animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
