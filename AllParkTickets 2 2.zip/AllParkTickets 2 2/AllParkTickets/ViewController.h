//
//  ViewController.h
//  AllParkTickets
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SBSliderView.h"
#import "SBPhotoViewer/SBPhotoManager.h"

@interface ViewController : UIViewController<SBSliderDelegate,UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UISwitch *autoPlayToggle;
@property (strong, nonatomic) IBOutlet UIImageView *sampleImageView;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *containerView;
@property (strong, nonatomic) IBOutlet UITableView *tablvieww;

- (IBAction)toggleAutoPlay:(id)sender;
- (IBAction)tappedOnSampleImage:(id)sender;



@end

