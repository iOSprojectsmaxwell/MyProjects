//
//  ViewController.m
//  AllParkTickets
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ViewController.h"
#import "tablviewCell.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"

#define _AUTO_SCROLL_ENABLED 0
@interface ViewController ()<UIScrollViewDelegate,MBProgressHUDDelegate>{
    NSMutableArray *imagesArray;
    SBSliderView *slider;
    MBProgressHUD *HUD;
    
    NSDictionary *dict2;
    NSArray *response;
    NSArray *trending;
    NSArray *country_name;
    NSArray *state_name;
    NSArray *city;
    NSArray *image;
    NSArray *duration;
    
   
}
@property (strong, nonatomic) IBOutlet MyImageView *image1;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
   
    [self CallingWebServices];
//[_scrollView addSubview:slider];
//[slider stopAutoPlay];
  //  [self toggleAutoPlay:nil];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)CallingWebServices

{
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/tour_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            response = [dict2 valueForKey:@"response"];
            
            trending = [response valueForKey:@"trending"];
            country_name = [trending valueForKey:@"country_name"];
            state_name = [trending valueForKey:@"state_name"];
            city = [trending valueForKey:@"city"];
            image = [trending valueForKey:@"image"];
            duration =[trending valueForKey:@"duration"];
            
            [_tablvieww reloadData];

           
            [HUD hide:YES];
        });
    });

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //  http://gnaritusglobal.com/clients/desikan/api/home.php
    
    // http://tech599.com/tech599.com/johnaks/church_finder/api/login.php
    
//    urlstring=@"tour_list.php";
//    
//    
//    data = @"";
//    // [NSString stringWithFormat:@"email=%@&pwd=%@",_emailidFeild.text,_passwordFeild.text];
//    
//    
//    [WebManager callAPI:urlstring Data:data delegate:self onSuccess:@selector(onSuccessg:) onFailure:@selector(onFailureg:)];
//    
//    
    
}

-(void) onSuccessg:(NSDictionary *)dict{
    
    NSLog(@"if success %@",dict);
    [HUD hide:YES];
    
}

-(void) onFailureg:(NSDictionary *)dict{
    NSLog(@"if fail %@",dict);
    
    
    response = [dict valueForKey:@"response"];

    trending = [response valueForKey:@"trending"];
    country_name = [trending valueForKey:@"country_name"];
    state_name = [trending valueForKey:@"state_name"];
    city = [trending valueForKey:@"city"];
    image = [trending valueForKey:@"image"];
    duration =[trending valueForKey:@"duration"];
    
    [_tablvieww reloadData];
    
    
 
    [HUD hide:YES];
    
}


- (IBAction)toggleAutoPlay:(id)sender {
    
    UISwitch *toggleSwitch = (UISwitch *)sender;
    
    if ([toggleSwitch isOn]) {
        [slider startAutoPlay];
    } else {
        [slider stopAutoPlay];
    }
}
-(void) viewDidLayoutSubviews
{
    int intt =(int)country_name.count;
    
    NSLog(@"%d",intt);
    
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width, 2300);
    
_tablvieww.frame =CGRectMake(0,340, _tablvieww.frame.size.width, 1950);
}

- (void)sbslider:(SBSliderView *)sbslider didTapOnImage:(UIImage *)targetImage andParentView:(UIImageView *)targetView {
    
    SBPhotoManager *photoViewerManager = [[SBPhotoManager alloc] init];
    [photoViewerManager initializePhotoViewerFromViewControlller:self forTargetImageView:targetView withPosition:sbslider.frame];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 220;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [image  count];    //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"tablviewCell";
    
    
    
    
    tablviewCell  *cell = (tablviewCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[tablviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    cell.tittlelbl.text =[country_name objectAtIndex:indexPath.row];
    
    _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[image objectAtIndex:indexPath.row];
    
    // NSLog(@"path %@",path);
    
    [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    return cell;
}


- (IBAction)tappedOnSampleImage:(id)sender {
    
    UIGestureRecognizer *gesture = (UIGestureRecognizer *)sender;
    UIImageView *targetView = (UIImageView *)gesture.view;
    
    SBPhotoManager *photoViewerManager = [[SBPhotoManager alloc] init];
    [photoViewerManager initializePhotoViewerFromViewControlller:self forTargetImageView:targetView withPosition:targetView.frame];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
