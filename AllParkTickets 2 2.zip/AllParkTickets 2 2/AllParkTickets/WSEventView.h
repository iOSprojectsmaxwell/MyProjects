//
//  WSEventView.h
//  CalendarDemo
//
//  Created by Dotsquares on 2/16/17.
//  Copyright © 2017 Dotsquares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSEventView : UIView
@property (nonatomic,strong) UIColor *eventColor;
-(void)setEventViewColor:(UIColor *)color;
@end
