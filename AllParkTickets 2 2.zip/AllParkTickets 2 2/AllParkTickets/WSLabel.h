//
//  WSLabel.h
//  CalendarDemo
//
//  Created by Dotsquares on 2/15/17.
//  Copyright © 2017 Dotsquares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSLabel : UILabel

@property (nonatomic,strong) NSDate *linkedDate;

@end
