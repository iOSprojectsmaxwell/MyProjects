//
//  WebManager.h
//  Gangadhar
//
//  Created by Gangadhar on 06/10/15.
//  Copyright (c) 2015 Gangadhar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface WebManager : NSObject

//*************Search**************
+(void)callAPIdict:(NSString *)flag parameter:(NSDictionary *)dict  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;
+(void)callAPI:(NSString *)flag Data:(NSString *)data delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;
+(void)callAPIForSuccessMsg:(NSString *)flag Data:(NSString *)data delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;

+(void)callAPIWIthImage:(NSString *)flag parameter:(NSDictionary *)dict Image:(UIImage *)imageFile keyimage:(NSString *)imagekey delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;
+(void)CALLIDEAL:(NSString *)flag  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;
+(void)callAPIdictGet:(NSString *)flag parameter:(NSDictionary *)dict  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback;
@end
