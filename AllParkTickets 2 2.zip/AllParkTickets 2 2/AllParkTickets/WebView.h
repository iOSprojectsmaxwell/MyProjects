//
//  WebView.h
//  AllParkTickets
//
//  Created by Admin on 7/5/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebView : UIViewController
@property(nonatomic,strong)IBOutlet UIWebView*web;
@end
