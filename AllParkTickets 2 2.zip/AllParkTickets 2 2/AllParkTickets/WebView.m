//
//  WebView.m
//  AllParkTickets
//
//  Created by Admin on 7/5/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "WebView.h"
#import "JSON.h"

@interface WebView ()
{
    
    NSString *webdata;
    NSDictionary *dict2;
    NSArray *response;
    
    NSString *content;
    
   // response":[{"id":"44","category_name":"Dhinam Oru Thirunaamam","upload_type":"Text","title":"Sri Vishnu Sahasranaamam - 043. OM DHATRE NAMA:","content
}

@end

@implementation WebView

- (void)viewDidLoad {
    [super viewDidLoad];
  
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.allparktickets.com/api/tour_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
    response =[dict2 valueForKey:@"response"];
    content =[[response valueForKey:@"content"]objectAtIndex:0];
    //[_web loadHTMLString:content baseURL:nil];
  //  [_web loadHTMLString:[content stringByReplacingOccurrencesOfString:@"\n" withString:@"<br/>"] baseURL:nil];
       // Do any additional setup after loading the view.
    
    [self.web loadHTMLString:content baseURL:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
