//
//  tablviewCell.h
//  AllParkTickets
//
//  Created by Admin on 7/2/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"
#import "FirstView.h"
@interface tablviewCell : UITableViewCell
{
    

}
@property(nonatomic,strong)IBOutlet UILabel *tittlelbl;
@property(nonatomic,strong)IBOutlet UILabel *tittlelbl2;
@property(nonatomic,strong)IBOutlet UILabel *tittlelbl3;
@property(nonatomic,strong)IBOutlet MyImageView *imagevieee;
@property(nonatomic,strong)IBOutlet UILabel *Pricelbl;
@property(nonatomic,strong)IBOutlet UILabel *statelbl;
@property(nonatomic,strong)IBOutlet UILabel *countrylbl;
@property(nonatomic,strong)IBOutlet UIButton *yourbutton;

@property (weak, nonatomic) IBOutlet UILabel *TourName;
@property (weak, nonatomic) IBOutlet UILabel *Adultslbl;
@property (weak, nonatomic) IBOutlet UILabel *childlbl;
@property (weak, nonatomic) IBOutlet UILabel *ordernolbl;

@property (weak, nonatomic) IBOutlet UILabel *Costlbl;
@property (weak, nonatomic) IBOutlet UILabel *Datelbl;
@property (weak, nonatomic) IBOutlet UIButton *btnselect;



@property (weak, nonatomic) IBOutlet UILabel *statuslbl;
@property (weak, nonatomic) IBOutlet UILabel *srno;

@property (weak, nonatomic) IBOutlet UILabel *ordernoslbl;
@property (weak, nonatomic) IBOutlet UILabel *netamountlbl;


@property (weak, nonatomic) IBOutlet UILabel *childnetpricelbl;
@property (weak, nonatomic) IBOutlet UILabel *adultnetpricelbl;

@property (weak, nonatomic) IBOutlet UILabel *childpricelbl;
@property (weak, nonatomic) IBOutlet UILabel *adultpricelbl;
@end
