//
//  BookVC.h
//  Dail4Iyer
//
//  Created by user on 24/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BookVC : UIViewController
<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *scrowlView;
@property(nonatomic,strong)NSString *strservices;
@property(nonatomic,strong)IBOutlet UIView *V1;
@property(nonatomic,strong)IBOutlet UIView *V2;
@property(nonatomic,strong)IBOutlet UIView *V3;
@property(nonatomic,strong)IBOutlet UIView *V4;
@property(nonatomic,strong)IBOutlet UIView *V5;
@property(nonatomic,strong)IBOutlet UIView *V6;
@property(nonatomic,strong)IBOutlet UIView *V7;
@property(nonatomic,strong)IBOutlet UIView *V8;
@property(nonatomic,strong)IBOutlet UIView *V9;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;
@property (weak, nonatomic) IBOutlet UITextField *nameFeild;

@property (weak, nonatomic) IBOutlet UITextField *emailFeild;

@property (weak, nonatomic) IBOutlet UITextField *MobileFeild;
@property (weak, nonatomic) IBOutlet UITextField *PoojaFeild;

@property (weak, nonatomic) IBOutlet UITextField *EventDateFeild;

@property (weak, nonatomic) IBOutlet UITextField *EventTimeFeild;

@property (weak, nonatomic) IBOutlet UITextField *AddressFeild;
@property (weak, nonatomic) IBOutlet UITextField *DescFeild;

@end

NS_ASSUME_NONNULL_END
