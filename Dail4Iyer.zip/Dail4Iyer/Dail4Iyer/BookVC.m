//
//  BookVC.m
//  Dail4Iyer
//
//  Created by user on 24/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "BookVC.h"
#import "Common.h"
#import "SWRevealViewController.h"
#import "RCalendarPickerView.h"
#import "RClockPickerView.h"
#import "DateHelper.h"
#import "MBProgressHUD.h"
#import "JSON.h"
#import "ViewController.h"
@interface BookVC ()<MBProgressHUDDelegate>
{
    NSString *ServiceName;
    NSString *ServicesName;
    NSDictionary *dict2;
    NSString *response;
      MBProgressHUD *HUD;
     NSString *apiURLStr;
}
@property(nonatomic,strong)NSArray *dataSource;
@end

@implementation BookVC

- (void)viewDidLoad {
    [super viewDidLoad];
   
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
   ServicesName = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"ServicesName"];
    
    
    _PoojaFeild.text =ServicesName;
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
    self.navigationController.navigationBar.hidden =NO;
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo copy"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    //
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:98/255.0f
                                       green:4/255.0f
                                        blue:3/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    self.V1.layer.borderWidth = 1.0f;
    self.V1.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V2.layer.borderWidth = 1.0f;
    self.V2.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V3.layer.borderWidth = 1.0f;
    self.V3.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V4.layer.borderWidth = 1.0f;
    self.V4.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V5.layer.borderWidth = 1.0f;
    self.V5.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V6.layer.borderWidth = 1.0f;
    self.V6.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V7.layer.borderWidth = 1.0f;
    self.V7.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V1.layer.borderWidth = 1.0f;
    self.V1.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    self.V1.layer.borderWidth = 1.0f;
    self.V1.layer.borderColor =[UIColor lightGrayColor].CGColor;
    
    ServiceName = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"ServiceName"];
    
    
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)book_Iyer:(id)sender{
    
    if (_nameFeild.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter Your Name"];
    }
    else if (_emailFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Your Email Address"];
    }
    else if (![self NSStringIsValidEmail:_emailFeild.text])
    {
        
        [Common AlertShowWithErrorMsg:@"Please Enter Valid Emaild Address"];
        
    }
    
    else if (_MobileFeild.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter Your Mobile Number"];
    }
    else if (_PoojaFeild.text.length ==0)
    {
   
    }
    else if (_EventDateFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Your Event Date"];
    }
    else if (_EventTimeFeild.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter Your Event Time"];
    }
    else if (_AddressFeild.text.length ==0)
    {
         [Common AlertShowWithErrorMsg:@"Please enter Your Address"];
    }
    else if (_DescFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Your Description"];
    }
    else{
        
        [self calling_webServices];
    }
  
    
}



-(void) viewDidLayoutSubviews
{
    _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,1600);
    
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

-(void)calling_webServices
{
    [HUD show:YES];
   
  
    
    NSString *nameFeildText =[self.nameFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSString *EmailText =[self.emailFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSString *MobileText =[self.MobileFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSString *PoojaText =[self.PoojaFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSString *EventDateText =[self.EventDateFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSString *EventTimeText =[self.EventTimeFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    NSString *AddressText =[self.AddressFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    NSString *DescText =[self.DescFeild.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
   
    
//    http://www.dial4iyer.com/api/book_now.php?name=ramesh&email=ramesh@maxwellglobalsoftware.com&phone=9677127700&service_name=Ayudha%20Pooja&event_date=19-05-2018&event_time=05:00%20PM&address=14,lakshmi%20talkies%20road,%20shenoy%20nagar,%20chennai-600030&description=testing
    
    
   
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        self->apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/book_now.php?name=%@&email=%@&phone=%@&service_name=%@&event_date=%@&event_time=%@&address=%@&description=%@",nameFeildText,EmailText,MobileText,PoojaText,EventDateText,EventTimeText,AddressText,DescText];
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:self->apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        self->dict2=[sampleURL JSONValue];
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            self->response =[dict2 valueForKey:@"response"];
            
            NSLog(@"testing result %@",response);
            
           
            if ([response isEqualToString:@"success"]) {
                [Common AlertShowWithSuccessMsg:@"Thankyou for Booking we will contact you Soon.!"];
                
                self.nameFeild.text =@"";
                self.emailFeild.text=@"";
                self.MobileFeild.text=@"";
                self.PoojaFeild.text=@"";
                self.EventDateFeild.text=@"";
                self.EventTimeFeild.text=@"";
                
                
                ViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
                [self.navigationController pushViewController:controller animated:NO];
                
            }
            else{
                
                [Common AlertShowWithSuccessMsg:@"Please Fill the Feilds Currect Formate"];
            }
            
            
            [self->HUD hide:YES];
        });
    });
    
    
    
    
    
}

-(IBAction)date_select:(id)sender{
    
    
    
    
    
    RCalendarPickerView *calendarPicker = [[RCalendarPickerView alloc]initWithFrame:CGRectMake(0, 0, MainScreenWidth, MainScreenHeight)];
    
    calendarPicker.selectDate = [NSDate date];
    calendarPicker.dataSource = self.dataSource;
    //            calendarPicker.thisTheme =[UIColor blackColor];
    calendarPicker.complete = ^(NSInteger day, NSInteger month, NSInteger year, NSDate *date){
        
        
        
       self->_EventDateFeild.text =[NSString stringWithFormat:@"%ld-%ld-%ld",(long)day,(long)month,(long)year];
    };
    [self.view addSubview:calendarPicker];
}


-(IBAction)analog_select:(id)sender{
    
    
    RClockPickerView *rClockPickerView = [[RClockPickerView alloc]init];
    rClockPickerView.date = [NSDate date];
    //            rClockPickerView.thisTheme =[UIColor blackColor];
    //            rClockPickerView.dateString =@"13:50";
    rClockPickerView.complete = ^(NSInteger hours, NSInteger minutes, NSInteger noon ,float date){
        NSLog(@"%d-%d-%d -%f", (int)hours,(int)minutes,(int)noon,date);
        NSString *alr;
        
        if (noon==0) {
            alr =@"AM";
        }
        else{
           alr =@"PM";
        }
        self->_EventTimeFeild.text =[NSString stringWithFormat:@"%ld:%ld:%@",(long)hours,(long)minutes,alr];
    };
    [self.view addSubview:rClockPickerView];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
