//
//  Common.h
//  iastitva
//
//  Created by APPLE-HOME on 21/06/16.
//  Copyright © 2016 Tushar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Common : NSObject<UIAlertViewDelegate>
+(void)AlertShowWithErrorMsg:(NSString *)msg;
+ (UIColor *)colorwithHexString:(NSString *)hexStr alpha:(CGFloat)alpha;
+(void)AlertShowWithSuccessMsg:(NSString *)msg;
+(NSMutableDictionary *)removenullvalue:(NSMutableDictionary *)Dictionary;
+(CAGradientLayer *) gradientLayerForBounds:(CGRect)Bounds;
@end
