//
//  ContactUS.m
//  Dail4Iyer
//
//  Created by user on 28/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ContactUS.h"
#import "SWRevealViewController.h"
@interface ContactUS ()

@end

@implementation ContactUS

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.hidden =NO;
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo copy"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    //
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:98/255.0f
                                       green:4/255.0f
                                        blue:3/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
