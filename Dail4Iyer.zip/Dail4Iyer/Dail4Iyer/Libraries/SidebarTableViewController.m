//
//  SidebarTableViewController.m
//  SidebarDemo
//
//  Created by Simon Ng on 10/11/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import "SidebarTableViewController.h"
#import "SWRevealViewController.h"
#import "TittleCell.h"
#import "ViewController.h"
#import "ServicesVC.h"
#import "ViewController.h"
#import "AboutUsVC.h"
#import "ContactUS.h"

//#import "MyImageView.h"
//#import "NSString+HTML.h"
//#import "home.h"
//#import "FeedbackVC.h"
//#import "AboutUsVC.h"
//#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import <FBSDKLoginKit/FBSDKLoginKit.h>
//#import <GoogleSignIn/GoogleSignIn.h>
//#import "LoginView.h"
//#import "PaymentGetWayVC2.h"



@interface SidebarTableViewController ()
{
    NSString *image;
    NSString *profilename;
    int selectedCell;
    NSString *srt;
    NSString *storeselect;
    int se;
    
}


@end

@implementation SidebarTableViewController {
    NSArray *menuItems;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    se =1;
    storeselect = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"SelectedCell"];
    profilename= [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"user"];
    image= [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"Profile_image"];
   
    menuItems = @[@"title", @"news", @"comments", @"map", @"calendar", @"wishlist", @"bookmark",@"tag"];
    
    static NSString *CellIdentifier1 = @"tittle";
    
    UINib *nib = [UINib nibWithNibName:@"tittle" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CellIdentifier1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return menuItems.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    int se =[storeselect intValue];
    
    
    storeselect = [[NSUserDefaults standardUserDefaults]
                   stringForKey:@"SelectedCell"];
    
    if (indexPath.row ==0) {
        static NSString *CellClassName = @"TittleCell";
        
        TittleCell *cell = (TittleCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
        
        
        if (cell == nil)
        {
            cell = [[TittleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TittleCell"
                                                         owner:self options:nil];
            cell = [nib objectAtIndex:0];
            
        }
  
       // cell.iamgaevvieww.layer.cornerRadius = cell.iamgaevvieww.frame.size.height/2;
        cell.lblr.text =profilename;
        
        if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
           // cell.iamgaevvieww.layer.cornerRadius = 25;
        }else{
           //cell.iamgaevvieww.layer.cornerRadius = 58;
        }
    
       
//        _imageview=(MyImageView*)[cell viewWithTag:1];
//    cell.iamgaevvieww.layer.masksToBounds = YES;
//        [_imageview addImageFrom:[image stringByURLDecode] isRound:YES isActivityIndicator:YES];
//
//        if (se == indexPath.row) {
//            cell.backgroundColor =[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1];
//            cell.lblr.textColor =[UIColor whiteColor];
//        }
//        else{
//              cell.backgroundColor =[UIColor clearColor];
//            
//        }
//        
        return cell;
    }
    else{
        NSString *CellIdentifier = [menuItems objectAtIndex:indexPath.row];
       UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        
//        if (se == indexPath.row) {
//            cell.backgroundColor =[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1];
//            cell.textLabel.textColor = [UIColor whiteColor];
//        }
//        else{
//            cell.backgroundColor =[UIColor clearColor];
//             cell.textLabel.textColor = [UIColor clearColor];
//        }
//
//           cell.textLabel.textColor = [UIColor whiteColor];
           return cell;
    }
    
   
 
}
- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row){
        case 0:
            if(indexPath.row==0)
                
                if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
                  return 170.0;
                }else{
                   return 170.0;
                }
                
                 // first row is 123pt high
        default:
            if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
               return 100.0;
            }else{
              return 50.0;
            }
             // all other rows are 40pt high
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    NSLog(@"index %ld",indexPath.row);
    
    
    if (indexPath.row ==0) {
        
    }
    else{
    
    ; NSString *CellIdentifier = [menuItems objectAtIndex:indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        cell.textLabel.textColor = [UIColor whiteColor];
    
    
    selectedCell =(int)indexPath.row;
    
    srt =[NSString stringWithFormat:@"%d",selectedCell];
    [[NSUserDefaults standardUserDefaults] setObject:srt forKey:@"SelectedCell"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.tableView reloadData];
    
    if (indexPath.row ==1) {
        if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ipadMain" bundle:nil];
            ViewController *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ViewController"];

            UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
            [navController setViewControllers: @[rootViewController] animated: YES];

            [self.revealViewController setFrontViewController:navController];
            [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        }else{
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ViewController *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
        
            
            UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
            [navController setViewControllers: @[rootViewController] animated: YES];
            
            [self.revealViewController setFrontViewController:navController];
            [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        }
        
       
    }
    else if (indexPath.row ==2)
    {
        
        if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ipadMain" bundle:nil];
//        FeedbackVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"FeedbackVC"];
//
//        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
//        [navController setViewControllers: @[rootViewController] animated: YES];
//
//        [self.revealViewController setFrontViewController:navController];
//        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
            
        }else{
            
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AboutUsVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"AboutUsVC"];
        
        
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
        [navController setViewControllers: @[rootViewController] animated: YES];
        
        [self.revealViewController setFrontViewController:navController];
        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        }
     
        
    }
    else if (indexPath.row ==3)
    {
        
         if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
//        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ipadMain" bundle:nil];
//        PaymentGetWayVC2 *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"PaymentGetWayVC2"];
//        
//        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
//        [navController setViewControllers: @[rootViewController] animated: YES];
//
//        [self.revealViewController setFrontViewController:navController];
//        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
         }
         else{
             UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
             ServicesVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ServicesVC"];
             NSString *Services =@"POOJA";
             rootViewController.Services =Services;
             

             UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
             [navController setViewControllers: @[rootViewController] animated: YES];

             [self.revealViewController setFrontViewController:navController];
             [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
             
         }
        
        
    }
    else if (indexPath.row ==4)
    {
        
         if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ipadMain" bundle:nil];
//        AboutUsVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"AboutUsVC"];
//
//        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
//        [navController setViewControllers: @[rootViewController] animated: YES];
//
//        [self.revealViewController setFrontViewController:navController];
//        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
         }
         else{
             
             UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
             ServicesVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ServicesVC"];
             NSString *Services =@"HOMAM";
             rootViewController.Services =Services;
             UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
             [navController setViewControllers: @[rootViewController] animated: YES];
             
             [self.revealViewController setFrontViewController:navController];
             [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
         }
        
        
    }
    else if (indexPath.row ==6)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ServicesVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ServicesVC"];
        NSString *Services =@"ASTRO";
        rootViewController.Services =Services;
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
        [navController setViewControllers: @[rootViewController] animated: YES];
        
        [self.revealViewController setFrontViewController:navController];
        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        
        
    }
    else if (indexPath.row ==5)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ServicesVC *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ServicesVC"];
        
        NSString *Services =@"CER";
        rootViewController.Services =Services;
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
        [navController setViewControllers: @[rootViewController] animated: YES];
        
        [self.revealViewController setFrontViewController:navController];
        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        
        
    }
    else if (indexPath.row ==0)
    {
        
        
    }
    else if (indexPath.row ==7)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ContactUS *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"ContactUS"];
        
       
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
        [navController setViewControllers: @[rootViewController] animated: YES];
        
        [self.revealViewController setFrontViewController:navController];
        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
        
        
    }
    else if (indexPath.row ==434)
    {
        UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"Log Out"
                                                                      message:@"Are you sure?"
                                                               preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes"
                                                            style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action)
                                    {
                                        /** What we write here???????? **/
//                                        FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
//                                        [loginManager logOut];
//                                        
//                                        [FBSDKAccessToken setCurrentAccessToken:nil];
//                                        
//                                        [[GIDSignIn sharedInstance] signOut];
//                                        
//                                        [[NSUserDefaults standardUserDefaults] setObject:@"Logout" forKey:@"user"];
//                                        [[NSUserDefaults standardUserDefaults] synchronize];
//                                        
//                                        [[NSUserDefaults standardUserDefaults] setObject:@" " forKey:@"Email"];
//                                        [[NSUserDefaults standardUserDefaults] synchronize];
//                                
//                                        [[NSUserDefaults standardUserDefaults] setObject:@" " forKey:@"Profile_image"];
//                                        [[NSUserDefaults standardUserDefaults] synchronize];
//                                        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//                                        LoginView *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginView"];
//
//                                        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
//                                        [navController setViewControllers: @[rootViewController] animated: YES];
//
//                                        [self.revealViewController setFrontViewController:navController];
//                                        [self.revealViewController setFrontViewPosition: FrontViewPositionLeft animated: YES];
                                        
                                        // call method whatever u need
                                    }];
        
        UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * action)
                                   {
                                       /** What we write here???????? **/
                                       NSLog(@"you pressed No, thanks button");
                                       // call method whatever u need
                                   }];
        
        [alert addAction:yesButton];
        [alert addAction:noButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        
        
        
        
    }
    }
    
}


- (void)presentActivityController:(UIActivityViewController *)controller {
    
    // for iPad: make the presentation a Popover
    controller.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:controller animated:YES completion:nil];
    
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    popController.barButtonItem = self.navigationItem.leftBarButtonItem;
    
    // access the completion handler
    controller.completionWithItemsHandler = ^(NSString *activityType,
                                              BOOL completed,
                                              NSArray *returnedItems,
                                              NSError *error){
        // react to the completion
        if (completed) {
            // user shared an item
            NSLog(@"We used activity type%@", activityType);
        } else {
            // user cancelled
            NSLog(@"We didn't want to share anything after all.");
        }
        
        if (error) {
            NSLog(@"An Error occured: %@, %@", error.localizedDescription, error.localizedFailureReason);
        }
    };
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation



@end
