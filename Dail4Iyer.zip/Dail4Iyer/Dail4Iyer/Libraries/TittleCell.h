//
//  TittleCell.h
//  SideMenuVC
//
//  Created by user on 01/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TittleCell : UITableViewCell

@property(nonatomic,strong)IBOutlet UILabel *lblr;
@end
