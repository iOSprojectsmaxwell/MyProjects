//
//  TittleCell.m
//  SideMenuVC
//
//  Created by user on 01/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "TittleCell.h"

@implementation TittleCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
