//
//  ModalViewController.h
//  HYAwesomeTransitionDemo
//
//  Created by nathan on 15/7/30.
//  Copyright (c) 2015年 nathan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ModalViewController;
@protocol ModalViewControllerDelegate <NSObject>
-(void) modalViewControllerDidClickedDismissButton:(ModalViewController *)viewController;
@end

@interface ModalViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UILabel *lblname;
@property (weak, nonatomic) IBOutlet UIView *Vieee;
@property (weak, nonatomic) IBOutlet UIImageView *imagevieww;
@property (nonatomic, weak) id<ModalViewControllerDelegate> delegate;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, strong) NSString *imageUrl;
@property (nonatomic, strong) NSString *Benfites;
@property (nonatomic, strong) NSString *Desc;
@property (nonatomic, strong) NSString *Tittle;

@property (weak, nonatomic) IBOutlet UILabel *benfiteslbl;

@end
