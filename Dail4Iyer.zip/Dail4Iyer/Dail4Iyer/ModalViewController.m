//
//  ModalViewController.m
//  HYAwesomeTransitionDemo
//
//  Created by nathan on 15/7/30.
//  Copyright (c) 2015年 nathan. All rights reserved.
//

#import "ModalViewController.h"
#import "NewVC.h"
#import "BookVC.h"

@interface ModalViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)IBOutlet UIWebView *webvieee;
@property(nonatomic,strong)IBOutlet UIWebView *webvieee1;
@end

@implementation ModalViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _lblname.text =_imageUrl;
    // _Services isEqualToString:@"ASTRO"
    if ([_Tittle isEqualToString:@"ASTRO"]) {
        _benfiteslbl.text =@"Reasons";
    }
    else{
    
        
    }
      NSLog(@"_Benfites %@",_Benfites);
    
    [[NSUserDefaults standardUserDefaults] setObject:_lblname.text forKey:@"ServicesName"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [_Vieee.layer setMasksToBounds:NO];
    [_Vieee.layer setShadowColor:[[UIColor blackColor] CGColor]];
    [_Vieee.layer setShadowOpacity:0.6f];
    [_Vieee.layer setShadowRadius:10.0f];
    [_Vieee.layer setCornerRadius:4.0f];
    [_Vieee.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
    NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[_Desc dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    
    NSLog(@"Main %@",attrStr);
    
    NSString *gfdfd =[NSString stringWithFormat:@"%@",attrStr];
    // NSLog(@"htmlString %@",gfdfd);
    
    NSArray *dddggf =[gfdfd componentsSeparatedByString:@"</html>"];
    
    NSString *actualstring =[NSString stringWithFormat:@"%@</html>",[dddggf objectAtIndex:0]];
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
       
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
             [_webvieee loadHTMLString:actualstring baseURL:nil];
            //  [HUD hide:YES];
        });
    });
    
    
    
    
    NSAttributedString * attrStr1 = [[NSAttributedString alloc] initWithData:[_Benfites dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    
    NSLog(@"Main %@",attrStr1);
    
    NSString *gfdfd1 =[NSString stringWithFormat:@"%@",attrStr1];
    // NSLog(@"htmlString %@",gfdfd);
    
    NSArray *dddggf1 =[gfdfd1 componentsSeparatedByString:@"</html>"];
    
    NSString *actualstring1 =[NSString stringWithFormat:@"%@</html>",[dddggf1 objectAtIndex:0]];
    
    dispatch_queue_t queue1 = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue1, ^{
        // data processing
      
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            [_webvieee1 loadHTMLString:actualstring1 baseURL:nil];
            //  [HUD hide:YES];
        });
    });
    
    
    
   
        UIImage* image3 = [UIImage imageNamed:@"Backorg"];
        CGRect frameimg = CGRectMake(-10, 0, 20, 20);
        UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
        [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
        [someButton addTarget:self action:@selector(sendmail)
             forControlEvents:UIControlEventTouchUpInside];
        [someButton setShowsTouchWhenHighlighted:YES];
    
        UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
        self.navigationItem.leftBarButtonItem=mailbutton;
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo copy"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    //
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:98/255.0f
                                       green:4/255.0f
                                        blue:3/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
  
  [self.navigationController setNavigationBarHidden:NO animated:YES];
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
   
  [self.navigationController setNavigationBarHidden:NO animated:YES];
}
-(IBAction)Book:(id)sender{
    BookVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"BookVC"];
    [self.navigationController pushViewController:controller animated:NO];
    
}
- (IBAction)backClicked:(id)sender {
    if (self.navigationController) {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(modalViewControllerDidClickedDismissButton:)]) {
            [self.delegate modalViewControllerDidClickedDismissButton:self];
        }
    }
}

@end
