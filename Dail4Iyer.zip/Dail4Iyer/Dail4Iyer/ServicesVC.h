//
//  ServicesVC.h
//  Dail4Iyer
//
//  Created by user on 24/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ServicesVC : UIViewController
@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;
@property (weak, nonatomic) IBOutlet UILabel *Tittle_lbl;
@property (weak, nonatomic)NSString *Services;

@end

NS_ASSUME_NONNULL_END
