//
//  ServicesVC.m
//  Dail4Iyer
//
//  Created by user on 24/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ServicesVC.h"
#import "SWRevealViewController.h"
#import "Common.h"
#import "HYAwesomeTransition.h"
#import "ModalViewController.h"
#import "CustomCell.h"
#import "Common.h"
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "BookVC.h"

@interface ServicesVC ()
<UICollectionViewDataSource,UICollectionViewDelegate,UIViewControllerTransitioningDelegate,ModalViewControllerDelegate,UINavigationControllerDelegate,MBProgressHUDDelegate>
{
      NSString *apiURLStr;
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSArray *services;
    NSArray *ids;
    NSArray *category;
    NSArray *data;
     NSArray *Data;
    NSArray *service_name;
    NSArray *service_image;
    CGFloat width;
    NSArray *description;
    NSArray *benifits;
    
    
}


@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) HYAwesomeTransition *awesometransition;
@property (nonatomic, strong) NSMutableArray *imagesArray;


@property(nonatomic,strong)IBOutlet MyImageView *image1;
@end

@implementation ServicesVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
//    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
//    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
//    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
//    [someButton addTarget:self action:@selector(sendmail)
//         forControlEvents:UIControlEventTouchUpInside];
//    [someButton setShowsTouchWhenHighlighted:YES];
//    
//    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
//    self.navigationItem.leftBarButtonItem=mailbutton;
    self.navigationController.navigationBar.hidden =NO;
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    [self Get_Services];
    
//    UIImage* image3 = [UIImage imageNamed:@"backk"];
//    CGRect frameimg = CGRectMake(0, 0, 20, 20);
//    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
//    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
//    [someButton addTarget:self action:@selector(sendmail)
//         forControlEvents:UIControlEventTouchUpInside];
//    [someButton setShowsTouchWhenHighlighted:YES];
//
//    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
//    self.navigationItem.leftBarButtonItem=mailbutton;
    
    self.imagesArray = @[].mutableCopy;
    for (int i = 0; i < 30; i++) {
        [self.imagesArray addObject:@"Ayyappa Swamy Pooja"];
    }
    [self.imagesArray replaceObjectAtIndex:10 withObject:@"Ayyappa Swamy Pooja"];
    
    self.awesometransition = [[HYAwesomeTransition alloc] init];
    self.awesometransition.type = HYTransitionTypeNavigation;
    self.awesometransition.duration = 0.5f;
    self.awesometransition.containerBackgroundView = ({
        UIView *bgView = (UIView *)[[[NSBundle mainBundle] loadNibNamed:@"ContainerBackgroundView" owner:nil options:nil] lastObject];
        bgView;
    });
    
  
    
    
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo copy"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    //
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:98/255.0f
                                       green:4/255.0f
                                        blue:3/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)Get_Services
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
  
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        
        if ([_Services isEqualToString:@"POOJA"]) {
            
            _Tittle_lbl.text =@"POOJA SERVICES";
            apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/pooja_services.php"];
        }
        else if ([_Services isEqualToString:@"CER"])
        {
            _Tittle_lbl.text =@"CEREMONIES SERVICES";
         apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/ceremonies.php"];
        }
        else if ([_Services isEqualToString:@"ASTRO"])
        {
            _Tittle_lbl.text =@"ASTROLOGY";
           apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/astrology.php"];
        }
        else if ([_Services isEqualToString:@"HOMAM"])
        {
            _Tittle_lbl.text =@"HOMAM SERVICES";
         apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/homam_services.php"];
        }
        else{
        
      apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/services.php"];
        }
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        self->dict2=[sampleURL JSONValue];
        NSLog(@"Login Details %@",self->dict2);
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if ([_Services isEqualToString:@"CER"])
            {
               services =[dict2 valueForKey:@"response"];
                Data =[services valueForKey:@"data"];
            }
            else if ([_Services isEqualToString:@"ASTRO"])
            {
                 services =[dict2 valueForKey:@"response"];
                Data =[services valueForKey:@"data"];
            }
            else if ([_Services isEqualToString:@"POOJA"])
            {
                services =[dict2 valueForKey:@"response"];
                Data =[services valueForKey:@"data"];
            }
            else if ([_Services isEqualToString:@"HOMAM"])
            {
                services =[dict2 valueForKey:@"response"];
                Data =[services valueForKey:@"data"];
            }
            else{
                  Data =[dict2 valueForKey:@"services"];
               
            }
            
          
            
            ids =[Data valueForKey:@"id"];
            service_name =[Data valueForKey:@"service_name"];
            description  =[Data valueForKey:@"description"];
           if ([_Services isEqualToString:@"ASTRO"])
            {
               benifits =[Data valueForKey:@"reason"];
            }
           else{
               benifits =[Data valueForKey:@"benifits"];
           }
           // benifits =[Data valueForKey:@"benifits"];
            service_image =[Data valueForKey:@"service_image"];
            [_collectionView reloadData];
            
            [HUD hide:YES];
            
        });
    });
    
    
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat height = self.view.frame.size.height;
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                width  = self.view.frame.size.width+20;
                
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                width  = self.view.frame.size.width+50;
                
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                
                width  = self.view.frame.size.width+55;
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
                
                width  = self.view.frame.size.width+60;
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
                
                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }
        
    }
    //width  = self.view.frame.size.width+60;
    // in case you you want the cell to be 40% of your controllers view
    return CGSizeMake(width * 0.4, height * 0.3);
}
#pragma mark - collectionView


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ReuseIdentifier = @"CustomMainCell";
    CustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ReuseIdentifier forIndexPath:indexPath];
    
    // _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[service_image objectAtIndex:indexPath.row];
    
    // NSLog(@"path %@",path);
    
    //[_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:path]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            // WARNING: is the cell still using the same data by this point??
            cell.imageView.image = [UIImage imageWithData: data];
        });
        
    });
    
//    [cell.baseView.layer setMasksToBounds:NO];
//    [cell.baseView.layer setShadowColor:[[UIColor grayColor] CGColor]];
//    [cell.baseView.layer setShadowOpacity:0.6f];
//    [cell.baseView.layer setShadowRadius:10.0f];
//    [cell.baseView.layer setCornerRadius:4.0f];
//    [cell.baseView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
    //  cell.imageView.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
    cell.NameLbl.text =[service_name objectAtIndex:indexPath.row];
    
    cell.FullimageView.hidden =YES;
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return service_image.count;
}


- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 2.0, 10, 2.0);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    
    
    static NSString *ReuseIdentifier = @"CustomMainCell";
    CustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ReuseIdentifier forIndexPath:indexPath];
    cell.FullimageView.hidden =NO;
    // cell1.imageView.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
    
    
    
    if (self.awesometransition.type == HYTransitionTypeModal) {
        
        ModalViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ModalViewController"];
        vc.imageName = service_image[indexPath.row];
        vc.transitioningDelegate = self;
        vc.delegate              = self;
        
        CGRect startFrame = [cell convertRect:cell.bounds toView:self.view];
        CGRect finalFrame = CGRectMake(40, 150, 100, 100);
        
        [self.awesometransition registerStartFrame:startFrame
                                        finalFrame:finalFrame transitionView:cell];
        
        [self presentViewController:vc animated:YES completion:^{
            vc.avatar.hidden = NO;
            vc.avatar.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
        }];
    } else {
        ModalViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ModalViewController"];
        
        vc.imageName = service_image[indexPath.row];
         vc.Desc = description[indexPath.row];
           vc.imageUrl = service_name[indexPath.row];
         vc.Benfites = benifits[indexPath.row];
        vc.Tittle =_Services;
       
        vc.delegate              = self;
        
        
        
        [[NSUserDefaults standardUserDefaults] setObject:service_name[indexPath.row] forKey:@"ServiceName"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        CGRect startFrame = [cell convertRect:cell.bounds toView:self.view];
        CGRect finalFrame = CGRectMake(40, 150, 100, 50);
        
        [self.awesometransition registerStartFrame:startFrame
                                        finalFrame:finalFrame transitionView:cell];
        
        
        vc.imagevieww.hidden =NO;
        
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:self->service_image[indexPath.row]]];
            if ( data == nil )
                return;
            dispatch_async(dispatch_get_main_queue(), ^{
                // WARNING: is the cell still using the same data by this point??
                vc.imagevieww.image = [UIImage imageWithData:data];
            });
            
        });
        
        self.navigationController.delegate = self;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
}



- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    self.awesometransition.present = NO;
    return self.awesometransition;
}

// If you use UINavigationController, you have to implement UINavigationControllerDelegate
// instead of UIViewControllerTransitioningDelegate

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC{
    
    self.awesometransition.type = HYTransitionTypeNavigation;
    if (operation == UINavigationControllerOperationPush) {
        self.awesometransition.present = YES;
    } else {
        self.awesometransition.present = NO;
    }
    return self.awesometransition;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
