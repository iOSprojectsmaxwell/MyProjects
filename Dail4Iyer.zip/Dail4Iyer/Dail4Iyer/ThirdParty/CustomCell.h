//
//  CustomCell.h
//  HYAwesomeTransitionDemo
//
//  Created by why on 16/2/14.
//  Copyright © 2016年 nathan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

@interface CustomCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *NameLbl;
@property (weak, nonatomic) IBOutlet UIView *baseView;
@property (weak, nonatomic) IBOutlet UIImageView *FullimageView;

@end
