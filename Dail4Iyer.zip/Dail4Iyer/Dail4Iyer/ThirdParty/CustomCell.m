//
//  CustomCell.m
//  HYAwesomeTransitionDemo
//
//  Created by why on 16/2/14.
//  Copyright © 2016年 nathan. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [_baseView.layer setMasksToBounds:NO];
    [_baseView.layer setShadowColor:[[UIColor blackColor] CGColor]];
    [_baseView.layer setShadowOpacity:0.6f];
    [_baseView.layer setShadowRadius:10.0f];
    [_baseView.layer setCornerRadius:4.0f];
    [_baseView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
//    _baseView.layer.cornerRadius = 6;
//    _baseView.layer.shadowColor =[[UIColor blackColor] CGColor];
//    _baseView.layer.shadowOffset = CGSizeMake(0.5, 4.0); //Here your control your spread
//    _baseView.layer.shadowOpacity = 0.5;
//    _baseView.layer.shadowRadius = 5.0;
    
   
    // Initialization code
}

@end
