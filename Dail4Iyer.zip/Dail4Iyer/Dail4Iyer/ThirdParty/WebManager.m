//
//  WebManager.m
//  Gangadhar
//
//  Created by Gangadhar on 06/10/15.
//  Copyright (c) 2015 Gangadhar. All rights reserved.

#import "WebManager.h"
#import "JSON.h"

NSString *Mainurl = @"http://gnaritus.com/clients/gurukula/manage/";
@implementation WebManager
+(void)callAPIdictGet:(NSString *)flag parameter:(NSDictionary *)dict  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{
    NSError *error;
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:delegate delegateQueue:nil];
    NSURL * url = [NSURL URLWithString:[ NSString stringWithFormat:@"%@/%@",Mainurl,flag]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:60.0];
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [request setHTTPMethod:@"GET"];
    
   // http://tech599.com/tech599.com/johngov/ameristarr_ambulance/api/get_all_usernames.php
    NSData *postData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:&error];
    [request setHTTPBody:postData];
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                          
    {
        
        if(error == nil)
        {
            NSString * text = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
            NSLog(@"Data = %@",text);
            SBJsonParser * parser = [[SBJsonParser alloc] init];
            NSDictionary *getMessage = [parser objectWithString:text];
            
            BOOL status = [[getMessage objectForKey:@"success"] boolValue];
            if (status == YES)
            {
                if ([delegate respondsToSelector:successCallback])
                {
                    
                    [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
                }
                
            }
            else
            {
                if ([delegate respondsToSelector:failureCallback])
                {
                    [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
                }
            }
        }
        
    }];
    
    [postDataTask resume];
}
+(void)callAPIdict:(NSString *)flag parameter:(NSDictionary *)dict  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{
NSError *error;

NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:delegate delegateQueue:nil];
NSURL * url = [NSURL URLWithString:[ NSString stringWithFormat:@"%@/%@",Mainurl,flag]];
NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                       cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                   timeoutInterval:60.0];

[request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
[request addValue:@"application/json" forHTTPHeaderField:@"Accept"];

[request setHTTPMethod:@"POST"];


NSData *postData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:&error];
[request setHTTPBody:postData];


NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                      
{
    
    if(error == nil)
       {
           NSString * text = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
           NSLog(@"Data = %@",text);
           SBJsonParser * parser = [[SBJsonParser alloc] init];
           NSDictionary *getMessage = [parser objectWithString:text];
           
           BOOL status = [[getMessage objectForKey:@"success"] boolValue];
           if (status == YES)
           {
               if ([delegate respondsToSelector:successCallback])
               {
                   
                   [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
               }
               
           }
           else
           {
               if ([delegate respondsToSelector:failureCallback])
               {
                   [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
               }
           }
       }
    
    }];

  [postDataTask resume];
}
+(void)callAPIWIthImage:(NSString *)flag parameter:(NSDictionary *)dict Image:(UIImage *)imageFile keyimage:(NSString *)imagekey delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{
  
//    NSString *urlstr=[[NSString stringWithFormat:@"%@/%@",Mainurl,flag] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
//    int number = (arc4random()%1000000)+1;
//    NSString *string = [NSString stringWithFormat:@"%i.png", number];
//     NSData * stringData = [urlstr dataUsingEncoding:NSUTF8StringEncoding];
//    // add image data
//  
//    
//    NSData *imageData = UIImageJPEGRepresentation(imageFile, 1.0);
//    NSMutableData *completeData = [[NSMutableData alloc] initWithBytes:[stringData bytes] length:[stringData length]];
//    [completeData appendData:imageData];
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
//     manager.responseSerializer = [AFHTTPResponseSerializer serializer];
////  NSMutableSet *contentTypes = [[NSMutableSet alloc] initWithSet:manager.responseSerializer.acceptableContentTypes];
////    [contentTypes addObject:@"text/html"];
////       [contentTypes addObject:@"application/json"];
////     [contentTypes addObject:@"text/json"];
////    [contentTypes addObject:@"text/javascript"];
//   
//  //  manager.responseSerializer.acceptableContentTypes = contentTypes;
//   [manager.requestSerializer setTimeoutInterval:100.0];
//    [manager POST:urlstr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//        
//        [formData appendPartWithFileData:imageData name:imagekey fileName:string mimeType:@"image/png"];
//    }
//         progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
//        NSLog(@"Response: %@", responseObject);
//        NSString *responseString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        SBJsonParser * parser = [[SBJsonParser alloc] init];
//        NSDictionary *getMessage = [parser objectWithString:responseString];
//        
//        BOOL status = [[getMessage objectForKey:@"success"] boolValue];
//        if (status == YES)
//        {
//            if ([delegate respondsToSelector:successCallback])
//            {
//                
//                [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
//            }
//            
//        }
//        else
//        {
//            if ([delegate respondsToSelector:failureCallback])
//            {
//                [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
//            }
//        }
//
//    } failure:^(NSURLSessionDataTask *task) {
//       
//        NSMutableDictionary *dict1 = [NSMutableDictionary dictionary];
//        [dict1 setValue:@"Check your network" forKey:@"Error"];
//        
//        [delegate performSelectorOnMainThread:failureCallback withObject:dict1 waitUntilDone:YES];
//    }];
}

+(void)CALLIDEAL:(NSString *)flag  delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{

     NSURL *url =[NSURL URLWithString:[[NSString stringWithFormat:@"%@/%@",Mainurl,flag] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
     NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
     [request setURL:url];
    [request setHTTPMethod:@"GET"];
     NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
     [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    __block NSDictionary *getMessage =[[NSDictionary alloc]init];
    NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    SBJsonParser * parser = [[SBJsonParser alloc] init];
    getMessage = [parser objectWithString:responseString];
    
    if ([[getMessage objectForKey:@"success"] boolValue]==YES)
    {
        if ([delegate respondsToSelector:successCallback])
        {
            [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
        }
    }
    else
    {
        if ([delegate respondsToSelector:failureCallback])
        {
            [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
        }
    }
    
    }]resume];
}

+(void)callAPI:(NSString *)flag Data:(NSString *)data delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{
    NSString *urlSTR=[[NSString stringWithFormat:@"%@/%@",Mainurl,flag] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    NSData *parameterData = [data dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSLog(@"flag --- %@",flag);
    
    NSLog(@"urlString --- %@",data);
    __block NSDictionary *getMessage =[[NSDictionary alloc]init];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlSTR] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:100.0];
    
    [request setURL:[NSURL URLWithString:urlSTR]];
    [request setHTTPMethod:@"POST"];
    [request addValue: @"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    [postbody appendData:[NSData dataWithData:parameterData]];
    [request setHTTPBody:postbody];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]completionHandler:
     ^(NSURLResponse* response, NSData* data, NSError *error)
     {
         NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
         SBJsonParser * parser = [[SBJsonParser alloc] init];
         getMessage = [parser objectWithString:responseString];
         

         if ([[getMessage objectForKey:@"message_code"] integerValue]==1)
         {
             if ([delegate respondsToSelector:successCallback])
             {
                 [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
             }
         }
         else
         {
             if ([delegate respondsToSelector:failureCallback])
             {
                 [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
             }
         }
         NSLog(@"response : %@", getMessage);
     }];
}
+(void)callAPIForSuccessMsg:(NSString *)flag Data:(NSString *)data delegate:(id)delegate onSuccess:(SEL)successCallback onFailure:(SEL)failureCallback
{
    NSString *urlSTR=[[NSString stringWithFormat:@"%@%@",Mainurl,flag] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSData *parameterData = [data dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    ;
    NSLog(@"flag --- %@",flag);
    
    NSLog(@"urlString --- %@",parameterData);
    __block NSDictionary *getMessage =[[NSDictionary alloc]init];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlSTR] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:100.0];
    
    [request setURL:[NSURL URLWithString:urlSTR]];
    [request setHTTPMethod:@"POST"];
    [request addValue: @"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    [postbody appendData:[NSData dataWithData:parameterData]];
    [request setHTTPBody:postbody];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]completionHandler:
     ^(NSURLResponse* response, NSData* data, NSError *error)
     {
         NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
         SBJsonParser * parser = [[SBJsonParser alloc] init];
         getMessage = [parser objectWithString:responseString];
         
         if ([[getMessage objectForKey:@"status"] isEqualToString:@"success"])
         {
             if ([delegate respondsToSelector:successCallback])
             {
                 [delegate performSelectorOnMainThread:successCallback withObject:getMessage  waitUntilDone:YES];
             }
         }
         else
         {
             if ([delegate respondsToSelector:failureCallback])
             {
                 [delegate performSelectorOnMainThread:failureCallback withObject:getMessage waitUntilDone:YES];
             }
         }
         NSLog(@"response : %@", getMessage);
     }];
}
@end
