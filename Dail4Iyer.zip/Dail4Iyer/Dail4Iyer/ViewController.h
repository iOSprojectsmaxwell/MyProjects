//
//  ViewController.h
//  Dail4Iyer
//
//  Created by user on 22/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *scrowlView;
@property (weak, nonatomic) IBOutlet UILabel *lbl1;
@property (weak, nonatomic) IBOutlet UILabel *lbl2;
@property (weak, nonatomic) IBOutlet UILabel *lbl3;
@property (weak, nonatomic) IBOutlet UILabel *lbl4;
@property (weak, nonatomic) IBOutlet UILabel *lbl5;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;
@property (weak, nonatomic) IBOutlet UIImageView *BannerImageview;

@property (weak, nonatomic) IBOutlet UIButton * BtnMore;
@property (weak, nonatomic) IBOutlet UILabel * BtnMorelbl;
@property (weak, nonatomic) IBOutlet UILabel *WelcomeLbl;

@property (weak, nonatomic) IBOutlet UILabel *We;

@property (weak, nonatomic) IBOutlet UILabel *Hightly;

@property (weak, nonatomic) IBOutlet UITextView *TextViews;


@end

