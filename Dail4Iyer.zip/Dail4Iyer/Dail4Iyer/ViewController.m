//
//  ViewController.m
//  Dail4Iyer
//
//  Created by user on 22/09/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ViewController.h"
#import "SWRevealViewController.h"
#import <DCAnimationKit/UIView+DCAnimationKit.h>
#import "VKAdBannerView.h"
#import <iAd/iAd.h>
#import "Common.h"
#import "HYAwesomeTransition.h"
#import "ModalViewController.h"
#import "CustomCell.h"
#import "Common.h"
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "BookVC.h"
#import "ServicesVC.h"
#import <QuartzCore/QuartzCore.h>
#import "AboutUsVC.h"

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
@interface ViewController ()<ADBannerViewDelegate, VKAdBannerViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UIViewControllerTransitioningDelegate,ModalViewControllerDelegate,UINavigationControllerDelegate,MBProgressHUDDelegate>
{
     MBProgressHUD *HUD;
    NSDictionary *dict2;
     NSArray *services;
     NSArray *ids;
    NSArray *category;
     NSArray *service_name;
    NSArray *service_image;
    NSArray *benifits;
    NSArray *description;
    CGFloat width;
    
 
}


@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) HYAwesomeTransition *awesometransition;
@property (nonatomic, strong) NSMutableArray *imagesArray;

@property (strong, nonatomic) ADBannerView *adBannerView;
@property (strong, nonatomic) VKAdBannerView *myBannerView;
@property(nonatomic,strong)IBOutlet MyImageView *image1;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self Get_Services];
    [self setupAdBannerView];
    [self setupMyBannerView];
    self.imagesArray = @[].mutableCopy;
    for (int i = 0; i < 30; i++) {
        [self.imagesArray addObject:@"Ayyappa Swamy Pooja"];
    }
    [self.imagesArray replaceObjectAtIndex:10 withObject:@"Ayyappa Swamy Pooja"];
    
    self.awesometransition = [[HYAwesomeTransition alloc] init];
    self.awesometransition.type = HYTransitionTypeNavigation;
    self.awesometransition.duration = 0.5f;
    self.awesometransition.containerBackgroundView = ({
        UIView *bgView = (UIView *)[[[NSBundle mainBundle] loadNibNamed:@"ContainerBackgroundView" owner:nil options:nil] lastObject];
        bgView;
    });
    [_myBannerView startRotation];
    
    [self.view bringSubviewToFront:_adBannerView];
    _lbl4.hidden= YES;
    _lbl1.hidden =YES;
    _lbl2.hidden =YES;
    _lbl3.hidden =YES;
     _lbl5.hidden =YES;
    
    _We.hidden=YES;
    
    _WelcomeLbl.hidden=YES;
    _Hightly.hidden=YES;
    _TextViews.hidden =YES;
    _BannerImageview.hidden =YES;
    [self banner_Animations];
     _TextViews.hidden=YES;
     [self banner_Animation];
 //[self.lbl2 snapIntoView:self.view direction:DCAnimationDirectionTop];
    //[self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
    self.navigationController.navigationBar.hidden =NO;
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo copy"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
//    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:98/255.0f
                                       green:4/255.0f
                                        blue:3/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)moredetails:(id)sender{
    [Common AlertShowWithErrorMsg:@"developing....."];
}

-(IBAction)select_Services:(id)sender{
    
   [Common AlertShowWithErrorMsg:@"developing....."];
}

-(IBAction)services:(id)sender{
    
    ServicesVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ServicesVC"];
    [self.navigationController pushViewController:controller animated:NO];
}

-(IBAction)about:(id)sender{
    
    AboutUsVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"AboutUsVC"];
    [self.navigationController pushViewController:controller animated:NO];
}
-(void) viewDidLayoutSubviews
{
    
   
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                width  = self.view.frame.size.width+20;
                _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,2100);
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                
               /// 8 566
                
                _collectionView.frame =CGRectMake(8, 566, _collectionView.frame.size.width, _collectionView.frame.size.height-30);
                
                
                
                _BtnMore.frame =CGRectMake(256, 1210, _BtnMore.frame.size.width, _BtnMore.frame.size.height);
                [self.scrowlView addSubview:_BtnMore];
                _BtnMorelbl.frame =CGRectMake(256, 1210, _BtnMorelbl.frame.size.width, _BtnMorelbl.frame.size.height);
                     [self.scrowlView addSubview:_BtnMorelbl];
               // [self.BtnMore addSubview:_collectionView];
                [self.scrowlView addSubview:_collectionView];
            _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,2700);
                
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                 _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,3000);
               
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
                
                  _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,2950);
              
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
                  _scrowlView.contentSize = CGSizeMake(_scrowlView.frame.size.width,3200);
                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }
  
    }
}

-(IBAction)Book_Iyer:(id)sender{
    
    BookVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"BookVC"];
    [self.navigationController pushViewController:controller animated:NO];
}

-(void)Get_Services
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.dial4iyer.com/api/services.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        self->dict2=[sampleURL JSONValue];
        NSLog(@"Login Details %@",self->dict2);
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
        
            
                services =[dict2 valueForKey:@"services"];
            
              ids =[services valueForKey:@"id"];
            service_name =[services valueForKey:@"service_name"];
            description  =[services valueForKey:@"description"];
            benifits =[services valueForKey:@"benifits"];
              service_image =[services valueForKey:@"service_image"];
            
            [_collectionView reloadData];
            
            [HUD hide:YES];
            
        });
    });
    
    
    
}

-(void)setupAdBannerView
{
    _adBannerView = [[ADBannerView alloc] initWithFrame:CGRectZero];
    _adBannerView.frame = CGRectOffset(_adBannerView.frame, 0, [UIScreen mainScreen].bounds.size.height - CGRectGetHeight(_adBannerView.frame));
    _adBannerView.backgroundColor = [UIColor clearColor];
    [_adBannerView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [_adBannerView setAlpha:0];
    _adBannerView.delegate = self;
    
    [self.view addSubview:_adBannerView];
}

-(void)setupMyBannerView
{
    
    // Init VKAdBannerView with Apple's iAd frame
    // You can call [VKAdBannerView defaultiPhoneFrame:] or [VKAdBannerView defaultiPadFrame:] if you don't use iAd
    _myBannerView = [[VKAdBannerView alloc] initWithFrame:_adBannerView.frame];
    _myBannerView.delegate = self;
    
    // First Ad Content
    VKAdBannerContent *adContentCities = [[VKAdBannerContent alloc] init];
    
    adContentCities.icon = [UIImage imageNamed:@"services.png"];
    adContentCities.iconBorderColor = [UIColor colorWithWhite:0.5 alpha:1];
    
    adContentCities.title = @"Daily4Iyer";
    adContentCities.titleColor = UIColorFromRGB(0xda4936);
    
    adContentCities.descriptionText  = [NSString stringWithFormat:@"NEED IYER FOR POOJA ?? %@", [UIDevice currentDevice].model];
    adContentCities.descriptionColor = UIColorFromRGB(0x3b3b3b);
    
    adContentCities.price = [NSString stringWithFormat:@"Call Us %@", @"7306673066"];
    adContentCities.priceColor = UIColorFromRGB(0x3b3b3b);
    
    adContentCities.url = [NSURL URLWithString:@"http://www.dial4iyer.com/index.php"];
    adContentCities.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navigation"]];
    
 
    // Second Ad Content
    VKAdBannerContent *adContentMyHeartbeat = [[VKAdBannerContent alloc] init];
    
    adContentMyHeartbeat.icon = [UIImage imageNamed:@"services.png"];
    
    adContentMyHeartbeat.title = @"Daily4Iyer";
    adContentMyHeartbeat.titleColor = UIColorFromRGB(0x00b1d1);
    
    adContentMyHeartbeat.descriptionText  = @"NEED IYER FOR POOJA ??";
    adContentMyHeartbeat.descriptionColor = [UIColor whiteColor];
    
    adContentMyHeartbeat.price = @"7306673066";
    adContentMyHeartbeat.priceColor = [UIColor greenColor];
    
    adContentMyHeartbeat.url = [NSURL URLWithString:@"http://www.dial4iyer.com/index.php"];
    adContentMyHeartbeat.backgroundColor  = [UIColor blackColor];
    
    
    // Third Ad Content
    VKAdBannerContent *adContentMusic = [[VKAdBannerContent alloc] init];
    
    adContentMusic.title = @"Daily4Iyer";
    adContentMusic.titleColor = UIColorFromRGB(0xff3366);
    
    adContentMusic.descriptionText  = @"we are having highly experienced iyers from all over india !";
    adContentMusic.descriptionColor = UIColorFromRGB(0x00b1d1);
    
    adContentMusic.price = @"7306673066";;
    adContentMusic.priceColor = [UIColor whiteColor];
    
    adContentMusic.url = [NSURL URLWithString:@"http://www.dial4iyer.com/index.php"];
    adContentMusic.backgroundColor  = [UIColor blackColor];
    
    adContentMusic.icon = [UIImage imageNamed:@"customizeServices.png"];
    adContentMusic.iconBorderColor = [UIColor clearColor];
    
    
    // Add created content to your
    [_myBannerView setAdContent:@[adContentCities, adContentMyHeartbeat, adContentMusic]];
    [_myBannerView setRotationTime:6.];
    [_myBannerView setRotationType:VKAdBannerViewRotationTypeRandom];
    
    [self.view addSubview:_myBannerView];
}

#pragma mark - ADBannerViewDelegate

-(void)bannerViewWillLoadAd:(ADBannerView *)banner {}

-(void)bannerViewDidLoadAd:(ADBannerView *)banner
{
    [self setAdBannerViewVisible:YES];
}

-(void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [self setAdBannerViewVisible:NO];
}

-(void)setAdBannerViewVisible:(BOOL)visible
{
    if (visible)
        [_myBannerView stopRotation];
    else
        [_myBannerView startRotation];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.adBannerView.alpha = visible ? 1. : .0;
        self.myBannerView.alpha = visible ? .0 : 1.;
    }];
}

#pragma mark - VKAdBannerViewDelegate

-(void)VKAdBannerView:(VKAdBannerView *)adBannerView didRotateContent:(VKAdBannerContent *)content
{
    NSLog(@"Did show next content: %@", content.title);
}

-(void)VKAdBannerView:(VKAdBannerView *)adBannerView willOpenURL:(NSURL *)url
{
    NSLog(@"Will open URL: %@", url);
}

-(void)banner_Animations
{
    _lbl1.hidden =NO;
    
    [_lbl1 setAlpha:0.0];
    [UIView animateWithDuration:1.0
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_lbl1 setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {_lbl1.hidden =NO;
              [self banner_Animations1];
            // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:4
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                 // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}
- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat height = self.view.frame.size.height;
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                width  = self.view.frame.size.width+20;
             
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                width  = self.view.frame.size.width+50;
               
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                
               width  = self.view.frame.size.width+55;
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
                
               width  = self.view.frame.size.width+60;
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
               
                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }
     
    }
    
    
    
    // in case you you want the cell to be 40% of your controllers view
    return CGSizeMake(width * 0.4, height * 0.3);
}

-(void)banner_Animations1
{
    
    _lbl2.hidden =NO;
    
   
    
    [_lbl2 setAlpha:0.0];
    [UIView animateWithDuration:1.0
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_lbl2 setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {   _lbl2.hidden =NO;
              [self banner_Animations2];
             // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:4
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                  // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}
-(void)banner_Animations2
{
    _lbl3.hidden =NO;
    
    [_lbl3 setAlpha:0.0];
    [UIView animateWithDuration:1.0
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_lbl3 setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {
             
            _lbl3.hidden =NO;
             [self banner_Animations3];
             // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:4
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                  // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}
-(void)banner_Animations3
{
     _lbl4.hidden =NO;
    
    [_lbl4 setAlpha:0.0];
    [UIView animateWithDuration:1.0
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_lbl4 setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {[self banner_Animations4];
             _lbl4.hidden =NO;
             // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:4
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                  // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}
-(void)banner_Animations4
{
   // _BannerImageview.hidden =NO;
    _lbl5.hidden =NO;
    
    [_lbl5 setAlpha:0.0];
    [UIView animateWithDuration:1.0
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_lbl5 setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {
             _lbl5.hidden =NO;
             
             [self.BannerImageview bounceIntoView:self.view direction:DCAnimationDirectionLeft];
              _BannerImageview.hidden =NO;
             // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:4
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                  // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}





-(void)werlcome_Label
{
    
    
    
    
    
}


-(void)banner_Animation
{
    // _BannerImageview.hidden =NO;
    _TextViews.hidden=NO;
    _We.hidden=NO;
    
    _WelcomeLbl.hidden=NO;
      _Hightly.hidden=NO;
    
    
 [_TextViews setAlpha:0.0];
     [_We setAlpha:0.0];
     [_WelcomeLbl setAlpha:0.0];
    
    [_Hightly setAlpha:0.0];
    [UIView animateWithDuration:1.3
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations:^(void)
     {
         [_TextViews setAlpha:1.0];
            [_Hightly setAlpha:1.0];
            [_WelcomeLbl setAlpha:1.0];
         
            [_We setAlpha:1.0];
     }
                     completion:^(BOOL finished)
     {
         if(finished)
         {
           
              _TextViews.hidden=NO;
            
             _We.hidden=NO;
             
             _WelcomeLbl.hidden=NO;
             _Hightly.hidden=NO;
             // [self.lbl1 snapIntoView:self.view direction:DCAnimationDirectionLeft];
             [UIView animateWithDuration:1.5
                                   delay:5
                                 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                              animations:^(void)
              {
                  // [_lbl2 setAlpha:0.0];
              }
                              completion:^(BOOL finished)
              {
                  if(finished)
                      NSLog(@"Hurray. Label fadedIn & fadedOut");
              }];
         }
     }];
    
    
}


//Ayyappa Swamy Pooja




#pragma mark - collectionView


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ReuseIdentifier = @"CustomMainCell";
    CustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ReuseIdentifier forIndexPath:indexPath];
    
    // _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[service_image objectAtIndex:indexPath.row];
    
    // NSLog(@"path %@",path);
    
    //[_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:path]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            // WARNING: is the cell still using the same data by this point??
            cell.imageView.image = [UIImage imageWithData: data];
        });
       
    });
    
  //  [cell.baseView.layer setMasksToBounds:NO];
   // [cell.baseView.layer setShadowColor:[[UIColor grayColor] CGColor]];
   // [cell.baseView.layer setShadowOpacity:0.6f];
   // [cell.baseView.layer setShadowRadius:10.0f];
   // [cell.baseView.layer setCornerRadius:4.0f];
   // [cell.baseView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
  //  cell.imageView.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
    cell.NameLbl.text =[service_name objectAtIndex:indexPath.row];
    
    cell.FullimageView.hidden =YES;
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return service_image.count;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
   // UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    
    
    static NSString *ReuseIdentifier = @"CustomMainCell";
    CustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ReuseIdentifier forIndexPath:indexPath];
    cell.FullimageView.hidden =NO;
   // cell1.imageView.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
    
    
    
    if (self.awesometransition.type == HYTransitionTypeModal) {
        
        ModalViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ModalViewController"];
       vc.imageName = service_image[indexPath.row];
        vc.transitioningDelegate = self;
        vc.delegate              = self;
        
        CGRect startFrame = [cell convertRect:cell.bounds toView:self.view];
        CGRect finalFrame = CGRectMake(40, 150, 100, 100);
        
        [self.awesometransition registerStartFrame:startFrame
                                        finalFrame:finalFrame transitionView:cell];
        
        [self presentViewController:vc animated:YES completion:^{
            vc.avatar.hidden = NO;
            vc.avatar.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
        }];
    } else {
        ModalViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ModalViewController"];
        
        vc.imageName = service_image[indexPath.row];
         vc.imageUrl = service_name[indexPath.row];
         vc.Desc = description[indexPath.row];
         vc.Benfites = benifits[indexPath.row];
        vc.delegate              = self;
        
        
    
        [[NSUserDefaults standardUserDefaults] setObject:service_name[indexPath.row] forKey:@"ServiceName"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        CGRect startFrame = [cell convertRect:cell.bounds toView:self.view];
        CGRect finalFrame = CGRectMake(40, 150, 100, 50);
        
        [self.awesometransition registerStartFrame:startFrame
                                        finalFrame:finalFrame transitionView:cell];
        
        
        vc.imagevieww.hidden =NO;
        
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:self->service_image[indexPath.row]]];
            if ( data == nil )
                return;
            dispatch_async(dispatch_get_main_queue(), ^{
                // WARNING: is the cell still using the same data by this point??
                vc.imagevieww.image = [UIImage imageWithData:data];
            });
            
        });
        
        self.navigationController.delegate = self;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
}


- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    self.awesometransition.present = NO;
    return self.awesometransition;
}

// If you use UINavigationController, you have to implement UINavigationControllerDelegate
// instead of UIViewControllerTransitioningDelegate

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC{
    
    self.awesometransition.type = HYTransitionTypeNavigation;
    if (operation == UINavigationControllerOperationPush) {
        self.awesometransition.present = YES;
    } else {
        self.awesometransition.present = NO;
    }
    return self.awesometransition;
}













@end
