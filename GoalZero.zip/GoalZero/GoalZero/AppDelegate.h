//
//  AppDelegate.h
//  GoalZero
//
//  Created by user on 16/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

