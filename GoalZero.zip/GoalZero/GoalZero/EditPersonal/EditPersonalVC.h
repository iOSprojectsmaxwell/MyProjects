//
//  EditPersonalVC.h
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditPersonalVC : UIViewController
@property(nonatomic,strong)IBOutlet UITextField*UsernameTxt;
@property(nonatomic,strong)IBOutlet UITextField*PasswordTxt;
@property(nonatomic,strong)IBOutlet UIView *Usernameview;
@property(nonatomic,strong)IBOutlet UIView *Passwordview;
@property(nonatomic,strong)IBOutlet UIView*blurescreen;

@property(nonatomic,strong)IBOutlet UITextField*emailTxt;
@property(nonatomic,strong)IBOutlet UITextField*newpasswordTxt;
@property(nonatomic,strong)IBOutlet UIView *emailview;
@property(nonatomic,strong)IBOutlet UIView *newpasswordview;


@property(nonatomic,strong)IBOutlet UITextField*ConfirmTxt;
@property(nonatomic,strong)IBOutlet UIView *Confirmview;

@end
