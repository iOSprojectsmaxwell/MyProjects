//
//  EditPersonalVC.m
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "EditPersonalVC.h"
#import "ViewController.h"
#import "Common.h"
@interface EditPersonalVC ()
{
     ViewController *objSideMenuView;
}

@property (weak, nonatomic) IBOutlet UIImageView *Profile_Image;

@end

@implementation EditPersonalVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _blurescreen.hidden=YES;
    

    self.Profile_Image.layer.cornerRadius = self.Profile_Image.frame.size.width / 2;
    self.Profile_Image.clipsToBounds = YES;
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.blurescreen addGestureRecognizer:singleFingerTap];
    
    self.Confirmview.layer.cornerRadius = 8.0 ;
    self.Confirmview.clipsToBounds = true;
    
    self.Confirmview.layer.borderWidth = 1.0f;
    self.Confirmview.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.emailview.layer.cornerRadius = 8.0 ;
    self.emailview.clipsToBounds = true;
    
    self.emailview.layer.borderWidth = 1.0f;
    self.emailview.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.newpasswordview.layer.cornerRadius = 8.0 ;
    self.newpasswordview.clipsToBounds = true;
    
    self.newpasswordview.layer.borderWidth = 1.0f;
    self.newpasswordview.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.Passwordview.layer.cornerRadius = 8.0 ;
    self.Passwordview.clipsToBounds = true;
    
    self.Passwordview.layer.borderWidth = 1.0f;
    self.Passwordview.layer.borderColor = [UIColor redColor].CGColor;
    
    self.Usernameview.layer.cornerRadius = 8.0 ;
    self.Usernameview.clipsToBounds = true;
    
    self.Usernameview.layer.borderWidth = 1.0f;
    self.Usernameview.layer.borderColor = [UIColor redColor].CGColor;
    
    // Do any additional setup after loading the view.
}
- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
    _blurescreen.hidden=YES;
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    //Do stuff here...
}

-(IBAction)submit_button:(id)sender{
    
    if (_emailTxt.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your Emailid"];
    }
    else if (_PasswordTxt.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter your Current password"];
    }
    else if (_newpasswordTxt.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter your New password"];
    }
    else if (_ConfirmTxt.text.length ==0)
    {
      [Common AlertShowWithErrorMsg:@"Please enter Confirm password"];
    }
    else if (_newpasswordTxt.text !=_ConfirmTxt.text)
    {
         [Common AlertShowWithErrorMsg:@"your password not match with cofirmpassword"];
    }
    else{
//        [Common AlertShowWithErrorMsg:@"Successfully changed your profile"];
    }
   
}


- (IBAction)Menu:(id)sender {
    
    
    
    _blurescreen.hidden=NO;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+25, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
- (IBAction)Select_Pic:(id)sender {
    
     [self showActionSheet];
    
}

- (void)showActionSheet{
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:@"Choose From" preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped.
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Gallery" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
        imgpicker.allowsEditing = YES;
        imgpicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imgpicker.delegate=(id)self;
        [self presentViewController:imgpicker animated:YES completion:nil];
        ////         Distructive button tapped.
        //                [self dismissViewControllerAnimated:YES completion:^{
        //                }];
    }]];
    
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Sorry"
                                         message:@"No camera detected"
                                         preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action =[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
                
                
            }];
            
            
            [alert addAction:action];
            
            [self presentViewController:alert animated:YES completion:nil];
        }else{
            
            UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
            imgpicker.allowsEditing = YES;
            imgpicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            imgpicker.delegate=(id)self;
            [self presentViewController:imgpicker animated:YES completion:nil];
            
        }
        // OK button tapped.
        
        //        [self dismissViewControllerAnimated:YES completion:^{
        //        }];
    }]];
    
    // Present action sheet.
    [self presentViewController:actionSheet animated:YES completion:nil];
    
    
    
    // OK button tapped.
    
    //        [self dismissViewControllerAnimated:YES completion:^{
    //        }];
    
}
- (IBAction)btnActnChoosePic:(id)sender {
    
   
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage =[info valueForKey:UIImagePickerControllerOriginalImage];
    
    chosenImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    self.Profile_Image.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
