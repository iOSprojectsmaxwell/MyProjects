//
//  MyImageView.m
//  iMixtapes
//
//  Created by Vipin Jain on 05/02/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyImageView.h"
#define TMP NSTemporaryDirectory()

@implementation MyImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {

    }
    return self;
}

-(void) addImageFrom:(NSString*) URL isRound:(BOOL)value isActivityIndicator:(BOOL)activ
{
    value = NO;
    URL = [URL stringByURLDecode];
    NSString *_lastStr =[URL lastPathComponent];
        
    if ([_lastStr isEqualToString:@"iphone:1"])
    {
        _lastStr =@"http://www.sproutt.net/mobile/event_detail/131/iphone:1";
    }
    else if ([_lastStr isEqualToString:@"iphone:0"])
    {
       _lastStr =@"http://www.sproutt.net/mobile/event_detail/131/iphone:0"; 
        
    }
    else if([_lastStr isEqualToString:@"ipad:1"])
    {
      _lastStr =@"http://www.sproutt.net/mobile/event_detail/131/ipad:1";   
        
    }
   else if ([_lastStr isEqualToString:@"ipad:0"])
    {
        _lastStr =@"http://www.sproutt.net/mobile/event_detail/131/ipad:0"  ;
        
    }
    
    URL = [[URL stringByDeletingLastPathComponent] stringByAppendingPathComponent:_lastStr];
    
    
    NSString *imgPath = [self getUniquePath:URL];
    
	if ([[NSFileManager defaultManager] fileExistsAtPath:imgPath])
    {
        
        NSData *data = [NSData dataWithContentsOfFile:imgPath];
        
        [self setImage:[UIImage imageWithData:data]];
    }
    
	else 
	{
        if (activ) 
        {
            UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
            activityIndicator.tag = 786;
            
            [activityIndicator startAnimating];
            
            [activityIndicator setHidesWhenStopped:YES];
            
            CGRect myRect = self.frame;

            CGRect newRect = CGRectMake(myRect.size.width/2 -12.5f,myRect.size.height/2 - 12.5f, 25, 25);
            
            [activityIndicator setFrame:newRect];
            
            [self addSubview:activityIndicator];
        }
        
		[NSThread detachNewThreadSelector:@selector(fetchImage:) toTarget:self withObject:[URL stringByURLDecode]];
	}
}
-(void) addImageFrom:(NSString*) URL isRound:(BOOL)value
{
	[self addImageFrom:URL isRound:value isActivityIndicator:YES];
}

-(void) fetchImage:(NSString*) str
{
	NSURL *url = [NSURL URLWithString:str];
	NSData *data = [NSData dataWithContentsOfURL:url];
	UIImage *tmpImage = [UIImage imageWithData:data];
	
	NSString *imgPath = [self getUniquePath:str];
	[data writeToFile:imgPath atomically:YES];
    	
    
    [self performSelectorOnMainThread:@selector(setImageToImageView:) withObject:tmpImage waitUntilDone:YES];

}

-(void)setImageToImageView:(UIImage *)tmpImage
{
    [self setImage:tmpImage];
    UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView*)[self viewWithTag:786];
    [activityIndicator stopAnimating];
    [activityIndicator removeFromSuperview];
}


-(NSString*)  getUniquePath:(NSString*)  urlStr
{
    if ([urlStr length] > 7)
    {
        
    NSMutableString *tempImgUrlStr = [NSMutableString stringWithString:[urlStr substringFromIndex:7]];
    [tempImgUrlStr replaceOccurrencesOfString:@"/" withString:@"-" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [tempImgUrlStr length])];
    
    
    // Generate a unique path to a resource representing the image you want
    NSString    *filename = [NSString stringWithFormat:@"%@",tempImgUrlStr] ;//[ImageURLString substringFromIndex:7];   // [[something unique, perhaps the image name]];
    NSString *uniquePath = [TMP stringByAppendingPathComponent: filename];
    
    return uniquePath;
    }
return nil;
}
						   
- (UIImage*)imageWithBorderFromImage:(UIImage*)source
{
    CGSize size = [source size];
    UIGraphicsBeginImageContext(size);
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    [source drawInRect:rect blendMode:kCGBlendModeNormal alpha:1.0];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetRGBStrokeColor(context, 1.0, 0.5, 1.0, 1.0);
    CGContextStrokeRect(context, rect);
    UIImage *testImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return testImg;
}

-(void)downloadImageFromPathToDirectory:(NSString *)path
{
    NSError *error;
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* documentsDirectory = [paths objectAtIndex:0];
    
    // FOR STORING IMAGE INTO FOLDER CREATED IN DOCUMENT DIRECTORY
    
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:@"/CityImagesFolder"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:&error];
    
    NSURL *url1 = [NSURL URLWithString:path];
    NSData *data = [NSData dataWithContentsOfURL:url1];
    //  UIImage *image = [UIImage imageWithData: [NSData dataWithContentsOfURL:url1]];
    //  NSData* imageData = UIImagePNGRepresentation(image);
    NSString* incrementedImgStr = [NSString stringWithFormat:@"CityZip.zip"];
    NSString* fullPathToFile2 = [dataPath stringByAppendingPathComponent:incrementedImgStr];
    [data writeToFile:fullPathToFile2 atomically:NO];
}

-(UIImage *)FetchImage
{
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* documentsDirectory = [paths objectAtIndex:0];
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:@"/CityImagesFolder"];
    NSString *workSpacePath = [dataPath stringByAppendingPathComponent:@"userImage.png"];
    return [UIImage imageWithData:[NSData dataWithContentsOfFile:workSpacePath]];
}

@end
