//
//  GoalZeroVC.h
//  GoalZero
//
//  Created by user on 16/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoalZeroVC : UIViewController
@property(nonatomic,strong)IBOutlet UIView*blurescreen;
@property(nonatomic,strong)IBOutlet UIWebView*WebVieww;
@end
