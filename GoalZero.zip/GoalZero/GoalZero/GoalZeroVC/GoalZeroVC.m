//
//  GoalZeroVC.m
//  GoalZero
//
//  Created by user on 16/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "GoalZeroVC.h"
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "Common.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "ViewController.h"
@interface GoalZeroVC ()<MBProgressHUDDelegate>
{
     MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSArray *response;
    NSString *Images;
     ViewController *objSideMenuView;
    float lastScale;
}
@property(nonatomic,strong)IBOutlet MyImageView *iamgeviveww;
@property(nonatomic,strong)IBOutlet UIImageView *imagevieww;
@end

@implementation GoalZeroVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _blurescreen.hidden=YES;
    [_imagevieww setUserInteractionEnabled:YES];
    UIPinchGestureRecognizer *pgr = [[UIPinchGestureRecognizer alloc]
                                     initWithTarget:self action:@selector(handlePinchGesture:)];
    
     [_imagevieww addGestureRecognizer:pgr];
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.blurescreen addGestureRecognizer:singleFingerTap];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    [self calling_webServicsfor_banner];
    // Do any additional setup after loading the view.
}

- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
    _blurescreen.hidden=YES;
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    //Do stuff here...
}
- (IBAction)Menu:(id)sender {
    
    
    
     _blurescreen.hidden=NO;
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+3, 270, 600);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@" " forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
    
    
    
//
//    _blurescreen.hidden=NO;
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
//    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+25, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
//
//    [self addChildViewController:objSideMenuView];
//
//    [objSideMenuView didMoveToParentViewController:self];
//
//    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
//    [button1 addTarget:self
//                action:@selector(aMethod:)
//      forControlEvents:UIControlEventTouchUpInside];
//    [button1 setTitle:@"X" forState:UIControlStateNormal];
//    button1.frame = CGRectMake(211, -16, 55, 55);
//    [objSideMenuView.view addSubview:button1];
//    [self.view addSubview:objSideMenuView.view];



-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/leadership.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[dict2 valueForKey:@"response"]
            ;
            
            Images =[[response valueForKey:@"image"]objectAtIndex:0];
           
            
            _imagevieww.image =[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:Images]]];
//            
//            imagevieww.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]]
//            
        
            
//            NSString *urlAddress = Images;
//            NSURL *url = [NSURL URLWithString:urlAddress];
//            NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
//
//            [_WebVieww loadRequest:requestObj];
//
//            _WebVieww.delegate=self;
//
            [HUD hide:YES];
            
        });
    });
    
}


- (void)handlePinchGesture:(UIPinchGestureRecognizer *)gestureRecognizer {
    
    if([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        // Reset the last scale, necessary if there are multiple objects with different scales.
        lastScale = [gestureRecognizer scale];
    }
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan ||
        [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        
        CGFloat currentScale = [[[gestureRecognizer view].layer valueForKeyPath:@"transform.scale"] floatValue];
        
        // Constants to adjust the max/min values of zoom.
        const CGFloat kMaxScale = 2.0;
        const CGFloat kMinScale = 1.0;
        
        CGFloat newScale = 1 -  (lastScale - [gestureRecognizer scale]); // new scale is in the range (0-1)
        newScale = MIN(newScale, kMaxScale / currentScale);
        newScale = MAX(newScale, kMinScale / currentScale);
        CGAffineTransform transform = CGAffineTransformScale([[gestureRecognizer view] transform], newScale, newScale);
        [gestureRecognizer view].transform = transform;
        
        lastScale = [gestureRecognizer scale];  // Store the previous. scale factor for the next pinch gesture call
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [HUD hide:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
