//
//  HomeView.h
//  GoalZero
//
//  Created by user on 16/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ViewController.h"

@interface HomeView : ViewController
@property(nonatomic,strong)IBOutlet UIView*blurescreen;
@property(nonatomic,strong)IBOutlet UIView *leftview;
@property(nonatomic,strong)IBOutlet UIView *rightview;

@property(nonatomic,strong)IBOutlet UILabel *harmlbl;
@property(nonatomic,strong)IBOutlet UILabel *leakslbl;
@end
