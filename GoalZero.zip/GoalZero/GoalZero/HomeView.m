//
//  HomeView.m
//  GoalZero
//
//  Created by user on 16/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "HomeView.h"
#import "ViewController.h"
#import "JSON.h"
#import "Common.h"
#import "MBProgressHUD.h"


@interface HomeView ()<MBProgressHUDDelegate>
{
    ViewController *objSideMenuView;
    NSArray *response;
    NSDictionary *dict2;
    MBProgressHUD *HUD;
    NSString *harms;
      NSString *leaks;
    

}

@end

@implementation HomeView

- (void)viewDidLoad {
    [super viewDidLoad];
    _blurescreen.hidden=YES;
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    self.leftview.layer.cornerRadius = 8.0 ;
    self.leftview.clipsToBounds = true;
    
    self.leftview.layer.borderWidth = 1.0f;
    self.leftview.layer.borderColor = [UIColor redColor].CGColor;
    [self calling_webServicsfor_banner];
    
    self.rightview.layer.cornerRadius = 8.0 ;
    self.rightview.clipsToBounds = true;
    
    self.rightview.layer.borderWidth = 1.0f;
    self.rightview.layer.borderColor = [UIColor redColor].CGColor;
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.blurescreen addGestureRecognizer:singleFingerTap];
    
    //The event handling method
   
    // Do any additional setup after loading the view.
}


- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
      _blurescreen.hidden=YES;
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    //Do stuff here...
}
- (IBAction)Menu:(id)sender {
    
    
    
    _blurescreen.hidden=NO;
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+3, 270, 600);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@" " forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    
    
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/harms-leaks.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        self->dict2=[sampleURL JSONValue];
        NSLog(@"Login Details %@",self->dict2);
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[[dict2 valueForKey:@"response"]objectAtIndex:0]
            ;
            harms =[NSString stringWithFormat:@"%@",[response valueForKey:@"harms"]];
            leaks =[NSString stringWithFormat:@"%@",[response valueForKey:@"leaks"]];;
            
            
            
            [[NSUserDefaults standardUserDefaults] setObject:harms forKey:@"harms"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setObject:leaks forKey:@"leaks"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            _harmlbl.text =harms;
             _leakslbl.text =leaks;
            [HUD hide:YES];
            
        });
    });
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
