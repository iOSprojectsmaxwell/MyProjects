//
//  ListeningObservationVC.h
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListeningObservationVC : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *ScrollViewsc;
@property(nonatomic,strong)IBOutlet UIView*blurescreen;


@property (weak, nonatomic) IBOutlet UIButton *Radio_Button_P;
@property (weak, nonatomic) IBOutlet UIButton *Radio_Button_N;



@property(nonatomic,strong)IBOutlet UIView *leftview;
@property(nonatomic,strong)IBOutlet UIView *rightview;

@property(nonatomic,strong)IBOutlet UILabel *harmlbl;
@property(nonatomic,strong)IBOutlet UILabel *leakslbl;
@end
