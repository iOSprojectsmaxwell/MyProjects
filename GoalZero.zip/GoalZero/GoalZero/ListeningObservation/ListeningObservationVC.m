//
//  ListeningObservationVC.m
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ListeningObservationVC.h"
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "Common.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "ViewController.h"
#import "CLPopListView.h"
@interface ListeningObservationVC ()
<MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSArray *response;
    NSString *Images;
    ViewController *objSideMenuView;
    NSArray *location;
    NSArray *project;
    NSString *strl;
    NSArray *areaname;
    NSArray *project_name;
    NSString *selectedLocation;
       NSString *Project;
    NSString *alertString;
    UIImage* radioOff;
    UIImage* radioOn;
    NSString *company_name;
    NSString *idd1;
    NSString *currentTime;
    NSString *idd2;
    NSString *idd3;
    NSString *idd4;
    NSString *idd5;
    NSString *idd6;
    NSString *idd7;
    NSString *idd8;
    NSString *idd9;
    NSString *idd10;
    NSString *idd11;
    NSString *idd12;
    NSString *idd13;
    NSString *idd14;
    NSString *idd15;
    NSString *idd16;
    NSString *idd17;
    NSString *idd18;
    NSString *userid;
    NSString *postive;
    NSString *close;
    NSMutableArray *mainArray;
    NSArray *project_id;
    NSArray *location_id;
    NSString * selected;
    NSString *project_idstr;
    NSString *location_idstr;
      NSMutableArray *namesArray;
    UIDatePicker *datePicker;
    NSString *harms;
    NSString *leaks;
    
    UIDatePicker *picker;
}
@property (weak, nonatomic) IBOutlet UIView *CompanyView;
@property (weak, nonatomic) IBOutlet UIView *ListingView;
@property (weak, nonatomic) IBOutlet UIView *DateView;
@property (weak, nonatomic) IBOutlet UIView *ProjectView;
@property (weak, nonatomic) IBOutlet UIView *TimeView;
@property (weak, nonatomic) IBOutlet UITextView *Desctextview;
@property (weak, nonatomic) IBOutlet UITextView *RecomendedTextView;
@property (weak, nonatomic) IBOutlet UIView *ActionPartyView;
@property (weak, nonatomic) IBOutlet UIView *ActionPerformmedView;
@property (weak, nonatomic) IBOutlet UITextView *ExplanationView;
@property (weak, nonatomic) IBOutlet UIButton *Submit_Button;
@property (weak, nonatomic) IBOutlet UIButton *ChemicalsBox;

@property (weak, nonatomic) IBOutlet UIButton *ConfinedBox;
@property (weak, nonatomic) IBOutlet UIButton *DroppedBox;
@property (weak, nonatomic) IBOutlet UIButton *EmergeBox;
@property (weak, nonatomic) IBOutlet UIButton *ExcavationBox;
@property (weak, nonatomic) IBOutlet UIButton *ExplainBox;
@property (weak, nonatomic) IBOutlet UIButton *HeavyBox;
@property (weak, nonatomic) IBOutlet UIButton *HotWorksBox;
@property (weak, nonatomic) IBOutlet UIButton *HousekeepingBox;
@property (weak, nonatomic) IBOutlet UIButton *IsolationBox;
@property (weak, nonatomic) IBOutlet UIButton *LiftingBox;
@property (weak, nonatomic) IBOutlet UIButton *LineoffireBox;
@property (weak, nonatomic) IBOutlet UIButton *PPEBox;
@property (weak, nonatomic) IBOutlet UIButton *ScaffoldingBox;
@property (weak, nonatomic) IBOutlet UIButton *sheltersBox;
@property (weak, nonatomic) IBOutlet UIButton *signBox;
@property (weak, nonatomic) IBOutlet UIButton *SimopsBox;
@property (weak, nonatomic) IBOutlet UIButton *ToolsBox;
@property (weak, nonatomic) IBOutlet UIButton *WorkatHeight;
@property (weak, nonatomic) IBOutlet UILabel *Explainlbl;

@property (weak, nonatomic) IBOutlet UIButton *ExplainsButton;

@property (weak, nonatomic) IBOutlet UILabel *Normallbl;
@property (weak, nonatomic) IBOutlet UILabel *ExpLbl;
@property (weak, nonatomic) IBOutlet UITextField *LocationTxt;
@property (weak, nonatomic) IBOutlet UITextField *ProjectTxt;


@property (weak, nonatomic) IBOutlet UITextField *Action_PartyTXT;
@property (weak, nonatomic) IBOutlet UITextField *Action_PerformedTXT;
@property (weak, nonatomic) IBOutlet UITextField *dateTxt;
@property (weak, nonatomic) IBOutlet UITextField *timetTxt;
@property (weak, nonatomic) IBOutlet UITextField *CompanyTxt;


@property (weak, nonatomic) IBOutlet UIButton *Closebtn;
@property (weak, nonatomic) IBOutlet UIButton *Forther_btn;

@end

@implementation ListeningObservationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self SetupView];
    radioOff=[UIImage imageNamed:@"RadioEmty.png"];//[UIImage init
    radioOn=[UIImage imageNamed:@"RadioButton_Filled.png"];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    postive =@"emity";
    close =@"emity";
    [HUD hide:YES];
    idd1 =@"00";
    idd2 =@"00";
    idd3=@"00";
    idd4=@"00";
    idd5=@"00";
    idd6=@"00";
    idd7=@"00";
    idd8=@"00";
    idd9=@"00";
    idd10=@"00";
    idd11=@"00";
    idd12=@"00";
    idd13=@"00";
    idd14=@"00";
    idd15=@"00";
    idd16=@"00";
    idd17=@"00";
    idd18=@"00";
    CGFloat Height = self.view.frame.size.height;
    CGFloat Width = self.view.frame.size.width;
    
    UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, Width, 50)];
    numberToolbar.barStyle = UIBarStyleBlackTranslucent;
    numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"DONE" style:UIBarButtonItemStyleDone target:self action:@selector(doneBtnAction)],
                            [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil]];
    [numberToolbar sizeToFit];
    // txtFiled.inputView = numberToolbar;
    
    picker = [[UIDatePicker alloc]initWithFrame:CGRectMake(0, Height-200, Width, 200)];
    picker.backgroundColor = [UIColor orangeColor];
    picker.datePickerMode =UIDatePickerModeTime;
    [picker addSubview:numberToolbar];
    [self.view addSubview:picker];
    datePicker.backgroundColor =[UIColor orangeColor];
    [picker addTarget:self action:@selector(dateChanged:) forControlEvents:UIControlEventValueChanged];
    UILabel  * label1 = [[UILabel alloc] initWithFrame:CGRectMake(40, 70, 300, 50)];
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
    [dateFormatter2 setDateFormat:@"hh:mm:ss a"];
    NSString *currentTime1 = [dateFormatter2 stringFromDate:datePicker.date];
    label1.text = currentTime1;
    label1.hidden =YES;
    [self.view addSubview:label1];
    
    selected =@"emity";
    self.leftview.layer.cornerRadius = 8.0 ;
    self.leftview.clipsToBounds = true;
    picker.hidden=YES;
    self.leftview.layer.borderWidth = 1.0f;
    self.leftview.layer.borderColor = [UIColor redColor].CGColor;
    self.rightview.layer.cornerRadius = 8.0 ;
    self.rightview.clipsToBounds = true;
    
    self.rightview.layer.borderWidth = 1.0f;
    self.rightview.layer.borderColor = [UIColor redColor].CGColor;
    userid = [[NSUserDefaults standardUserDefaults]
              stringForKey:@"userid"];
    company_name = [[NSUserDefaults standardUserDefaults]
                    stringForKey:@"company_name"];
    
    _CompanyTxt.text =company_name;
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
    
    _dateTxt.text =[NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    harms = [[NSUserDefaults standardUserDefaults]
             stringForKey:@"harms"];
    _harmlbl.text =harms;
    
    leaks = [[NSUserDefaults standardUserDefaults]
             stringForKey:@"leaks"];
    _leakslbl.text =leaks;
    
    
    
    NSDateFormatter *dateFormatter1=[[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"hh:mm:ss"];
    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
    NSLog(@"%@",[dateFormatter1 stringFromDate:[NSDate date]]);
    _timetTxt.text =[NSString stringWithFormat:@"%@",[dateFormatter1 stringFromDate:[NSDate date]]];
    
    
    [self calling_webServicsfor_banner];
    UIImage* nonCheckedImage=[UIImage imageNamed:@"icons8-unchecked-checkbox-filled-50.png"];//[UIImage init
    UIImage* CheckedImage=[UIImage imageNamed:@"CheckBoxFill.png"];
    // Do any additional setup after loading the view.
    
    _blurescreen.hidden=YES;
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.blurescreen addGestureRecognizer:singleFingerTap];
    
    [_ExplainsButton setImage:CheckedImage forState:UIControlStateSelected];
    [_ExplainsButton setImage:nonCheckedImage forState:UIControlStateNormal];
    [_ChemicalsBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ChemicalsBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_ConfinedBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ConfinedBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_DroppedBox setImage:CheckedImage forState:UIControlStateSelected];
    [_DroppedBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_EmergeBox setImage:CheckedImage forState:UIControlStateSelected];
    [_EmergeBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_ExcavationBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ExcavationBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_ExplainBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ExplainBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_HeavyBox setImage:CheckedImage forState:UIControlStateSelected];
    [_HeavyBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    
    
    [_HotWorksBox setImage:CheckedImage forState:UIControlStateSelected];
    [_HotWorksBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_HousekeepingBox setImage:CheckedImage forState:UIControlStateSelected];
    [_HousekeepingBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_IsolationBox setImage:CheckedImage forState:UIControlStateSelected];
    [_IsolationBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_LiftingBox setImage:CheckedImage forState:UIControlStateSelected];
    [_LiftingBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_LineoffireBox setImage:CheckedImage forState:UIControlStateSelected];
    [_LineoffireBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    [_PPEBox setImage:CheckedImage forState:UIControlStateSelected];
    [_PPEBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    
    [_ScaffoldingBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ScaffoldingBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_sheltersBox setImage:CheckedImage forState:UIControlStateSelected];
    [_sheltersBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_signBox setImage:CheckedImage forState:UIControlStateSelected];
    [_signBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_SimopsBox setImage:CheckedImage forState:UIControlStateSelected];
    [_SimopsBox setImage:nonCheckedImage forState:UIControlStateNormal];
    [_ToolsBox setImage:CheckedImage forState:UIControlStateSelected];
    [_ToolsBox setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    [_WorkatHeight setImage:CheckedImage forState:UIControlStateSelected];
    [_WorkatHeight setImage:nonCheckedImage forState:UIControlStateNormal];
    
    

    
}
- (void)doneBtnAction:(UIBarButtonItem *)sender {
    NSLog(@"%@", sender);
}
-(void)changeDateFromLabel:(id)sender
{
   // [[your UI Element] resignFirstResponder];
}
- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
    _blurescreen.hidden=YES;
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    //Do stuff here...
}


-(void)datePicker{
    datePicker.hidden=NO;
    datePicker=[[UIDatePicker alloc]init];
    datePicker.datePickerMode=UIDatePickerModeTime;
    [_timetTxt setInputView:datePicker];
    datePicker.backgroundColor =[UIColor orangeColor];
    UIToolbar *toolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    [_timetTxt setInputAccessoryView:toolBar];
}



-(void)ShowSelectedDate
{   NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm:ss"];
    currentTime = [dateFormatter stringFromDate:datePicker.date];
    _timetTxt.text=[NSString stringWithFormat:@"%@",currentTime];
    [_timetTxt resignFirstResponder];
}
- (IBAction)Menu:(id)sender {
    
    
    
    _blurescreen.hidden=NO;
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+3, 270, 600);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@" " forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
- (IBAction)Positive_Button:(id)sender {
    
    postive =@"1";
    [_Radio_Button_P setImage:radioOn forState:UIControlStateNormal];
    [_Radio_Button_N setImage:radioOff forState:UIControlStateNormal];
    
    
}

-(IBAction)time_piker:(id)sender
{
    [self datePicker];
  datePicker.hidden =NO;
 //picker.hidden =NO;
    
}

- (IBAction)Close_Button:(id)sender {
    close =@"1";
    [_Closebtn setImage:radioOn forState:UIControlStateNormal];
    [_Forther_btn setImage:radioOff forState:UIControlStateNormal];
    
}
- (IBAction)Further_Button:(id)sender {
    close =@"2";
    [_Closebtn setImage:radioOff forState:UIControlStateNormal];
    [_Forther_btn setImage:radioOn forState:UIControlStateNormal];
}

- (void)dateChanged:(id)sender
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm:ss"];
  currentTime = [dateFormatter stringFromDate:picker.date];
    NSLog(@"%@", currentTime);
}
-(IBAction)PressDone:(id)sender{
   
    
}
-(void)PressDone
{
    _timetTxt.text =currentTime;
    //  picker.hidden =NO;
    
}
- (IBAction)negativeov_button:(id)sender {
     postive =@"2";
    [_Radio_Button_P setImage:radioOff forState:UIControlStateNormal];
    [_Radio_Button_N setImage:radioOn forState:UIControlStateNormal];
}
-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/menu_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[dict2 valueForKey:@"response"];
  
            location =[response valueForKey:@"location"];
            project=[response valueForKey:@"project"];
            
            
           project_id =[project valueForKey:@"id"];
          location_id =[location valueForKey:@"id"];
            
          
      
            areaname =[location valueForKey:@"areaname"];
            project_name =[project valueForKey:@"project_name"];
    
           [HUD hide:YES];
            
        });
    });
    
}


-(IBAction)Location:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Location of Observation" options:areaname handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=100;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Project:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Project" options:project_name handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=101;
    [lplv showInView:self.view.window animated:YES];
    
    
}


-(IBAction)Register_Button:(id)sender{
    
      [self get_checkbox];
    NSString *name =[NSString stringWithFormat:@"%@",mainArray];
    NSString *obj =[NSString stringWithFormat:@"%@",name];
    if (_LocationTxt.text.length==0) {
        [Common AlertShowWithErrorMsg:@"Please select Location of Observation"];
    }
   
    else if (_dateTxt.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please select date"];
    }
    else if (_ProjectTxt.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please select your project"];
    }
    else if (_timetTxt.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Time"];
        
    }
    else if ([postive isEqualToString:@"emity"])
    {
        [Common AlertShowWithErrorMsg:@"Please select Type of Observation"];
        
    }
    else if (_Desctextview.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Desctiption of Observation"];
        
    }
    else if (_RecomendedTextView.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter your recommendation"];
    }
    else if (_Action_PartyTXT.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter action party"];
    }
    else if ([close isEqualToString:@"emity"])
    {
        [Common AlertShowWithErrorMsg:@"Please select action Type"];
        
    }
    else if (_Action_PerformedTXT.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter action performed"];
    }
    else if ([selected isEqualToString:@"emity"])
    {
        [Common AlertShowWithErrorMsg:@"Please select Activities"];
        
    }
    if (_ExplainsButton.selected ==YES)
    {
        if (_ExplanationView.text.length ==0) {
            [Common AlertShowWithErrorMsg:@"Please enter explanation"];
        }
        else{
            [self get_checkbox];
            
            [self upload_data];
            
        }
        
       
        
    }
    else{
        
        
        [self get_checkbox];
        
        [self upload_data];
        
    }
}



-(void)upload_data
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        
//        http://www.goalzero.qa/main/api/new_listening_observation.php?user_id=2315&obv_date=2018-08-20&obv_time=10:00:7&project_id=16&location_id=16&description=Testing&observation_type=1&action_desc=Testing&action_by=Testing&action_type=1&action_perform=testing&risk=1,2,3&explain_text=Testing
//
        
        NSString *Desc =[_Desctextview.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
     
        
          NSString *postiveaction = [_Action_PerformedTXT.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
      
        
        NSString *action_party = [_Action_PartyTXT.text stringByTrimmingCharactersInSet:
                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        
    
        
          NSString *explanation = [self->_ExplanationView.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        
       
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/new_listening_observation.php?user_id=%@&obv_date=%@&obv_time=%@&project_id=%@&location_id=%@&description=%@&observation_type=%@&action_desc=%@&action_by=%@&action_type=%@&action_perform=%@&risk=%@&explain_text=%@",userid,_dateTxt.text,_timetTxt.text,project_idstr,location_idstr,Desc,postive,postiveaction,action_party,close,postiveaction,alertString,self->_ExplanationView.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *response1;
            response1 =[dict2 valueForKey:@"response"];
            
            if ([response1 isEqualToString:@"success"]) {
                
                [Common AlertShowWithErrorMsg:@"your Listening Observation successfully submited"];
                _LocationTxt.text =@"";
                _ProjectTxt.text=@"";
                [_Radio_Button_P setImage:radioOff forState:UIControlStateNormal];
                [_Radio_Button_N setImage:radioOff forState:UIControlStateNormal];
                _Desctextview.text =@"";
                
                _RecomendedTextView.text =@"";
                _Action_PartyTXT.text =@"";
            
                [_Closebtn setImage:radioOff forState:UIControlStateNormal];
                [_Forther_btn setImage:radioOff forState:UIControlStateNormal];
                 _Action_PerformedTXT.text =@"";
                 _ExplanationView.text =@"";
            }
            else{
                
                   [Common AlertShowWithErrorMsg:@"Please check all feild your given something wrong"];
            }
          
            
            [HUD hide:YES];
            
        });
    });
    
    
    
}






- (void)leveyPopListView:(CLPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    if(popListView.tag==100)
    {
        
    
        //btnEventSize.titleLabel.text = [DurationArray objectAtIndex:anIndex];
        selectedLocation = [NSString stringWithFormat:@"  %@",[areaname objectAtIndex:anIndex]];
     
      location_idstr =[location_id objectAtIndex:anIndex];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _LocationTxt.text =selectedLocation;
        
    }
    
    else if (popListView.tag==101)
    {
        
        Project = [NSString stringWithFormat:@"  %@",[project_name objectAtIndex:anIndex]];
        project_idstr =[project_id objectAtIndex:anIndex];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _ProjectTxt.text =Project;
        
        
    }


}


- (IBAction)chemical_box:(id)sender {
      _ChemicalsBox.selected = !_ChemicalsBox.selected;
    if (_ChemicalsBox.selected ==YES) {
     selected =@"selected";
       idd1 =@"1";
    }
    else{
          idd1 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)ConfinedBox:(id)sender {
    _ConfinedBox.selected = !_ConfinedBox.selected;
    if (_ConfinedBox.selected ==YES) {
        selected =@"selected";
       idd2 =@"2";
    }
    else{
        idd2 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)DroppedBox:(id)sender {
    _DroppedBox.selected = !_DroppedBox.selected;
    if (_DroppedBox.selected ==YES) {
        selected =@"selected";
        idd3 =@"3";
    }
    else{
          idd3 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)EmergeBox:(id)sender {
    _EmergeBox.selected = !_EmergeBox.selected;
    if (_EmergeBox.selected ==YES) {
       selected =@"selected";
         idd4 =@"4";
    }
    else{
       idd4 =@"00";
         selected =@"emity";
    }
    
}

- (IBAction)ExcavationBox:(id)sender {
    _ExcavationBox.selected = !_ExcavationBox.selected;
    if (_ExcavationBox.selected ==YES) {
        selected =@"selected";
         idd5 =@"5";
    }
    else{
        idd5 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)ExplainBox:(id)sender {
    _ExplainBox.selected = !_ExplainBox.selected;
    if (_ExplainBox.selected ==YES) {
        selected =@"selected";
       idd6 =@"6";
    }
    else{
       idd6 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)HeavyBox:(id)sender {
    _HeavyBox.selected = !_HeavyBox.selected;
    if (_HeavyBox.selected ==YES) {
        selected =@"selected";
         idd7 =@"7";
    }
    else{
        idd7 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)HotWorksBox:(id)sender {
    _HotWorksBox.selected = !_HotWorksBox.selected;
    if (_HotWorksBox.selected ==YES) {
        selected =@"selected";
          idd8 =@"8";
    }
    else{
         idd8 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)HousekeepingBox:(id)sender {
    _HousekeepingBox.selected = !_HousekeepingBox.selected;
    if (_HousekeepingBox.selected ==YES) {
        selected =@"selected";
        idd9 =@"9";
    }
    else{
         idd9 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)IsolationBox:(id)sender {
    _IsolationBox.selected = !_IsolationBox.selected;
    if (_IsolationBox.selected ==YES) {
        selected =@"selected";
        idd10 =@"10";
    }
    else{
      idd10 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)LiftingBox:(id)sender {
    _LiftingBox.selected = !_LiftingBox.selected;
    if (_LiftingBox.selected ==YES) {
        selected =@"selected";
           idd11 =@"11";
    }
    else{
          idd11 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)LineoffireBox:(id)sender {
    _LineoffireBox.selected = !_LineoffireBox.selected;
    if (_LineoffireBox.selected ==YES) {
       selected =@"selected";
   idd12 =@"12";
    }
    else{
     idd12 =@"00";
         selected =@"emity";
    }
    
}

- (IBAction)PPEBox:(id)sender {
    _PPEBox.selected = !_PPEBox.selected;
    if (_PPEBox.selected ==YES) {
        selected =@"selected";
          idd13 =@"13";
    }
    else{
           idd13 =@"00";
         selected =@"emity";
    }
    
}
- (IBAction)ScaffoldingBox:(id)sender {
    _ScaffoldingBox.selected = !_ScaffoldingBox.selected;
    if (_ScaffoldingBox.selected ==YES) {
        selected =@"selected";
         idd14 =@"14";
    }
    else{
         idd14 =@"00";
       selected =@"emity";
    }
    
}

- (IBAction)sheltersBox:(id)sender {
    _sheltersBox.selected = !_sheltersBox.selected;
    if (_sheltersBox.selected ==YES) {
        selected =@"selected";
     idd15 =@"15";
    }
    else{
       idd15 =@"00";
        selected =@"emity";
    }
    
}

- (IBAction)signBox:(id)sender {
    _signBox.selected = !_signBox.selected;
    if (_signBox.selected ==YES) {
        selected =@"selected";
       idd16 =@"16";
    }
    else{
         idd16 =@"00";
         selected =@"emity";
    }
    
}

- (IBAction)SimopsBox:(id)sender {
    _SimopsBox.selected = !_SimopsBox.selected;
    if (_SimopsBox.selected ==YES) {
        selected =@"selected";
        idd17 =@"17";
    }
    else{
        idd17 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)ToolsBox:(id)sender {
    _ToolsBox.selected = !_ToolsBox.selected;
    if (_SimopsBox.selected ==YES) {
        selected =@"selected";
        idd18 =@"18";
    }
    else{
        idd18 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)WorkatHeight:(id)sender {
    _WorkatHeight.selected = !_WorkatHeight.selected;
    if (_WorkatHeight.selected ==YES) {
        
        strl =@"Selected";
    }
    else{
        strl =@"NotSelect";
        
    }
    
}

- (IBAction)Explains:(id)sender {
    _ExplainsButton.selected = !_ExplainsButton.selected;
    if (_ExplainsButton.selected ==YES) {
        
        
        _ExpLbl.hidden =NO;
         _ExplanationView.hidden =NO;
          _Submit_Button.frame = CGRectMake(111 , _ExplanationView.frame.origin.y+90, 149, 30);
      
        
        
        _Normallbl.frame = CGRectMake(50 , _ExplanationView.frame.origin.y+70, 300, 1);
        strl =@"Selected";
    }
    else{
        
        _Normallbl.frame = CGRectMake(50 , _Explainlbl.frame.origin.y+45, 300, 1);
        _ExpLbl.hidden =YES;
        _ExplanationView.hidden =YES;
        
        _Submit_Button.frame = CGRectMake(111 , _Explainlbl.frame.origin.y+60, 149, 30);
         _ExpLbl.hidden =YES;
         _ExplanationView.hidden =YES;
       
        
    }
    
}

-(void)get_checkbox
{
    
    
    
    NSArray *ad =[[NSArray alloc]initWithObjects:idd5, nil];
    
    
    namesArray =[[NSMutableArray alloc]initWithObjects:idd1,idd2,idd3,idd4,idd5,idd6,idd7,idd8,idd9,idd10,idd11,idd12,idd13,idd14,idd15,idd16,idd17, nil];
    
    
    
    
   mainArray = [[NSMutableArray alloc]init];
    for (int i = 0; i < [namesArray count]; i++) {
        NSString *obj = [namesArray objectAtIndex:i];
        if (![obj isEqualToString:@"00"]) { // or if (![obj  isKindOfClass:[[NSNull null]class]]) {
            [mainArray addObject:obj];
        }
    }
    
    
//    NSMutableString *sb = [[NSMutableString alloc] init];
//    for (int i=0; i < [mainArray count]; i++)  {
//
//        if(i<[mainArray count]-1)
//        {
//
//            [mainArray componentsJoinedByString: @", "];
//          //  [sb appendString:@",",[mainArray objectAtIndex:i]];
//        }
//        else
//        {
//
//           // [sb appendString:@",",[mainArray objectAtIndex:i]];
//            [sb appendString:@","];
//        }
//    }
//
    
    
    alertString = [mainArray componentsJoinedByString:@","];
  
    
    
    
 
    
    
}


    
    
    // toggle the selected property, just a simple BOOL
    

-(void) viewDidLayoutSubviews
{
    
    NSLog(@"ButtonPOsition %f",_Submit_Button.frame.origin.y);
    
    int inter =_Submit_Button.frame.origin.y;
    
    
   NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
//
//
//
//
    _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2800);
NSLog(@"%f",[UIScreen mainScreen].bounds.size.height);
    
    int height =[UIScreen mainScreen].bounds.size.height;
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
                
            case 2436:
                
               _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3400);
                printf("iPhone X");
                break;
            default:
                 _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3200);
                if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
                if (height == 480) {
                    _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2200);
                    printf("unknown");
                }
                else{
                      _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2800);
                  
                    printf("unknown");
                }
                }
        }
             
        }
        
    
    
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)SetupView
{
    
  
    self.CompanyView.layer.cornerRadius = 8.0 ;
    self.CompanyView.clipsToBounds = true;
    
    self.CompanyView.layer.borderWidth = 1.0f;
    self.CompanyView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.ListingView.layer.cornerRadius = 8.0 ;
    self.ListingView.clipsToBounds = true;
    
    self.ListingView.layer.borderWidth = 1.0f;
    self.ListingView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    
    self.DateView.layer.cornerRadius = 8.0 ;
    self.DateView.clipsToBounds = true;
    
    self.DateView.layer.borderWidth = 1.0f;
    self.DateView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.ProjectView.layer.cornerRadius = 8.0 ;
    self.ProjectView.clipsToBounds = true;
    
    self.ProjectView.layer.borderWidth = 1.0f;
    self.ProjectView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.TimeView.layer.cornerRadius = 8.0 ;
    self.TimeView.clipsToBounds = true;
    
    self.TimeView.layer.borderWidth = 1.0f;
    self.TimeView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Desctextview.layer.cornerRadius = 8.0 ;
    self.Desctextview.clipsToBounds = true;
    
    self.Desctextview.layer.borderWidth = 1.0f;
    self.Desctextview.layer.borderColor = [UIColor redColor].CGColor;
    
 
    
    self.RecomendedTextView.layer.cornerRadius = 8.0 ;
    self.RecomendedTextView.clipsToBounds = true;
    
    self.RecomendedTextView.layer.borderWidth = 1.0f;
    self.RecomendedTextView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.ActionPartyView.layer.cornerRadius = 8.0 ;
    self.ActionPartyView.clipsToBounds = true;
    
    self.ActionPartyView.layer.borderWidth = 1.0f;
    self.ActionPartyView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.ActionPerformmedView.layer.cornerRadius = 8.0 ;
    self.ActionPerformmedView.clipsToBounds = true;
    
    self.ActionPerformmedView.layer.borderWidth = 1.0f;
    self.ActionPerformmedView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.ExplanationView.layer.cornerRadius = 8.0 ;
    self.ExplanationView.clipsToBounds = true;
    
    self.ExplanationView.layer.borderWidth = 1.0f;
    self.ExplanationView.layer.borderColor = [UIColor redColor].CGColor;
    
    
}



@end
