//
//  LoginVC.h
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController
@property(nonatomic,strong)IBOutlet UITextField*UsernameTxt;
@property(nonatomic,strong)IBOutlet UITextField*PasswordTxt;
@property(nonatomic,strong)IBOutlet UIView *Usernameview;
@property(nonatomic,strong)IBOutlet UIView *Passwordview;
@end
