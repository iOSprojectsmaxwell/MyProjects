//
//  LoginVC.m
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "LoginVC.h"
#import "Common.h"
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "Common.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "GoalZeroVC.h"
#import "HomeView.h"
#import "RegisterView.h"
@interface LoginVC ()
<MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSArray *response;
    NSString *User_name;
    NSString *dept_name;
    NSString *company_name;
    NSString *emp_no;
    NSString *designation;
    NSString *userid;
    
  
}
@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%f",[UIScreen mainScreen].bounds.size.height);
    
    
    self.navigationController.navigationBar.hidden =YES;
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    self.Usernameview.layer.cornerRadius = 8.0 ;
    self.Usernameview.clipsToBounds = true;
    
    self.Usernameview.layer.borderWidth = 1.0f;
    self.Usernameview.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Passwordview.layer.cornerRadius = 8.0 ;
    self.Passwordview.clipsToBounds = true;
    
    self.Passwordview.layer.borderWidth = 1.0f;
    self.Passwordview.layer.borderColor = [UIColor redColor].CGColor;
    // Do any additional setup after loading the view.
}

-(IBAction)Register_View:(id)sender{
    
   
    RegisterView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"RegisterView"];
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)Login_button:(id)sender{
    
    if (_UsernameTxt.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter Username"];
    }
    else if (_PasswordTxt.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter your password"];
    }
    else{
        
        [self calling_webServicsfor_banner];
    }
    
}

-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
  
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/login.php?user_name=%@&pswd=%@",self->_UsernameTxt.text,self->_PasswordTxt.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        self->dict2=[sampleURL JSONValue];
        NSLog(@"Login Details %@",self->dict2);
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[[dict2 valueForKey:@"login"]objectAtIndex:0]
            ;
       
            self->User_name =[self->response valueForKey:@"user_name"];
           self->dept_name =[self->response valueForKey:@"dept_name"];
            self->company_name =[self->response valueForKey:@"company_name"];
           self->emp_no =[self->response valueForKey:@"emp_no"];
         self->designation =[self->response valueForKey:@"designation"];
           self->userid =[self->response valueForKey:@"userid"];
            
            [[NSUserDefaults standardUserDefaults] setObject:self->User_name forKey:@"user_name"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSUserDefaults standardUserDefaults] setObject:self->dept_name forKey:@"dept_name"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setObject:self->company_name forKey:@"company_name"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSUserDefaults standardUserDefaults] setObject:self->emp_no forKey:@"emp_no"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setObject:self->designation forKey:@"designation"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSUserDefaults standardUserDefaults] setObject:self->userid forKey:@"userid"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
         
            
            HomeView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeView"];
            [self.navigationController pushViewController:controller animated:YES];
           
            [HUD hide:YES];
            
        });
    });
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
