//
//  MyNewObseravationVC.h
//  GoalZero
//
//  Created by user on 18/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNewObseravationVC : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *ScrollViewsc;
@property (weak, nonatomic) IBOutlet UIView *Name_View;
@property (weak, nonatomic) IBOutlet UITextField *NameFeild;

@property (weak, nonatomic) IBOutlet UIView *Employee_view;
@property (weak, nonatomic) IBOutlet UITextField *Employee_Feild;

@property (weak, nonatomic) IBOutlet UIView *Company_view;
@property (weak, nonatomic) IBOutlet UITextField *Comapny_Feild;

@property (weak, nonatomic) IBOutlet UIView *Designation_View;
@property (weak, nonatomic) IBOutlet UITextField *Designation_Feild;

@property (weak, nonatomic) IBOutlet UIView *LocationObservation_View;
@property (weak, nonatomic) IBOutlet UITextField *LocationObservation_Feild;
@property(nonatomic,strong)IBOutlet UIView*blurescreen;

@property (weak, nonatomic) IBOutlet UIView *Date_View;
@property (weak, nonatomic) IBOutlet UITextField *Date_Feild;

@property (weak, nonatomic) IBOutlet UIView *Project_View;
@property (weak, nonatomic) IBOutlet UITextField *Project_feild;


@property (weak, nonatomic) IBOutlet UIView *Time_View;
@property (weak, nonatomic) IBOutlet UITextField *Time_Feild;



@property (weak, nonatomic) IBOutlet UIView *Actionby_View;
@property (weak, nonatomic) IBOutlet UITextField *ActionBy_Feild;


@property (weak, nonatomic) IBOutlet UITextView *DescObservation_Text;

@property (weak, nonatomic) IBOutlet UITextView *Taken_Text;

@property (weak, nonatomic) IBOutlet UIButton *Submit_Button;
@property (weak, nonatomic) IBOutlet UIButton *Choose_Button;

@property (weak, nonatomic) IBOutlet UIButton *Radio_Button_P;
@property (weak, nonatomic) IBOutlet UIButton *Radio_Button_N;

@property(nonatomic,strong)IBOutlet UIView *leftview;
@property(nonatomic,strong)IBOutlet UIView *rightview;

@property(nonatomic,strong)IBOutlet UILabel *harmlbl;
@property(nonatomic,strong)IBOutlet UILabel *leakslbl;



@end
