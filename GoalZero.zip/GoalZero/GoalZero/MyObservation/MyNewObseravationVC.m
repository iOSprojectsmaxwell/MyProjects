//
//  MyNewObseravationVC.m
//  GoalZero
//
//  Created by user on 18/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "MyNewObseravationVC.h"
#import "MBProgressHUD.h"
#import "JSON.h"
#import "CLPopListView.h"
#import "ViewController.h"
#import "Common.h"
@interface MyNewObseravationVC ()<MBProgressHUDDelegate>
{
    NSString *status;
    UIImage* radioOff;
    UIImage* radioOn;
    UIImage* nonCheckedImage;
    UIImage* CheckedImage;
    NSString *strl;
     UIDatePicker *picker;
    MBProgressHUD *HUD;
     NSString *currentTime;
      NSString *alertString;
    NSString *alertString1;
    
    NSString *selected;
     NSString *selected1;
    NSString *idd1;
     NSString *idd2;
     NSString *idd3;
     NSString *idd4;
     NSString *idd5;
     NSString *idd6;
     NSString *idd7;
     NSString *idd8;
     NSString *idd9;
     NSString *idd10;
     NSString *idd11;
    NSString *idd12;
    NSString *idd13;
    NSString *idd14;
    NSString *idd15;
    NSString *idd16;
    NSString *idd17;
    NSString *idd18;
    NSArray *CheckboxArrray1;
    NSMutableArray *CheckboxArrray2;
    NSMutableArray *namesArray;
    NSString *bidd1;
    NSString *bidd2;
    NSString *bidd3;
    NSString *bidd4;
    NSString *bidd5;
    NSString *bidd6;
    NSString *bidd7;
    NSString *bidd8;
    NSString *bidd9;
    NSString *bidd10;
    NSString *bidd11;
    NSString *bidd12;
    NSString *bidd13;
    NSString *bidd14;
    NSString *bidd15;
    NSString *bidd16;
    NSString *bidd17;
    NSString *bidd18;
    
    NSMutableArray *mainArray;
    UIDatePicker *datePicker;
    NSString *harms;
    NSString *leaks;
         NSMutableArray *mainArray1;
        NSArray  *actionby_company;
    NSArray  *company_namearray;
    NSString *postive;
    NSString *close;
    NSString *User_name;
    NSString *company_name;
    NSString *emp_no;
    NSString *designation;
    NSString *userid;
     ViewController *objSideMenuView;
    NSDictionary *dict2;
    NSArray *response;
    NSString *Images;
    NSArray *location;
    NSArray *project;
    NSArray *areaname;
    NSArray *project_name;
NSString *selectedLocation;
}
@property (weak, nonatomic) IBOutlet UILabel *ExplainLbl;
@property (weak, nonatomic) IBOutlet UIButton *Explainbtn;
@property (weak, nonatomic) IBOutlet UIView *NegativeView;
@property (weak, nonatomic) IBOutlet UILabel *ExplainobjLbl;
@property (weak, nonatomic) IBOutlet UITextView *ExplaintextBox;
@property (weak, nonatomic) IBOutlet UILabel *Labl;


@property (weak, nonatomic) IBOutlet UIView *FinalView;
@property (weak, nonatomic) IBOutlet UIButton *Closebtn;
@property (weak, nonatomic) IBOutlet UIButton *Forther_btn;



@property (weak, nonatomic) IBOutlet UIButton *A1;
@property (weak, nonatomic) IBOutlet UIButton *A2;
@property (weak, nonatomic) IBOutlet UIButton *A3;
@property (weak, nonatomic) IBOutlet UIButton *A4;

@property (weak, nonatomic) IBOutlet UIButton *A5;
@property (weak, nonatomic) IBOutlet UIButton *A6;
@property (weak, nonatomic) IBOutlet UIButton *A7;
@property (weak, nonatomic) IBOutlet UIButton *A8;
@property (weak, nonatomic) IBOutlet UIButton *A9;

@property (weak, nonatomic) IBOutlet UIButton *A10;
@property (weak, nonatomic) IBOutlet UIButton *A11;

@property (weak, nonatomic) IBOutlet UIButton *A12;

@property (weak, nonatomic) IBOutlet UIButton *A13;
@property (weak, nonatomic) IBOutlet UIButton *A14;
@property (weak, nonatomic) IBOutlet UIButton *A15;

@property (weak, nonatomic) IBOutlet UIButton *A16;

@property (weak, nonatomic) IBOutlet UIButton *A17;

@property (weak, nonatomic) IBOutlet UIButton *A18;



@property (weak, nonatomic) IBOutlet UIButton *B1;

@property (weak, nonatomic) IBOutlet UIButton *B2;
@property (weak, nonatomic) IBOutlet UIButton *B3;
@property (weak, nonatomic) IBOutlet UIButton *B4;

@property (weak, nonatomic) IBOutlet UIButton *B5;

@property (weak, nonatomic) IBOutlet UIButton *B6;

@property (weak, nonatomic) IBOutlet UIButton *B7;

@property (weak, nonatomic) IBOutlet UIButton *B8;

@property (weak, nonatomic) IBOutlet UIButton *B9;


@property (weak, nonatomic) IBOutlet UIButton *B10;

@property (weak, nonatomic) IBOutlet UIButton *B11;

@property (weak, nonatomic) IBOutlet UIButton *B12;
@property (weak, nonatomic) IBOutlet UIButton *B13;

@property (weak, nonatomic) IBOutlet UIButton *B14;

@property (weak, nonatomic) IBOutlet UIButton *B15;

@property (weak, nonatomic) IBOutlet UIButton *B16;
@property (weak, nonatomic) IBOutlet UIButton *B17;
@property (weak, nonatomic) IBOutlet UIButton *B18;

@property (weak, nonatomic) IBOutlet UIImageView *document_image;




@end

@implementation MyNewObseravationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    CGFloat Height = self.view.frame.size.height;
    CGFloat Width = self.view.frame.size.width;

   
    harms = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"harms"];
    _harmlbl.text =harms;
            
            leaks = [[NSUserDefaults standardUserDefaults]
                     stringForKey:@"leaks"];
    _leakslbl.text =leaks;
    
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    _document_image.hidden =YES;
    _blurescreen.hidden=YES;
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.blurescreen addGestureRecognizer:singleFingerTap];
    [self calling_webServicsfor_banner];
    User_name = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"user_name"];
    
    _NameFeild.text =User_name;
    
    company_name = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"company_name"];
    
    
    idd1 =@"00";
    idd2 =@"00";
    idd3=@"00";
    idd4=@"00";
    idd5=@"00";
    idd6=@"00";
   idd7=@"00";
   idd8=@"00";
    idd9=@"00";
    idd10=@"00";
    idd11=@"00";
    idd12=@"00";
    idd13=@"00";
    idd14=@"00";
    idd15=@"00";
    idd16=@"00";
    idd17=@"00";
   idd18=@"00";
    
    postive =@"emity";
    close =@"emity";
    selected =@"emity";
    selected1 =@"emity";
    _Comapny_Feild.text =company_name;
    
//    company_name = [[NSUserDefaults standardUserDefaults]
//                 stringForKey:@"company_name"];
    
    emp_no = [[NSUserDefaults standardUserDefaults]
                    stringForKey:@"emp_no"];
    
    _Employee_Feild.text =emp_no;
    self.leftview.layer.cornerRadius = 8.0 ;
    self.leftview.clipsToBounds = true;
    
    self.leftview.layer.borderWidth = 1.0f;
    self.leftview.layer.borderColor = [UIColor redColor].CGColor;
    self.rightview.layer.cornerRadius = 8.0 ;
    self.rightview.clipsToBounds = true;
    
    self.rightview.layer.borderWidth = 1.0f;
    self.rightview.layer.borderColor = [UIColor redColor].CGColor;
    
    designation = [[NSUserDefaults standardUserDefaults]
                    stringForKey:@"designation"];
    _Designation_Feild.text =designation;
    
    userid = [[NSUserDefaults standardUserDefaults]
              stringForKey:@"userid"];
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
    
    _Date_Feild.text =[NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    
    
    
    NSDateFormatter *dateFormatter1=[[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"hh:mm:ss a"];
    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
    NSLog(@"%@",[dateFormatter1 stringFromDate:[NSDate date]]);
      _Time_Feild.text =[NSString stringWithFormat:@"%@",[dateFormatter1 stringFromDate:[NSDate date]]];
    
    nonCheckedImage=[UIImage imageNamed:@"icons8-unchecked-checkbox-filled-50.png"];//[UIImage init
    CheckedImage=[UIImage imageNamed:@"CheckBoxFill.png"];
    
    
    radioOff=[UIImage imageNamed:@"RadioEmty.png"];//[UIImage init
    radioOn=[UIImage imageNamed:@"RadioButton_Filled.png"];
    [self setup_View];
    [self Check_Box];
  
    
    [_Explainbtn setImage:CheckedImage forState:UIControlStateSelected];
    [_Explainbtn setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
   
 
     _NegativeView.hidden =YES;
     _ExplainobjLbl.hidden =YES;
  
     _Labl.frame = CGRectMake(50 , _ExplainobjLbl.frame.origin.y+25, 300, 1);
    
    _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
    
}

-(void)datePicker{
     datePicker.hidden=NO;
    datePicker=[[UIDatePicker alloc]init];
    datePicker.datePickerMode=UIDatePickerModeTime;
    [_Time_Feild setInputView:datePicker];
    datePicker.backgroundColor =[UIColor orangeColor];
    UIToolbar *toolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    [_Time_Feild setInputAccessoryView:toolBar];
}



-(void)ShowSelectedDate
{   NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm:ss"];
    currentTime = [dateFormatter stringFromDate:datePicker.date];
    _Time_Feild.text=[NSString stringWithFormat:@"%@",currentTime];
    [_Time_Feild resignFirstResponder];
}
-(IBAction)time_piker:(id)sender
{
    [self datePicker];
    datePicker.hidden =NO;
    
}

- (void)dateChanged:(id)sender
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm:ss"];
    currentTime = [dateFormatter stringFromDate:picker.date];
    NSLog(@"%@", currentTime);
}

-(void)PressDone:(id)sender
{
    _Time_Feild.text =currentTime;
    picker.hidden =NO;
    
}
- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
    _blurescreen.hidden=YES;
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    //Do stuff here...
}

- (IBAction)Documant_Upload:(id)sender {
    
       [self showActionSheet];
    
}

- (void)showActionSheet{
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:@"Choose From" preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped.
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Gallery" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
        imgpicker.allowsEditing = YES;
        imgpicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imgpicker.delegate=(id)self;
        [self presentViewController:imgpicker animated:YES completion:nil];
        ////         Distructive button tapped.
        //                [self dismissViewControllerAnimated:YES completion:^{
        //                }];
    }]];
    
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Sorry"
                                         message:@"No camera detected"
                                         preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action =[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
                
                
            }];
            
            
            [alert addAction:action];
            
            [self presentViewController:alert animated:YES completion:nil];
        }else{
            
            UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
            imgpicker.allowsEditing = YES;
            imgpicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            imgpicker.delegate=(id)self;
            [self presentViewController:imgpicker animated:YES completion:nil];
            
        }
        // OK button tapped.
        
        //        [self dismissViewControllerAnimated:YES completion:^{
        //        }];
    }]];
    
    // Present action sheet.
    [self presentViewController:actionSheet animated:YES completion:nil];
    
    
    
    // OK button tapped.
    
    //        [self dismissViewControllerAnimated:YES completion:^{
    //        }];
    
}
- (IBAction)btnActnChoosePic:(id)sender {
    
 
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage =[info valueForKey:UIImagePickerControllerOriginalImage];
    
    chosenImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    self.document_image.image = chosenImage;
    _document_image.hidden =NO;
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)Menu:(id)sender {
    
    
    
    _blurescreen.hidden=NO;
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (ViewController *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+3, 270, 600);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@" " forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}



-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/menu_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[dict2 valueForKey:@"response"];
            
            location =[response valueForKey:@"location"];
            project=[response valueForKey:@"project"];
             actionby_company=[response valueForKey:@"actionby_company"];
            
         
            
            
            
            areaname =[location valueForKey:@"areaname"];
            project_name =[project valueForKey:@"project_name"];
             company_namearray =[actionby_company valueForKey:@"company_name"];
            [HUD hide:YES];
            
        });
    });
    
}







-(IBAction)Location:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Location of Observation" options:areaname handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=100;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Project:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Project" options:project_name handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=101;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)Company_names:(id)sender{
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Company" options:company_namearray handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=102;
    [lplv showInView:self.view.window animated:YES];
    
    
    
}
    
- (void)leveyPopListView:(CLPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    if(popListView.tag==100)
    {
        
        
        //btnEventSize.titleLabel.text = [DurationArray objectAtIndex:anIndex];
        selectedLocation = [NSString stringWithFormat:@"  %@",[areaname objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _LocationObservation_Feild.text =selectedLocation;
        
    }
    
    else if (popListView.tag==101)
    {
        NSString *project;
        project = [NSString stringWithFormat:@"  %@",[project_name objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Project_feild.text =project;
        
        
    }
    else if (popListView.tag==102)
    {
        NSString *company;
        company = [NSString stringWithFormat:@"  %@",[company_namearray objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Comapny_Feild.text =company;
        
        
    }
    
}



    


- (IBAction)Close_Button:(id)sender {
    
    close =@"1";
    [_Closebtn setImage:radioOn forState:UIControlStateNormal];
    [_Forther_btn setImage:radioOff forState:UIControlStateNormal];
    
}
- (IBAction)Further_Button:(id)sender {
     close =@"2";
    [_Closebtn setImage:radioOff forState:UIControlStateNormal];
    [_Forther_btn setImage:radioOn forState:UIControlStateNormal];
}

-(IBAction)Register_Button:(id)sender{
      [self get_checkbox];
    if (_Comapny_Feild.text.length==0) {
        [Common AlertShowWithErrorMsg:@"Please select your Company"];
    }
    else if (_LocationObservation_Feild.text.length==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Location of Observation"];
        
    }
    else if (_Date_Feild.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please select date"];
    }
    else if (_Project_feild.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please select your project"];
    }
    else if (_Time_Feild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Time"];
        
    }
    
    else if ([postive isEqualToString:@"emity"])
    {
         [Common AlertShowWithErrorMsg:@"Please select Type of Observation"];
        
    }
    else if (_DescObservation_Text.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Desctiption of Observation"];
        
    }
    else if (_Taken_Text.text.length ==0)
    {
        
        [Common AlertShowWithErrorMsg:@"Please enter Immediate Corrective Action Taken"];
    }
    else if ([close isEqualToString:@"emity"])
    {
        
        [Common AlertShowWithErrorMsg:@"Please select Action Status"];
    }
    else if (_ActionBy_Feild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter Action by"];
        
    }
    else if ([selected isEqualToString:@"emity"])
    {
        [Common AlertShowWithErrorMsg:@"Please select Activities"];
        
    }
    else if ([postive isEqualToString:@"2"])
    {
        if ([selected1 isEqualToString:@"emity"]) {
           [Common AlertShowWithErrorMsg:@"Please select Negative observations"];
        }
        
    }
   
    
    else{
        [self get_checkbox];
      //  [self.navigationController popViewControllerAnimated:YES];
        
        
    }
}





- (IBAction)Positive_Button:(id)sender {
    
    _NegativeView.hidden =YES;
    status =@"Positive";
     postive =@"1";
    _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
                
            case 2436:
                
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 4060);
                printf("iPhone X");
                break;
            default:
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3680);
                printf("unknown");
        }
        
    }
    
    
   
     [_Radio_Button_P setImage:radioOn forState:UIControlStateNormal];
      [_Radio_Button_N setImage:radioOff forState:UIControlStateNormal];
    
    
}



- (IBAction)negativeov_button:(id)sender {
    
    [_Radio_Button_P setImage:radioOff forState:UIControlStateNormal];
    [_Radio_Button_N setImage:radioOn forState:UIControlStateNormal];
    
    _NegativeView.hidden =NO;
       postive =@"2";
    status =@"Negative";
    _NegativeView.frame = CGRectMake( _NegativeView.frame.origin.x ,_Labl.frame.origin.y+25, _NegativeView.frame.size.width, _NegativeView.frame.size.height);
    _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_NegativeView.frame.origin.y+380, _FinalView.frame.size.width, _FinalView.frame.size.height);
    
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
                
            case 2436:
                
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 4500);
                printf("iPhone X");
                break;
            default:
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 4060);
                printf("unknown");
        }
        
    }
    
   
    
}













































//-(IBAction)negative_button:(id)sender{
//    
//    
//}
//-(IBAction)Positive_button:(id)sender{
//    
//   
//}
-(void) viewDidLayoutSubviews
{
    
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    //
    //
    //
    //
    NSLog(@"%f",[UIScreen mainScreen].bounds.size.height);
    
    int height =[UIScreen mainScreen].bounds.size.height;

    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2200);
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                
                if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
                 if (height == 480) {
                      _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2900);
                 }
                else if (height == 667)
                {
                     _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3400);
                }
                }
                 else{
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3400);
                printf("iPhone 6/6S/7/8");
                 }
                break;
            case 1920:
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3000);
                
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
             _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3600);
                
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
                
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 4000);
                printf("iPhone X");
                break;
            default:
                
                if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
                    if (height == 480) {
                         _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2400);
                        printf("unknown");
                    }
                    else{
                       _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 2900);
                        
                        printf("unknown");
                    }
                }
               
        }
        
    }
    
    
}

- (IBAction)Explains:(id)sender {
    _Explainbtn.selected = !_Explainbtn.selected;
    if (_Explainbtn.selected ==YES) {
      
        if ([status isEqualToString:@"Negative"]) {
            _NegativeView.hidden=NO;
            _ExplainobjLbl.hidden =NO;
            _ExplaintextBox.hidden =NO;
            //_Submit_Button.frame = CGRectMake(111 , _ExplanationView.frame.origin.y+90, 149, 30);
            
            
            
            _Labl.frame = CGRectMake(50 , _ExplaintextBox.frame.origin.y+70, 300, 1);
            
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
            _NegativeView.frame = CGRectMake( _NegativeView.frame.origin.x ,_Labl.frame.origin.y+25, _NegativeView.frame.size.width, _NegativeView.frame.size.height);
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+380, _FinalView.frame.size.width, _FinalView.frame.size.height);
        }
        else{
            
            
            if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
                
                switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                        
                  
                    case 2436:
                       
                        _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 5000);
                        printf("iPhone X");
                        break;
                    default:
                         _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3680);
                        printf("unknown");
                }
                
            }
            
            
             _NegativeView.hidden=YES;
            
            _ExplainobjLbl.hidden =NO;
            _ExplaintextBox.hidden =NO;
            //_Submit_Button.frame = CGRectMake(111 , _ExplanationView.frame.origin.y+90, 149, 30);
            
            
            
            _Labl.frame = CGRectMake(50 , _ExplaintextBox.frame.origin.y+70, 300, 1);
            
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
            _NegativeView.frame = CGRectMake( _NegativeView.frame.origin.x ,_Labl.frame.origin.y+25, _NegativeView.frame.size.width, _NegativeView.frame.size.height);
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
        }
        
      
       // strl =@"Selected";
    }
    else{
        
        if ([status isEqualToString:@"Negative"]) {
            _NegativeView.hidden=NO;
            
            _Labl.frame = CGRectMake(50 , _ExplainobjLbl.frame.origin.y+25, 300, 1);
            
            _ExplainobjLbl.hidden =YES;
            _ExplaintextBox.hidden =YES;
            _NegativeView.frame = CGRectMake( _NegativeView.frame.origin.x ,_Labl.frame.origin.y+25, _NegativeView.frame.size.width, _NegativeView.frame.size.height);
            // _Submit_Button.frame = CGRectMake(111 , _Explainlbl.frame.origin.y+60, 149, 30);
            //_ExpLbl.hidden =YES;
            _ExplaintextBox.hidden =YES;
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+380, _FinalView.frame.size.width, _FinalView.frame.size.height);
        }
        else{
            
            _Labl.frame = CGRectMake(50 , _ExplainobjLbl.frame.origin.y+25, 300, 1);
            
            _ExplainobjLbl.hidden =YES;
            _ExplaintextBox.hidden =YES;
            _NegativeView.frame = CGRectMake( _NegativeView.frame.origin.x ,_Labl.frame.origin.y+25, _NegativeView.frame.size.width, _NegativeView.frame.size.height);
            // _Submit_Button.frame = CGRectMake(111 , _Explainlbl.frame.origin.y+60, 149, 30);
            //_ExpLbl.hidden =YES;
            _ExplaintextBox.hidden =YES;
            _FinalView.frame = CGRectMake( _FinalView.frame.origin.x ,_Labl.frame.origin.y+25, _FinalView.frame.size.width, _FinalView.frame.size.height);
            _NegativeView.hidden=YES;
        }
        
        
        
        
    }
    
}




-(void)setup_View
{
    
   
    self.ExplaintextBox.layer.cornerRadius = 8.0 ;
    self.ExplaintextBox.clipsToBounds = true;
    
    self.ExplaintextBox.layer.borderWidth = 1.0f;
    self.ExplaintextBox.layer.borderColor = [UIColor redColor].CGColor;
    
    self.Name_View.layer.cornerRadius = 8.0 ;
    self.Name_View.clipsToBounds = true;
    
    self.Name_View.layer.borderWidth = 1.0f;
    self.Name_View.layer.borderColor = [UIColor redColor].CGColor;
    
  
  
    self.Company_view.layer.cornerRadius = 8.0 ;
    self.Company_view.clipsToBounds = true;
    
    self.Company_view.layer.borderWidth = 1.0f;
    self.Company_view.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Employee_view.layer.cornerRadius = 8.0 ;
    self.Employee_view.clipsToBounds = true;
    
    self.Employee_view.layer.borderWidth = 1.0f;
    self.Employee_view.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.LocationObservation_View.layer.cornerRadius = 8.0 ;
    self.LocationObservation_View.clipsToBounds = true;
    
    self.LocationObservation_View.layer.borderWidth = 1.0f;
    self.LocationObservation_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Designation_View.layer.cornerRadius = 8.0 ;
    self.Designation_View.clipsToBounds = true;
    
    self.Designation_View.layer.borderWidth = 1.0f;
    self.Designation_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    self.Project_View.layer.cornerRadius = 8.0 ;
    self.Project_View.clipsToBounds = true;
    
    self.Project_View.layer.borderWidth = 1.0f;
    self.Project_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Date_View.layer.cornerRadius = 8.0 ;
    self.Date_View.clipsToBounds = true;
    
    self.Date_View.layer.borderWidth = 1.0f;
    self.Date_View.layer.borderColor = [UIColor redColor].CGColor;
    
  
    self.Submit_Button.layer.cornerRadius = 8.0 ;
    self.Submit_Button.clipsToBounds = true;
    
    self.Submit_Button.layer.borderWidth = 1.0f;
    self.Submit_Button.layer.borderColor = [UIColor clearColor].CGColor;
    
    self.Choose_Button.layer.cornerRadius = 8.0 ;
    self.Choose_Button.clipsToBounds = true;
    
    self.Choose_Button.layer.borderWidth = 1.0f;
    self.Choose_Button.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    
    self.Actionby_View.layer.cornerRadius = 8.0 ;
    self.Actionby_View.clipsToBounds = true;
    
    self.Actionby_View.layer.borderWidth = 1.0f;
    self.Actionby_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Time_View.layer.cornerRadius = 8.0 ;
    self.Time_View.clipsToBounds = true;
    
    self.Time_View.layer.borderWidth = 1.0f;
    self.Time_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    
    self.Taken_Text.layer.cornerRadius = 8.0 ;
    self.Taken_Text.clipsToBounds = true;
    
    self.Taken_Text.layer.borderWidth = 1.0f;
    self.Taken_Text.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.DescObservation_Text.layer.cornerRadius = 8.0 ;
    self.DescObservation_Text.clipsToBounds = true;
    
    self.DescObservation_Text.layer.borderWidth = 1.0f;
    self.DescObservation_Text.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
}


//-(void)upload_data
//{
//
//    [HUD show:YES];
//    NSString *data;
//    NSString *urlstring;
//
//    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
//    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
//
//    // send a block to the queue - Not in Main thread
//    dispatch_async(queue, ^{
//        // data processing
//
//        //        http://www.goalzero.qa/main/api/new_listening_observation.php?user_id=2315&obv_date=2018-08-20&obv_time=10:00:7&project_id=16&location_id=16&description=Testing&observation_type=1&action_desc=Testing&action_by=Testing&action_type=1&action_perform=testing&risk=1,2,3&explain_text=Testing
//        //
//
//        NSString *Desc =[_DescObservation_Text.text stringByReplacingOccurrencesOfString:@" " withString:@""];
//
//
//
//        NSString *taken = [_Taken_Text.text stringByReplacingOccurrencesOfString:@" " withString:@""];
//
//
//
//        NSString *action_by = [_ActionBy_Feild.text stringByTrimmingCharactersInSet:
//                                  [NSCharacterSet whitespaceAndNewlineCharacterSet]];
//
//
//
//
//        NSString *explanation = [_ExplaintextBox.text stringByReplacingOccurrencesOfString:@" " withString:@""];
//
//
//
//        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/new_listening_observation.php?user_id=%@&obv_date=%@&obv_time=%@&project_id=%@&location_id=%@&description=%@&observation_type=%@&action_desc=%@&action_by=%@&action_type=%@&action_perform=%@&risk=%@&explain_text=%@",userid,_dateTxt.text,_timetTxt.text,project_idstr,location_idstr,Desc,postive,postiveaction,action_party,close,postiveaction,alertString,self->_ExplanationView.text];
//
//
//        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
//
//        dict2=[sampleURL JSONValue];
//
//        // image_tpic;
//
//        // Interaction with User Interface - Main thread
//        dispatch_async(dispatch_get_main_queue(), ^{
//            NSString *response1;
//            response1 =[dict2 valueForKey:@"response"];
//
//            if ([response1 isEqualToString:@"success"]) {
//
//                [Common AlertShowWithErrorMsg:@"your Listening Observation successfully submited"];
//                _LocationTxt.text =@"";
//                _ProjectTxt.text=@"";
//                [_Radio_Button_P setImage:radioOff forState:UIControlStateNormal];
//                [_Radio_Button_N setImage:radioOff forState:UIControlStateNormal];
//                _Desctextview.text =@"";
//
//                _RecomendedTextView.text =@"";
//                _Action_PartyTXT.text =@"";
//
//                [_Closebtn setImage:radioOff forState:UIControlStateNormal];
//                [_Forther_btn setImage:radioOff forState:UIControlStateNormal];
//                _Action_PerformedTXT.text =@"";
//                _ExplanationView.text =@"";
//            }
//            else{
//
//                [Common AlertShowWithErrorMsg:@"Please check all feild your given something wrong"];
//            }
//
//
//            [HUD hide:YES];
//
//        });
//    });
//
//
//
//}





-(void)Check_Box
{
    
    [_A1 setImage:CheckedImage forState:UIControlStateSelected];
    [_A1 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A2 setImage:CheckedImage forState:UIControlStateSelected];
    [_A2 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A3 setImage:CheckedImage forState:UIControlStateSelected];
    [_A3 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A4 setImage:CheckedImage forState:UIControlStateSelected];
    [_A4 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A5 setImage:CheckedImage forState:UIControlStateSelected];
    [_A5 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A6 setImage:CheckedImage forState:UIControlStateSelected];
    [_A6 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A7 setImage:CheckedImage forState:UIControlStateSelected];
    [_A7 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A8 setImage:CheckedImage forState:UIControlStateSelected];
    [_A8 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A9 setImage:CheckedImage forState:UIControlStateSelected];
    [_A9 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A10 setImage:CheckedImage forState:UIControlStateSelected];
    [_A10 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A11 setImage:CheckedImage forState:UIControlStateSelected];
    [_A11 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A12 setImage:CheckedImage forState:UIControlStateSelected];
    [_A12 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    
    
    [_A13 setImage:CheckedImage forState:UIControlStateSelected];
    [_A13 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A14 setImage:CheckedImage forState:UIControlStateSelected];
    [_A14 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A15 setImage:CheckedImage forState:UIControlStateSelected];
    [_A15 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A16 setImage:CheckedImage forState:UIControlStateSelected];
    [_A16 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A17 setImage:CheckedImage forState:UIControlStateSelected];
    [_A17 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_A18 setImage:CheckedImage forState:UIControlStateSelected];
    [_A18 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
    
    [_B1 setImage:CheckedImage forState:UIControlStateSelected];
    [_B1 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B2 setImage:CheckedImage forState:UIControlStateSelected];
    [_B2 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B3 setImage:CheckedImage forState:UIControlStateSelected];
    [_B3 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B4 setImage:CheckedImage forState:UIControlStateSelected];
    [_B4 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B5 setImage:CheckedImage forState:UIControlStateSelected];
    [_B5 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B6 setImage:CheckedImage forState:UIControlStateSelected];
    [_B6 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B7 setImage:CheckedImage forState:UIControlStateSelected];
    [_B7 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B8 setImage:CheckedImage forState:UIControlStateSelected];
    [_B8 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B9 setImage:CheckedImage forState:UIControlStateSelected];
    [_B9 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B10 setImage:CheckedImage forState:UIControlStateSelected];
    [_B10 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B11 setImage:CheckedImage forState:UIControlStateSelected];
    [_B11 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B12 setImage:CheckedImage forState:UIControlStateSelected];
    [_B12 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B13 setImage:CheckedImage forState:UIControlStateSelected];
    [_B13 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B14 setImage:CheckedImage forState:UIControlStateSelected];
    [_B14 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B15 setImage:CheckedImage forState:UIControlStateSelected];
    [_B15 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B16 setImage:CheckedImage forState:UIControlStateSelected];
    [_B16 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B17 setImage:CheckedImage forState:UIControlStateSelected];
    [_B17 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    [_B18 setImage:CheckedImage forState:UIControlStateSelected];
    [_B18 setImage:nonCheckedImage forState:UIControlStateNormal];
    
    
}



- (IBAction)a1:(id)sender {
    _A1.selected = !_A1.selected;
    if (_A1.selected ==YES) {
        selected =@"selected";
        idd1 =@"1";
        

    }
    else{
         selected =@"emity";
        idd1 =@"00";
        
    }
    
}
- (IBAction)a2:(id)sender {
    _A2.selected = !_A2.selected;
    if (_A2.selected ==YES) {
         selected =@"selected";
    idd2 =@"2";
         [namesArray addObject:idd2];
    }
    else{
     idd2 =@"00";
        selected =@"emity";
    }
    
}
- (IBAction)a3:(id)sender {
    _A3.selected = !_A3.selected;
    if (_A3.selected ==YES) {
        selected =@"selected";
      idd3 =@"3";
         [namesArray addObject:idd3];
    }
    else{
         selected =@"emity";
       idd3 =@"00";
        
    }
    
}
- (IBAction)a4:(id)sender {
    _A4.selected = !_A4.selected;
    if (_A4.selected ==YES) {
         selected =@"selected";
      idd4 =@"4";
          [namesArray addObject:idd4];
    }
    else{
         selected =@"emity";
      idd4 =@"00";
        
    }
    
}
- (IBAction)a5:(id)sender {
    _A5.selected = !_A5.selected;
    if (_A5.selected ==YES) {
        selected =@"selected";
      idd5 =@"5";
         [namesArray addObject:idd5];
    }
    else{
         selected =@"emity";
       idd5 =@"00";
        
    }
    
}
- (IBAction)a6:(id)sender {
    _A6.selected = !_A6.selected;
    if (_A6.selected ==YES) {
         selected =@"selected";
       idd6 =@"6";
         [namesArray addObject:idd6];
    }
    else{
         selected =@"emity";
   idd6 =@"00";
        
    }
    
}
- (IBAction)a7:(id)sender {
    _A7.selected = !_A7.selected;
    if (_A7.selected ==YES) {
        selected =@"selected";
      idd7 =@"7";
        [namesArray addObject:idd7];
    }
    else{
         selected =@"emity";
      idd7 =@"00";
        
    }
    
}
-(IBAction)a8:(id)sender {
    _A8.selected = !_A8.selected;
    if (_A8.selected ==YES) {
        selected =@"selected";
     idd8 =@"8";
    }
    else{
         selected =@"emity";
       idd8 =@"00";
        
    }
    
}
- (IBAction)a9:(id)sender {
    _A9.selected = !_A9.selected;
    if (_A9.selected ==YES) {
        selected =@"selected";
     idd9 =@"9";
    }
    else{
         selected =@"emity";
       idd9 =@"00";
        
    }
    
}
- (IBAction)a10:(id)sender {
    _A10.selected = !_A10.selected;
    if (_A10.selected ==YES) {
       selected =@"selected";
      idd10 =@"10";
    }
    else{
         selected =@"emity";
       idd10 =@"00";
        
    }
    
}
- (IBAction)a11:(id)sender {
    _A11.selected = !_A11.selected;
    if (_A11.selected ==YES) {
        selected =@"selected";
      idd11 =@"11";
    }
    else{
         selected =@"emity";
      idd11 =@"00";
        
    }
    
}
- (IBAction)a12:(id)sender {
    _A12.selected = !_A12.selected;
    if (_A12.selected ==YES) {
         selected =@"selected";
       idd12 =@"12";
    }
    else{
         selected =@"emity";
    idd12 =@"00";
        
    }
    
}
- (IBAction)a13:(id)sender {
    _A13.selected = !_A13.selected;
    if (_A13.selected ==YES) {
        selected =@"selected";
      idd13 =@"13";
    }
    else{
         selected =@"emity";
    idd13 =@"00";
        
    }
    
}
- (IBAction)a14:(id)sender {
    _A14.selected = !_A14.selected;
    if (_A14.selected ==YES) {
         selected =@"selected";
       idd14 =@"14";
    }
    else{
         selected =@"emity";
       idd14 =@"00";
        
    }
    
}
- (IBAction)a15:(id)sender {
    _A15.selected = !_A15.selected;
    if (_A15.selected ==YES) {
         selected =@"selected";
       idd15 =@"15";
    }
    else{
         selected =@"emity";
     idd15 =@"00";
        
    }
    
}
- (IBAction)a16:(id)sender {
    _A16.selected = !_A16.selected;
    if (_A16.selected ==YES) {
         selected =@"selected";
      idd16 =@"16";
    }
    else{
         selected =@"emity";
      idd16 =@"00";
        
    }
    
}
- (IBAction)a17:(id)sender {
    _A17.selected = !_A17.selected;
    if (_A1.selected ==YES) {
       selected =@"selected";
    idd17 =@"17";
    }
    else{
         selected =@"emity";
      idd17 =@"00";
        
    }
    
}
- (IBAction)a18:(id)sender {
    _A18.selected = !_A18.selected;
    if (_A18.selected ==YES) {
         selected =@"selected";
        idd18 =[NSString stringWithFormat:@"18"];
    }
    else{
         selected =@"emity";
     idd18 =@"00";
        
    }
    
}
- (IBAction)b1:(id)sender {
    _B1.selected = !_B1.selected;
    if (_B1.selected ==YES) {
        selected1 =@"selected";
         bidd1 =@"1";
    }
    else{
        selected1 =@"emity";
       bidd1 =@"00";
        
    }
    
}
- (IBAction)b2:(id)sender {
    _B2.selected = !_B2.selected;
    if (_B2.selected ==YES) {
         selected1 =@"selected";
       bidd2 =@"2";
    }
    else{
        selected1 =@"emity";
       bidd2 =@"00";
        
    }
    
}
- (IBAction)b3:(id)sender {
    _B3.selected = !_B3.selected;
    if (_B3.selected ==YES) {
         selected1 =@"selected";
         bidd3 =@"3";
    }
    else{
      selected1 =@"emity";
        bidd3 =@"00";
        
    }
    
}
- (IBAction)b4:(id)sender {
    _B4.selected = !_B4.selected;
    if (_B4.selected ==YES) {
         selected1 =@"selected";
        bidd4 =@"4";
    }
    else{
      selected1 =@"emity";
        bidd4 =@"00";
        
    }
    
}
- (IBAction)b5:(id)sender {
    _B5.selected = !_B5.selected;
    if (_B5.selected ==YES) {
         selected1 =@"selected";
         bidd5 =@"5";
    }
    else{
        selected1 =@"emity";
        bidd5 =@"00";
        
    }
    
}
- (IBAction)b6:(id)sender {
    _B6.selected = !_B6.selected;
    if (_B6.selected ==YES) {
         selected1 =@"selected";
          bidd6 =@"6";
    }
    else{
       selected1 =@"emity";
       bidd6 =@"00";
        
    }
    
}
- (IBAction)b7:(id)sender {
    _B7.selected = !_B7.selected;
    if (_B7.selected ==YES) {
         selected1 =@"selected";
         bidd7 =@"7";
    }
    else{
        selected1 =@"emity";
     bidd7 =@"00";
        
    }
    
}
- (IBAction)b8:(id)sender {
    _B8.selected = !_B8.selected;
    if (_B8.selected ==YES) {
         selected1 =@"selected";
          bidd8 =@"8";
    }
    else{
         selected1 =@"emity";
       bidd8 =@"00";
        
    }
    
}
- (IBAction)b9:(id)sender {
    _B9.selected = !_B9.selected;
    if (_B9.selected ==YES) {
         selected1 =@"selected";
         bidd9 =@"9";
    }
    else{
         selected1 =@"emity";
      bidd9 =@"00";
        
    }
    
}
- (IBAction)b10:(id)sender {
    _B10.selected = !_B10.selected;
    if (_B10.selected ==YES) {
         selected1 =@"selected";
           bidd10 =@"10";
    }
    else{
         selected1 =@"emity";
         bidd10 =@"00";
        
    }
    
}
- (IBAction)b11:(id)sender {
    _B11.selected = !_B11.selected;
    if (_B11.selected ==YES) {
         selected1 =@"selected";
         bidd11 =@"11";
    }
    else{
         selected1 =@"emity";
        bidd11 =@"00";
        
    }
    
}
- (IBAction)b12:(id)sender {
    _B12.selected = !_B12.selected;
    if (_B12.selected ==YES) {
         selected1 =@"selected";
         bidd12 =@"12";
    }
    else{
         selected1 =@"emity";
        bidd12 =@"00";
        
    }
    
}
- (IBAction)b13:(id)sender {
    _B13.selected = !_B13.selected;
    if (_B13.selected ==YES) {
         selected1 =@"selected";
         bidd13 =@"13";
    }
    else{
         selected1 =@"emity";
       bidd13 =@"00";
        
    }
    
}

- (IBAction)b14:(id)sender {
    _B14.selected = !_B14.selected;
    if (_B14.selected ==YES) {
         selected1 =@"selected";
          bidd14 =@"14";
    }
    else{
         selected1 =@"emity";
        bidd14 =@"00";
        
    }
    
}
- (IBAction)b15:(id)sender {
    _B15.selected = !_B15.selected;
    if (_B15.selected ==YES) {
         selected1 =@"selected";
         bidd15 =@"15";
    }
    else{
         selected1 =@"emity";
       bidd15 =@"00";
        
    }
    
}
- (IBAction)b16:(id)sender {
    _B16.selected = !_B16.selected;
    if (_B16.selected ==YES) {
         selected1 =@"selected";
       bidd16 =@"16";
    }
    else{
         selected1 =@"emity";
       bidd16 =@"00";
        
    }
    
}
- (IBAction)b17:(id)sender {
    _B17.selected = !_B17.selected;
    if (_B17.selected ==YES) {
         selected1 =@"selected";
         bidd17 =@"17";
    }
    else{
         selected1 =@"emity";
        bidd17 =@"00";
        
    }
    
}
- (IBAction)b18:(id)sender {
    _B18.selected = !_B18.selected;
    if (_B18.selected ==YES) {
         selected1 =@"selected";
        bidd18 =[NSString stringWithFormat:@"18"];
    }
    else{
         selected1 =@"emity";
      bidd18 =@"00";
        
    }
    
}
-(void)get_checkbox
{
    
    
  
    NSArray *ad =[[NSArray alloc]initWithObjects:idd5, nil];
    
  
    namesArray =[[NSMutableArray alloc]initWithObjects:idd1,idd2,idd3,idd4,idd5,idd6,idd7,idd8,idd9,idd10,idd11,idd12,idd13,idd14,idd15,idd16,idd17,idd18, nil];
    
    
  
    
   mainArray = [[NSMutableArray alloc]init];
    for (int i = 0; i < [namesArray count]; i++) {
        NSString *obj = [namesArray objectAtIndex:i];
        if (![obj isEqualToString:@"00"]) { // or if (![obj  isKindOfClass:[[NSNull null]class]]) {
            [mainArray addObject:obj];
        }
    }
    
    NSLog(@"%@",mainArray);
    
    
    
     alertString = [mainArray componentsJoinedByString:@","];
    
    
//    for(int i = 0;[namesArray count] > 0;i++){
//        if([[namesArray objectAtIndex:i]isEqualToString:@"00"]){ // indentifies and removes null values from mutable array
//
//            [namesArray removeObjectAtIndex:i];
//            // or
//
//
//            NSLog(@"*** %@",namesArray);
//        }
//
//        // NSLog(@"*** %@",namesArray);
//    }
//
//
    
    
//
//    for (int j=0; j<namesArray.count; j++) {
//        for (NSMutableArray *ar in namesArray) {
//            if ([[ar objectAtIndex:j] isEqualToString:@"<null>"]) {
//                [ar addObject:@""];//Add empty value before remove null value
//                [ar removeObjectAtIndex:j];
//                [namesArray addObject:ar];
//            }
//        }
//    }
//
    
    
    
    NSLog(@"Changearrays %@",namesArray);
    
    NSString *dfdsf =[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@, ",idd1,idd2,idd3,idd4,idd5,idd6,idd7,idd8,idd9,idd10,idd11,idd12,idd13,idd14,idd15,idd16,idd17,idd18];
    
    NSLog(@"Checkarrays %@",namesArray);
     CheckboxArrray2 =[[NSMutableArray alloc]initWithObjects:bidd1,bidd2,bidd3,bidd4,bidd5,bidd6,bidd7,bidd8,bidd9,bidd10,bidd11,bidd12,bidd13,bidd14,bidd15,bidd16,bidd17, bidd18,nil];
    
    
    mainArray1 = [[NSMutableArray alloc]init];
    for (int i = 0; i < [CheckboxArrray2 count]; i++) {
        NSString *obj = [CheckboxArrray2 objectAtIndex:i];
        if (![obj isEqualToString:@"00"]) { // or if (![obj  isKindOfClass:[[NSNull null]class]]) {
            [mainArray1 addObject:obj];
        }
    }
    
      alertString1 = [mainArray1 componentsJoinedByString:@","];
    
    
    
    
//    
//    for(int i = 0; i < [CheckboxArrray1 count]; i++)
//    {
//        NSString *firstName = [CheckboxArrray1 objectAtIndex:i];
//        
//        
//        NSMutableArray *namesArray = [NSMutableArray array];
//        
//        if ([firstName isKindOfClass:[NSString class]])
//            [namesArray addObject:firstName];
//      
//        
//        if (namesArray.count > 0)
//            [CheckboxArrray1 addObject:[namesArray componentsJoinedByString:@""]];
//    
//    }
 
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
