//
//  RegisterView.h
//  GoalZero
//
//  Created by user on 18/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterView : UIViewController
<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *ScrollViewsc;
@property (weak, nonatomic) IBOutlet UIView *nameView;
@property (weak, nonatomic) IBOutlet UITextField *name_Feild;


@property (weak, nonatomic) IBOutlet UIView *Surname_view;

@property (weak, nonatomic) IBOutlet UITextField *Surname_Feild;


@property (weak, nonatomic) IBOutlet UIView *Preffereduser_View;
@property (weak, nonatomic) IBOutlet UITextField *Prefered_Feild;


@property (weak, nonatomic) IBOutlet UIView *PreferedpasswordView;
@property (weak, nonatomic) IBOutlet UITextField *PrefferedPassword_Feild;

@property (weak, nonatomic) IBOutlet UIView *Company_View;
@property (weak, nonatomic) IBOutlet UITextField *Company_Feild;


@property (weak, nonatomic) IBOutlet UITextField *Designation_Feild;
@property (weak, nonatomic) IBOutlet UIView *Designation_View;

@property (weak, nonatomic) IBOutlet UITextField *Department_Feild;
@property (weak, nonatomic) IBOutlet UIView *Department_View;

@property (weak, nonatomic) IBOutlet UIView *Contact_View;
@property (weak, nonatomic) IBOutlet UITextField *Contact_Feild;

@property (weak, nonatomic) IBOutlet UIView *Email_View;
@property (weak, nonatomic) IBOutlet UITextField *Email_feild;

@property (weak, nonatomic) IBOutlet UIView *Employee_view;
@property (weak, nonatomic) IBOutlet UITextField *Employee_Feild;

@property (weak, nonatomic) IBOutlet UIButton *Profile_button;
@property (weak, nonatomic) IBOutlet UIImageView *Profile_ImageView;

@end
