//
//  RegisterView.m
//  GoalZero
//
//  Created by user on 18/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "RegisterView.h"
#import "Common.h"
#import "JSON.h"
#import "ViewController.h"
#import "CLPopListView.h"
#import "MBProgressHUD.h"
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define IS_IPAD_PRO_1366 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1366.0)
#define IS_IPAD_PRO_1024 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1024.0)
#define IS_IPAD_PRO (MAX([[UIScreen mainScreen]bounds].size.width,[[UIScreen mainScreen] bounds].size.height) > 1024)
@interface RegisterView ()<MBProgressHUDDelegate>
{
    NSDictionary *dict2;
    NSString *response;
     NSArray *company;
     NSArray *company_name;
    MBProgressHUD *HUD;
    NSArray *department;
    NSArray *dept_name;
      NSData *imagedata;
    NSArray *designation;
    NSArray *designation_name;
    NSArray *company_id;
    NSArray *Designation_id;
    NSArray *Department_id;
    NSString *base64Img;
    NSString *company_idstr;
    NSString *Designation_idstr;
    NSString *Department_idstr;
    
    NSString *str64;
}
@property (weak, nonatomic) UIImageView *navBarLogo;
@end

@implementation RegisterView

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"GoalZeroNav.jpg"] forBarMetrics:UIBarMetricsDefault];
//
    
//    UIImage *image = [UIImage imageNamed:@"GoalZeroNav.jpg"];
//    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
//    imageView.frame = CGRectMake(0, 0, self.navigationController.navigationBar.frame.size.height, self.navigationController.navigationBar.frame.size.width);
//
//    self.navBarLogo = imageView;
//
//    [self.navigationController.navigationBar addSubview:imageView];
//
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
//self.navigationController.navigationBar.hidden =NO;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    self.Profile_ImageView.layer.cornerRadius = self.Profile_ImageView.frame.size.width / 2;
    self.Profile_ImageView.clipsToBounds = YES;
    [self setup_payment];
    [self calling_webServicsfor_banner];
    // Do any additional setup after loading the view.
}
-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}



-(void) viewDidLayoutSubviews
{
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                
                 _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1200);
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                
              _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1500);
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                  _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1600);
               
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
                _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1700);
                
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
                
              _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1850);
                printf("iPhone X");
                break;
            default:
              _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 1200);
        }
     
    }
    
    else{
        if (IS_IPAD_PRO_1366) {
            
        
            
        }
        else{
            
          _ScrollViewsc.contentSize = CGSizeMake(_ScrollViewsc.frame.size.width, 3000);
            
        }
    }
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)Register_Button:(id)sender{
    
    if (_name_Feild.text.length==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your full name"];
    }
    else if (_Surname_Feild.text.length==0)
    {
      [Common AlertShowWithErrorMsg:@"Please enter user surename"];
        
    }
    else if (_Prefered_Feild.text.length ==0)
    {
        
       [Common AlertShowWithErrorMsg:@"Please enter your preferred userid"];
    }
    else if (_PrefferedPassword_Feild.text.length ==0)
    {
        
      [Common AlertShowWithErrorMsg:@"Please enter your preferred password"];
    }
    else if (_Company_Feild.text.length ==0)
    {
      [Common AlertShowWithErrorMsg:@"Please select your company"];
        
    }
    else if (_Designation_Feild.text.length ==0)
    {
      [Common AlertShowWithErrorMsg:@"Please select your Designation"];
        
    }
    else if (_Department_Feild.text.length ==0)
    {
        
      [Common AlertShowWithErrorMsg:@"Please select your Department"];
    }
    else if (_Employee_Feild.text.length ==0)
    {
      [Common AlertShowWithErrorMsg:@"Please enter your Employee Number"];
        
    }
    else if (_Contact_Feild.text.length ==0)
    {
     [Common AlertShowWithErrorMsg:@"Please enter your Contact Number"];
        
    }
    else if (_Email_feild.text.length ==0)
    {
       [Common AlertShowWithErrorMsg:@"Please enter your E-mail Address"];
        
    }
    else{
         [HUD show:YES];
        
        [self upload_data];
//        [self.navigationController popViewControllerAnimated:YES];
        
        
    }
}

//company_idstr
//Designation_idstr
//Department_idstr

-(void)upload_data
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        
//        http://www.goalzero.qa/main/api/register.php?first_name=mike&sur_name=taylor&user_id=12228&password=1234567&reg_designation=20&reg_company=20&reg_department=4&emp_number=553535&contact_number=3535353538&email=mikrd@gmail.com&photo=yrry&department=yryrryr&method=fsf
        
    NSString *dd =    [base64Img stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        
        
        NSLog(@"%@",dd);
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/register.php?first_name=%@&sur_name=%@&user_id=%@&password=%@&reg_designation=%@&reg_company=%@&reg_department=%@&emp_number=%@&contact_number=%@&email=%@&photo=photo&department=5mike",self->_name_Feild.text,_Surname_Feild.text,_Prefered_Feild.text,_PrefferedPassword_Feild.text,Designation_idstr,company_idstr,Department_idstr,_Employee_Feild.text,_Contact_Feild.text,_Email_feild.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[dict2 valueForKey:@"response"];
            
            
            if ([response isEqualToString:@"success"]) {
                [Common AlertShowWithErrorMsg:@"you have successfully registered"];
            }
            else{
                
                 [Common AlertShowWithErrorMsg:@"you have already registerd"];
            }
           
            [self.navigationController popViewControllerAnimated:YES];
            
            
            [HUD hide:YES];
            
        });
    });
    
    
    
}


-(UIImage *)decodeBase64ToImage:(NSString *)strEncodeData {
    NSData *data = [[NSData alloc]initWithBase64EncodedString:strEncodeData options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    
   
    return [UIImage imageWithData:data];
}


- (void) Uploadata {
    
    NSString *urlString=@"http://www.goalzero.qa/main/api/register.php";
    
    NSString *method =  @"GET";
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"GET"];
    
    NSMutableData *body = [NSMutableData data];
    
    NSString *boundary;
    boundary = [NSString stringWithFormat:@"---------------------------14737809831466499882746641449"];
    
    
    
    imagedata = UIImageJPEGRepresentation(self.Profile_ImageView.image, 0.8);
    NSData *myImageData1 = [NSData dataWithData:imagedata];
    NSString *contentType1 = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType1 forHTTPHeaderField: @"Content-Type"];
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    NSString *strNameImage1 = [NSString stringWithFormat:@"test_tttt.jpg"];
    
    
    NSString *str1 = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"photo\"; filename=\"%@\"\r\n", strNameImage1];
    [body appendData:[str1 dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[NSData dataWithData:myImageData1]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    //  userid method
//    NSString *userID = [[NSUserDefaults standardUserDefaults] valueForKey:@"userid"];
//    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
//    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"user_id\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
//    [body appendData:[userID dataUsingEncoding:NSUTF8StringEncoding]];
//    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    


    
    
    //  Email method
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"first_name\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Mike" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    //  phone_number method
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"sur_name\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Taylor" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    //  pwd method
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"user_id\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"1234" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    //  cmnt method
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"password\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[_PrefferedPassword_Feild.text dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];

    //  parameter method
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"reg_company\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"20" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"reg_designation\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"2" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"reg_department\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"4" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"emp_number\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[_Employee_Feild.text dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
 
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"contact_number\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[_Contact_Feild.text dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"email\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[_Email_feild.text dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    
    
    
    // close form
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    NSString *message;
    NSError *responseError;
    NSURLResponse *requestResponse;
    
    NSData *requestHandler = [NSURLConnection sendSynchronousRequest:request returningResponse:&requestResponse error:&responseError];
    if ( responseError == nil)
    {
        //
        NSLog(@"Connection Successful");
        NSError* error;
        NSDictionary* json=[NSJSONSerialization JSONObjectWithData:requestHandler options:kNilOptions error:&error];
        NSLog(@"Value of json is %@",json);
        
        message=[json objectForKey:@"message"];
        
        if ( [json objectForKey:@"message_code"]) {
            
        }else{
            NSLog(@"Fail.....");
        }
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [HUD hide:YES];
            //            [Common AlertShowWithSuccessMsg:message];
//            ProfileViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
//            [self.navigationController  pushViewController:vc animated:YES];
        });
        
        
    }else{
        
        NSLog(@"---------------------");
    }
}

-(void)setup_payment
{
   
    self.nameView.layer.cornerRadius = 8.0 ;
    self.nameView.clipsToBounds = true;
    
    self.nameView.layer.borderWidth = 1.0f;
    self.nameView.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Surname_view.layer.cornerRadius = 8.0 ;
    self.Surname_view.clipsToBounds = true;
    
    self.Surname_view.layer.borderWidth = 1.0f;
    self.Surname_view.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Preffereduser_View.layer.cornerRadius = 8.0 ;
    self.Preffereduser_View.clipsToBounds = true;
    
    self.Preffereduser_View.layer.borderWidth = 1.0f;
    self.Preffereduser_View.layer.borderColor = [UIColor redColor].CGColor;
    
    self.PreferedpasswordView.layer.cornerRadius = 8.0 ;
    self.PreferedpasswordView.clipsToBounds = true;
    
    self.PreferedpasswordView.layer.borderWidth = 1.0f;
    self.PreferedpasswordView.layer.borderColor = [UIColor redColor].CGColor;
    
    self.Company_View.layer.cornerRadius = 8.0 ;
    self.Company_View.clipsToBounds = true;
    
    self.Company_View.layer.borderWidth = 1.0f;
    self.Company_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Designation_View.layer.cornerRadius = 8.0 ;
    self.Designation_View.clipsToBounds = true;
    
    self.Designation_View.layer.borderWidth = 1.0f;
    self.Designation_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    
    
    self.Department_View.layer.cornerRadius = 8.0 ;
    self.Department_View.clipsToBounds = true;
    
    self.Department_View.layer.borderWidth = 1.0f;
    self.Department_View.layer.borderColor = [UIColor redColor].CGColor;
    
    self.Contact_View.layer.cornerRadius = 8.0 ;
    self.Contact_View.clipsToBounds = true;
    
    self.Contact_View.layer.borderWidth = 1.0f;
    self.Contact_View.layer.borderColor = [UIColor redColor].CGColor;
    
    
    self.Email_View.layer.cornerRadius = 8.0 ;
    self.Email_View.clipsToBounds = true;
    
    self.Email_View.layer.borderWidth = 1.0f;
    self.Email_View.layer.borderColor = [UIColor redColor].CGColor;
    
    self.Employee_view.layer.cornerRadius = 8.0 ;
    self.Employee_view.clipsToBounds = true;
    
    self.Employee_view.layer.borderWidth = 1.0f;
    self.Employee_view.layer.borderColor = [UIColor redColor].CGColor;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)showActionSheet{
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:@"Choose From" preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped.
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Gallery" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
        imgpicker.allowsEditing = YES;
        imgpicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imgpicker.delegate=(id)self;
        [self presentViewController:imgpicker animated:YES completion:nil];
        ////         Distructive button tapped.
        //                [self dismissViewControllerAnimated:YES completion:^{
        //                }];
    }]];
    
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Sorry"
                                         message:@"No camera detected"
                                         preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action =[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
                
                
            }];
            
            
            [alert addAction:action];
            
            [self presentViewController:alert animated:YES completion:nil];
        }else{
            
            UIImagePickerController *imgpicker = [[UIImagePickerController alloc] init];
            imgpicker.allowsEditing = YES;
            imgpicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            imgpicker.delegate=(id)self;
            [self presentViewController:imgpicker animated:YES completion:nil];
            
        }
        // OK button tapped.
        
        //        [self dismissViewControllerAnimated:YES completion:^{
        //        }];
    }]];
    
    // Present action sheet.
    [self presentViewController:actionSheet animated:YES completion:nil];
    
    
    
    // OK button tapped.
    
    //        [self dismissViewControllerAnimated:YES completion:^{
    //        }];
    
}
- (IBAction)btnActnChoosePic:(id)sender {
    
    [self showActionSheet];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage =[info valueForKey:UIImagePickerControllerOriginalImage];
    
    chosenImage = [info valueForKey:UIImagePickerControllerOriginalImage];
       imagedata = UIImageJPEGRepresentation(self.Profile_ImageView.image, 0.8);
    
  
  base64Img = [imagedata base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    
 str64 = [base64Img stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    
    
//     - (NSString *)base64String:(UIImage*)image {return [[UIImageJPEGRepresentation(image,1) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed] stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];}
    
    
  
    self.Profile_ImageView.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}



-(void)calling_webServicsfor_banner
{
    
    [HUD show:YES];
    NSString *data;
    NSString *urlstring;
    
    // http://gnaritus.com/clients/gurukula/api/news.php?topic_id=1&category_id=1
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.goalzero.qa/main/api/menu_list.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // image_tpic;
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            response =[dict2 valueForKey:@"response"];
            
           
            company =[response valueForKey:@"company"];
          company_name =[company valueForKey:@"company_name"];
           company_id =[company valueForKey:@"id"];
           
         
            
          department =[response valueForKey:@"department"];
          dept_name=[department valueForKey:@"dept_name"];
            Department_id =[department valueForKey:@"id"];
            
           designation =[response valueForKey:@"designation"];
          designation_name =[designation valueForKey:@"designation_name"];
            Designation_id =[designation valueForKey:@"id"];
            
            
           
           
            [HUD hide:YES];
            
        });
    });
    
}

-(IBAction)company:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Company" options:company_name handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=100;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Designation:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Designation" options:designation_name handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=101;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)Department:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Department" options:dept_name handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=102;
    [lplv showInView:self.view.window animated:YES];
    
    
}
- (void)leveyPopListView:(CLPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    if(popListView.tag==100)
    {
       ;
        NSString *comapn;
        //btnEventSize.titleLabel.text = [DurationArray objectAtIndex:anIndex];
        comapn = [NSString stringWithFormat:@"  %@",[company_name objectAtIndex:anIndex]];
        company_idstr =[company_id objectAtIndex:anIndex];
      
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Company_Feild.text =comapn;
        
    }
    
    else if (popListView.tag==101)
    {
        NSString *designation;
        designation = [NSString stringWithFormat:@"  %@",[designation_name objectAtIndex:anIndex]];
        Designation_idstr =[Designation_id objectAtIndex:anIndex];
       
      
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Designation_Feild.text =designation;
        
        
    }
    else if (popListView.tag==102)
    {
        NSString *dept;
        dept = [NSString stringWithFormat:@"  %@",[dept_name objectAtIndex:anIndex]];
        Department_idstr =[Department_id objectAtIndex:anIndex];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Department_Feild.text =dept;
        
        
    }
    
    
}





@end
