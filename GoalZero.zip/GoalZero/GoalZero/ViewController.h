//
//  ViewController.h
//  ExpandableHeaders
//
//  Created by James Johnson on 05/01/2017.
//  Copyright © 2017 Anexinet. All rights reserved.
//

#import <UIKit/UIKit.h>
#define WIDTH_SIDEMENU  320
#define HEIGHT_SIDEMENU  700
@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong)IBOutlet UIView *Viewww;
@property(nonatomic,strong)IBOutlet UIButton *BtnLgt;
@end

