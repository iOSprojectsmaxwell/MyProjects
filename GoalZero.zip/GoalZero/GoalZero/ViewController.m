//
//  ViewController.m
//  ExpandableHeaders
//
//  Created by James Johnson on 05/01/2017.
//  Copyright © 2017 Anexinet. All rights reserved.
//

#import <MapKit/MapKit.h>
#import <Contacts/Contacts.h>
#import "ViewController.h"
#import "UIColor+AppColors.h"
#import "GoalZeroVC.h"
#import "ListeningObservationVC.h"
#import "MyObservationVC.h"
#import "ViewListeningObservationVC.h"
#import "EditPersonalVC.h"
#import "MyNewObseravationVC.h"
#import "LoginVC.h"

static int const kHeaderSectionTag = 6900;

@interface ViewController ()
{
    int headeropen;
    NSString *Headestr;
}

@property (assign) NSInteger expandedSectionHeaderNumber;
@property (assign) UITableViewHeaderFooterView *expandedSectionHeader;
@property (strong) NSArray *sectionItems;
@property (strong) NSArray *sectionNames;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.BtnLgt.layer.cornerRadius = 8.0 ;
    self.BtnLgt.clipsToBounds = true;
    
    self.BtnLgt.layer.borderWidth = 2.0f;
    self.BtnLgt.layer.borderColor = [UIColor redColor].CGColor;
    
   // self.BtnLgt.layer.borderColor =(__bridge CGColorRef _Nullable)([UIColor redColor]);
    _Viewww.layer.cornerRadius = 2;
    _Viewww.layer.shadowColor = (__bridge CGColorRef _Nullable)([UIColor lightGrayColor]);
    _Viewww.layer.shadowOffset = CGSizeMake(0.5, 4.0); //Here your control your spread
    _Viewww.layer.shadowOpacity = 0.5;
    _Viewww.layer.shadowRadius = 5.0;
    
    self.navigationController.navigationBar.hidden=YES;
    self.sectionNames = @[ @"Goal Zero", @"Listening Tour System", @"We Go Safely System" ];
    self.sectionItems = @[ @[@"GZ Leadership Team"],
                           @[@"Listening Observation", @"View Listening Observation"],
                           @[@"New Observation", @"My Observations"]
                         ];
    // configure the tableview
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;
    
    
    Headestr = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"Header"];
    int hease =[Headestr intValue];
    (void)(self.expandedSectionHeaderNumber =0),(void)(1),2;
      self.expandedSectionHeaderNumber = hease;
    //Get Section to open
    NSInteger sectionCount = [self.tableView numberOfSections];
    for (int needToOpen = 0; needToOpen<sectionCount; needToOpen++) {
        //Open Section one by one
      
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    if (self.sectionNames.count > 0) {
        self.tableView.backgroundView = nil;
        return self.sectionNames.count;
    } else {
        UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
        
        messageLabel.text = @"Retrieving data.\nPlease wait.";
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        messageLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:20];
        [messageLabel sizeToFit];
        self.tableView.backgroundView = messageLabel;
        
        return 0;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.expandedSectionHeaderNumber == section) {
        NSMutableArray *arrayOfItems = [self.sectionItems objectAtIndex:section];
        return arrayOfItems.count;
    } else {
        return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (self.sectionNames.count) {
        return [self.sectionNames objectAtIndex:section];
    }
    
    return @"";
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section; {
    return 44.0;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    // recast your view as a UITableViewHeaderFooterView
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    header.contentView.backgroundColor = [UIColor colorWithRed:254.0f/255.0f
                                                         green:206.0f/255.0f
                                                          blue:10.0f/255.0f
                                                         alpha:1.0f];
    
    header.layer.shadowRadius  = 1.5f;
    header.layer.shadowColor   = [UIColor colorWithRed:176.f/255.f green:199.f/255.f blue:226.f/255.f alpha:1.f].CGColor;
    header.layer.shadowOffset  = CGSizeMake(0.0f, 0.0f);
    header.layer.shadowOpacity = 0.9f;
    header.layer.masksToBounds = NO;
    
    UIEdgeInsets shadowInsets     = UIEdgeInsetsMake(0, 0, -1.5f, 0);
    UIBezierPath *shadowPath      = [UIBezierPath bezierPathWithRect:UIEdgeInsetsInsetRect(header.bounds, shadowInsets)];
    header.layer.shadowPath    = shadowPath.CGPath;
    
    
    header.textLabel.textColor = [UIColor blackColor];
    UIImageView *viewWithTag = [self.view viewWithTag:kHeaderSectionTag + section];
    if (viewWithTag) {
        [viewWithTag removeFromSuperview];
    }
    // add the arrow image
    CGSize headerFrame = self.view.frame.size;
    UIImageView *theImageView = [[UIImageView alloc] initWithFrame:CGRectMake(headerFrame.width - 32, 13, 18, 18)];
    theImageView.image = [UIImage imageNamed:@"Chevron-Dn-Wht"];
    theImageView.tag = kHeaderSectionTag + section;
    [header addSubview:theImageView];
    
    // make headers touchable
    header.tag = section;
    UITapGestureRecognizer *headerTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sectionHeaderWasTouched:)];
    [header addGestureRecognizer:headerTapGesture];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableCell" forIndexPath:indexPath];
    NSArray *section = [self.sectionItems objectAtIndex:indexPath.section];
    
    cell.textLabel.textColor = [UIColor blackColor];
    cell.textLabel.text = [section objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSLog(@"%ld",(long)indexPath.row) ;
     NSLog(@"%ld",(long)indexPath.section) ;
    
    if (indexPath.section ==0) {
        
        if (indexPath.row ==0) {
            GoalZeroVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"GoalZeroVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
    }
    else if (indexPath.section ==1)
    {
        if (indexPath.row ==0) {
            ListeningObservationVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ListeningObservationVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
        else{
            
            ViewListeningObservationVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewListeningObservationVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
    }
    else if (indexPath.section ==2)
    {
        if (indexPath.row ==1) {
            MyObservationVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyObservationVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
        else if (indexPath.row ==2)
        {
            
            EditPersonalVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"EditPersonalVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
        else{
            MyNewObseravationVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNewObseravationVC"];
            [self.navigationController pushViewController:controller animated:NO];
        }
    }
    
    NSString *dd =[NSString stringWithFormat:@"%ld",(long)indexPath.section];
    [[NSUserDefaults standardUserDefaults] setObject:dd forKey:@"Header"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)updateTableViewRowDisplay:(NSArray *)arrayOfIndexPaths {
    [self.tableView beginUpdates];
    [self.tableView deleteRowsAtIndexPaths:arrayOfIndexPaths withRowAnimation: UITableViewRowAnimationFade];
    [self.tableView endUpdates];
}

#pragma mark - Expand / Collapse Methods

- (void)sectionHeaderWasTouched:(UITapGestureRecognizer *)sender {
    UITableViewHeaderFooterView *headerView = (UITableViewHeaderFooterView *)sender.view;
    NSInteger section = headerView.tag;
    UIImageView *eImageView = (UIImageView *)[headerView viewWithTag:kHeaderSectionTag + section];
    self.expandedSectionHeader = headerView;
    
    if (self.expandedSectionHeaderNumber == -1) {
        self.expandedSectionHeaderNumber = section;
        [self tableViewExpandSection:section withImage: eImageView];
    } else {
        if (self.expandedSectionHeaderNumber == section) {
            [self tableViewCollapeSection:section withImage: eImageView];
            self.expandedSectionHeader = nil;
        } else {
            UIImageView *cImageView  = (UIImageView *)[self.view viewWithTag:kHeaderSectionTag + self.expandedSectionHeaderNumber];
            [self tableViewCollapeSection:self.expandedSectionHeaderNumber withImage: cImageView];
            [self tableViewExpandSection:section withImage: eImageView];
        }
    }
}

- (void)tableViewCollapeSection:(NSInteger)section withImage:(UIImageView *)imageView {
    NSArray *sectionData = [self.sectionItems objectAtIndex:section];
    
    self.expandedSectionHeaderNumber = -1;
    if (sectionData.count == 0) {
        return;
    } else {
        [UIView animateWithDuration:0.4 animations:^{
            imageView.transform = CGAffineTransformMakeRotation((0.0 * M_PI) / 180.0);
        }];
        NSMutableArray *arrayOfIndexPaths = [NSMutableArray array];
        for (int i=0; i< sectionData.count; i++) {
            NSIndexPath *index = [NSIndexPath indexPathForRow:i inSection:section];
            [arrayOfIndexPaths addObject:index];
        }
       // [self.tableView beginUpdates];
        [self.tableView deleteRowsAtIndexPaths:arrayOfIndexPaths withRowAnimation: UITableViewRowAnimationFade];
        [self.tableView endUpdates];
    }
}

- (void)tableViewExpandSection:(NSInteger)section withImage:(UIImageView *)imageView {
    NSArray *sectionData = [self.sectionItems objectAtIndex:section];
    
    if (sectionData.count == 0) {
        self.expandedSectionHeaderNumber = -1;
        return;
    } else {
        [UIView animateWithDuration:0.4 animations:^{
            imageView.transform = CGAffineTransformMakeRotation((180.0 * M_PI) / 180.0);
        }];
        NSMutableArray *arrayOfIndexPaths = [NSMutableArray array];
        for (int i=0; i< sectionData.count; i++) {
            NSIndexPath *index = [NSIndexPath indexPathForRow:i inSection:section];
            [arrayOfIndexPaths addObject:index];
        }
        self.expandedSectionHeaderNumber = section;
       // [self.tableView beginUpdates];
        [self.tableView insertRowsAtIndexPaths:arrayOfIndexPaths withRowAnimation: UITableViewRowAnimationFade];
        [self.tableView endUpdates];
    }
}



- (IBAction)logout:(id)sender {
    NSLog(@"logout");
    
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"Login"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"Logout"
                                                                  message:@"Are You Sure"
                                                           preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes Please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    /** What we write here???????? **/
                                    LoginVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
                                    [self.navigationController pushViewController:controller animated:YES];
                                    
                                    // call method whatever u need
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
    
    //    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Swamy Desikan" message:@"Are you sure you want Logout ?" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Cancel"];
    //    [alert show];
    
}
@end
