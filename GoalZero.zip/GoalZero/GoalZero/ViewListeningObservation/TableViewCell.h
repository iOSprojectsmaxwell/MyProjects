//
//  TableViewCell.h
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UILabel *namelbl;
@property(nonatomic,strong)IBOutlet UILabel *user_id;
@property(nonatomic,strong)IBOutlet UILabel *company_name;
@property(nonatomic,strong)IBOutlet UILabel *action_type;
@property(nonatomic,strong)IBOutlet UILabel *designation;
@property(nonatomic,strong)IBOutlet UILabel *regcode;
@property(nonatomic,strong)IBOutlet UILabel *reg_date;

@end
