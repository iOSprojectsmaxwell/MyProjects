//
//  ViewListeningObservationVC.h
//  GoalZero
//
//  Created by user on 17/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewListeningObservationVC : UIViewController
<UITableViewDelegate,UITableViewDataSource>
@property(weak,nonatomic)IBOutlet UITableView *tableviewwe;
@property(nonatomic,strong)IBOutlet UIView*blurescreen;
@end
