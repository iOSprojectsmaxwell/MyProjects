//
//  Common.m
//  iastitva
//
//  Created by APPLE-HOME on 21/06/16.
//  Copyright © 2016 Tushar. All rights reserved.
//

#import "Common.h"

@interface Common ()

@end

@implementation Common


#pragma mark - Alert view Method

+(void)AlertShowWithSuccessMsg:(NSString *)msg{
    UIAlertView *alert1 =[[UIAlertView alloc] initWithTitle:@"KPJ Matrimony" message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert1 show];
}
+(void)AlertShowWithErrorMsg:(NSString *)msg{
    UIAlertView *alert1 =[[UIAlertView alloc] initWithTitle:@"KPJ Matrimony" message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert1 show];
}
+ (UIColor *)colorwithHexString:(NSString *)hexStr alpha:(CGFloat)alpha;
{
    //-----------------------------------------
    // Convert hex string to an integer
    //-----------------------------------------
    unsigned int hexint = 0;
    
    // Create scanner
    NSScanner *scanner = [NSScanner scannerWithString:hexStr];
    
    // Tell scanner to skip the # character
    [scanner setCharactersToBeSkipped:[NSCharacterSet
                                       characterSetWithCharactersInString:@"#"]];
    [scanner scanHexInt:&hexint];
    
    //-----------------------------------------
    // Create color object, specifying alpha
    //-----------------------------------------
    UIColor *color =
    [UIColor colorWithRed:((CGFloat) ((hexint & 0xFF0000) >> 16))/255
                    green:((CGFloat) ((hexint & 0xFF00) >> 8))/255
                     blue:((CGFloat) (hexint & 0xFF))/255
                    alpha:alpha];
    
    return color;
}
+(NSMutableDictionary *)removenullvalue:(NSMutableDictionary *)Dictionary{
    NSMutableDictionary *dict=[[NSMutableDictionary alloc] init];
    for (NSString *key in Dictionary)
    {
        NSString *value = [Dictionary objectForKey:key];
        if ([value isKindOfClass:[NSNull class]] || ![Dictionary objectForKey:key] ) {
            value=@"-";
               [dict setValue:value forKey:key];
        }else if ([value isKindOfClass:[NSString class]] && [value isEqualToString:@""]) {
            value=@"-";
            [dict setValue:value forKey:key];
        }else{
           [dict setValue:value forKey:key];
        }
    }
  
    return dict;
}

+(CAGradientLayer *) gradientLayerForBounds:(CGRect)Bounds  {
   
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = Bounds;
    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[Common colorwithHexString:@"1281FF" alpha:1.0] CGColor], nil];
   
    return gradient;
}
@end
