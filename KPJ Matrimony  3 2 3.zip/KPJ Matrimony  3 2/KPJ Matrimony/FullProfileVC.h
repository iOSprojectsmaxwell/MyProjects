//
//  FullProfileVC.h
//  KPJ Matrimony
//
//  Created by user on 03/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FullProfileVC : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *scrowlView;
@property(nonatomic,strong)NSString *SelectedProfileID;
@property(nonatomic,strong)NSString *Statuss;

@end

NS_ASSUME_NONNULL_END
