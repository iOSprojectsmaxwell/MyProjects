//
//  FullProfileVC.m
//  KPJ Matrimony
//
//  Created by user on 03/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "FullProfileVC.h"
#import "Json.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Common.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
@interface FullProfileVC ()<UITextFieldDelegate,MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *user_id;
    NSArray *full_profile;
    NSArray *profile_details;
    NSString *profile_id;
    
    NSString *name;
    NSString *age;
    NSString *dob;
    
    NSString *castname;
    NSString *subcastname;
    NSString *gender;
    
    
    NSString *placeofbirth;
    NSString *maritalstatus;
    NSString *height;
    
    NSString *weight;
    NSString *bloodgroup;
    NSString *physicalstatus;
    
    
    
    NSString *education;
    NSString *occupation;
    NSString *company;
    
    NSString *employee_in;
    NSString *annual_income;
    NSString *house_name;
    
    
    NSString *chevvai_dosham;
    NSString *thisai_irrupu;
    NSString *star;
    
    
    NSString *rasi;
    NSString *lagnam;
    NSString *gothram;
    
    NSString *father_name;
    NSString *father_occupation;
    NSString *mother_name;
    
    
    NSString *mother_occupation;
    NSString *brother;
    NSString *brother_married;
    
    NSString *sister;
    NSString *sister_married;
    NSString *family_status;
    
    NSString *district;
    NSString *image;
    
    
}
@property (weak, nonatomic) IBOutlet UILabel *namelbl;
@property (weak, nonatomic) IBOutlet UILabel *agelbl;
@property (weak, nonatomic) IBOutlet UILabel *doblbl;
@property (weak, nonatomic) IBOutlet UILabel *castelbl;

@property (weak, nonatomic) IBOutlet UILabel *Genderlbl;
@property (weak, nonatomic) IBOutlet UILabel *placeofbirthlbl;
@property (weak, nonatomic) IBOutlet UILabel *maritalstatuslbl;
@property (weak, nonatomic) IBOutlet UILabel *Heightlbl;

@property (weak, nonatomic) IBOutlet UILabel *Weightlbl;
@property (weak, nonatomic) IBOutlet UILabel *bloodGroudlbl;
@property (weak, nonatomic) IBOutlet UILabel *physicallbl;
@property (weak, nonatomic) IBOutlet UILabel *Educationlbl;

@property (weak, nonatomic) IBOutlet UILabel *educationDetailslbl;
@property (weak, nonatomic) IBOutlet UILabel *occupationlbl;
@property (weak, nonatomic) IBOutlet UILabel *Companylbl;
@property (weak, nonatomic) IBOutlet UILabel *employeelbl;
@property (weak, nonatomic) IBOutlet UILabel *annualincomelbl;
@property (weak, nonatomic) IBOutlet UILabel *Housenamelbl;
@property (weak, nonatomic) IBOutlet UILabel *Gothramlbl;
@property (weak, nonatomic) IBOutlet UILabel *Starlbl;
@property (weak, nonatomic) IBOutlet UILabel *Raasilbl;
@property (weak, nonatomic) IBOutlet UILabel *Chevvai_Dosamlbl;

@property (weak, nonatomic) IBOutlet UILabel *Lagnamlbl;

@property (weak, nonatomic) IBOutlet UILabel *thisaiIrrupulbl;
@property (weak, nonatomic) IBOutlet UILabel *fatherslbl;
@property (weak, nonatomic) IBOutlet UILabel *fathers_Professionallbl;
@property (weak, nonatomic) IBOutlet UILabel *Mothernamelbl;

@property (weak, nonatomic) IBOutlet UILabel *MotherProfieesionalLbl;
@property (weak, nonatomic) IBOutlet UILabel *Brotherlbl;
@property (weak, nonatomic) IBOutlet UILabel *MarriedBrotherlbl;
@property (weak, nonatomic) IBOutlet UILabel *Sisterlbl;
@property (weak, nonatomic) IBOutlet UILabel *marriedSisterLbl;

@property (weak, nonatomic) IBOutlet UILabel *FamilyStatusLbl;
@property (weak, nonatomic) IBOutlet UILabel *NativePlacelbl;
@property (weak, nonatomic) IBOutlet UILabel *NativeDistrictlbl;
@property (weak, nonatomic) IBOutlet UILabel *LivingAddresslbl;
@property (weak, nonatomic) IBOutlet MyImageView *imagevieww;
@end

@implementation FullProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    self.navigationController.navigationBar.hidden =NO;
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    
    [self ViewHoroscope];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    // Do any additional setup after loading the view.
}
-(void) viewDidLayoutSubviews
{
    
    
    self.scrowlView.contentSize = CGSizeMake(self.scrowlView.frame.size.width,6800);
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)ViewHoroscope
{
    [HUD show:YES];
    //user_name
    //pswd
    
    // [HUD hide:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    //        http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=132&view_profile_id=180643
    //
//    // data processing
//    if ([_Statuss isEqualToString:@"single"]) {
//        
//    }
    NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/full_profile.php?login_user_id=%@&view_profile_id=%@",user_id,_SelectedProfileID];
    
    
    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
    
    dict2=[sampleURL JSONValue];
    
    // Interaction with User Interface - Main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSLog(@"dicr]t %@",dict2);
        
        full_profile =[dict2 valueForKey:@"full_profile"];
        profile_details =[[full_profile valueForKey:@"profile_details"]objectAtIndex:0];
        profile_id =[profile_details valueForKey:@"profile_id"];
        
        name=[profile_details valueForKey:@"name"];
        age=[profile_details valueForKey:@"age"];
        dob=[profile_details valueForKey:@"dob"];
        
        castname=[profile_details valueForKey:@"caste_name"];
        subcastname=[profile_details valueForKey:@"subcaste_name"];
        gender=[profile_details valueForKey:@"gender"];
        
        
        placeofbirth=[profile_details valueForKey:@"place_of_birth"];
        maritalstatus=[profile_details valueForKey:@"marital_status"];
        height=[profile_details valueForKey:@"height"];
        
        weight=[profile_details valueForKey:@"weight"];
        bloodgroup=[profile_details valueForKey:@"blood_group"];
        physicalstatus=[profile_details valueForKey:@"physical_status"];
        
        
        
        education=[profile_details valueForKey:@"education"];
        occupation=[profile_details valueForKey:@"occupation"];
        company=[profile_details valueForKey:@"company"];
        
        employee_in=[profile_details valueForKey:@"employee_in"];
        annual_income=[profile_details valueForKey:@"annual_income"];;
        house_name=[profile_details valueForKey:@"house_name"];;
        
        
        chevvai_dosham=[profile_details valueForKey:@"chevvai_dosham"];;
        thisai_irrupu=[profile_details valueForKey:@"thisai_irrupu"];;
        star=[profile_details valueForKey:@"star"];;
        
        
        rasi=[profile_details valueForKey:@"rasi"];;
        lagnam=[profile_details valueForKey:@"lagnam"];;
        gothram=[profile_details valueForKey:@"gothram"];;
        
        father_name=[profile_details valueForKey:@"father_name"];;
        father_occupation=[profile_details valueForKey:@"father_occupation"];;
        mother_name=[profile_details valueForKey:@"mother_name"];;
        
        
        mother_occupation=[profile_details valueForKey:@"mother_occupation"];;
        brother=[profile_details valueForKey:@"brother"];;
        brother_married=[profile_details valueForKey:@"brother_married"];;
        
        sister=[profile_details valueForKey:@"sister"];;
        sister_married=[profile_details valueForKey:@"sister_married"];;
        family_status=[profile_details valueForKey:@"family_status"];;
        
        district=[profile_details valueForKey:@"district"];;
        image=[profile_details valueForKey:@"image"];;
        
        
          [_imagevieww addImageFrom:[image stringByURLDecode] isRound:YES isActivityIndicator:YES];
        
        _namelbl.text =name;;
        _agelbl.text =[NSString stringWithFormat:@"%@",age];;
       _doblbl.text =[NSString stringWithFormat:@"%@",dob];;
        _castelbl.text =castname;;
        
        _Genderlbl.text =gender;;
        _placeofbirthlbl.text =placeofbirth;;
        _maritalstatuslbl.text =maritalstatus;;
        _Heightlbl.text =[NSString stringWithFormat:@"%@",height];;;;
        
        _Weightlbl.text =[NSString stringWithFormat:@"%@",weight];;;;
        _bloodGroudlbl.text =@"";
       _physicallbl.text  =@"";
        _Educationlbl.text =education;;
        
        _educationDetailslbl.text =education;;
        _occupationlbl.text =occupation;;
        _Companylbl.text =company;;
        _employeelbl.text =employee_in;;
        _annualincomelbl.text =[NSString stringWithFormat:@"%@",annual_income];;;
        _Housenamelbl.text =house_name;;
        _Gothramlbl.text =gothram;;
        _Starlbl.text =star;;
        _Raasilbl.text =rasi;;
        _Chevvai_Dosamlbl.text =chevvai_dosham;;
        
        _Lagnamlbl.text =lagnam;;;
        
        _thisaiIrrupulbl.text =thisai_irrupu;;;
        _fatherslbl.text =father_name;;;
        _fathers_Professionallbl.text =father_occupation;;;
       _Mothernamelbl.text =mother_name;;;
        
        _MotherProfieesionalLbl.text =mother_occupation;;;
        _Brotherlbl.text =brother;;;
        _MarriedBrotherlbl.text =brother_married;;;
        _Sisterlbl.text =sister;;;
        _marriedSisterLbl.text =sister_married;;;
        
       _FamilyStatusLbl.text =family_status;;;
        _NativePlacelbl.text =district;;;
        _NativeDistrictlbl.text =district;;;
        _LivingAddresslbl.text =district;;;
        
        
        
        [HUD hide:YES];
    });
};
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
