//
//  Guestuser.h
//  KPJ Matrimony
//
//  Created by user on 25/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Guestuser : UIViewController <UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)IBOutlet UITableView *guestblview;

@end
