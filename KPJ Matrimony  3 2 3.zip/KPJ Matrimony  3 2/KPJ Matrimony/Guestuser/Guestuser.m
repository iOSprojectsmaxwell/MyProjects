//
//  Guestuser.m
//  KPJ Matrimony
//
//  Created by user on 25/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "Guestuser.h"
#import "guestuserCell.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "MBProgressHUD.h"
#import <QuartzCore/QuartzCore.h>
#import "CLPopListView.h"
#import <QuartzCore/CALayer.h>
#import "Common.h"

@interface Guestuser ()<MBProgressHUDDelegate,UITableViewDelegate,UITableViewDataSource>
{
     MBProgressHUD *HUD;
     NSDictionary *dict2;
    NSArray *profiles;
    NSArray *ProfileId;
    NSArray *name;
    NSArray *age;
    NSArray *height;
    NSArray *star;
    NSArray *district;
    NSArray *caste_name;
    NSArray *subcaste_name;
    NSArray *occupation;
    NSArray *image;
    NSString *status;
    NSString *apiURLStr;
}


@property(nonatomic,strong)IBOutlet MyImageView *image1;
@property (weak, nonatomic) IBOutlet UILabel *BrideLbl;
@property (weak, nonatomic) IBOutlet UILabel *Groomlbl;
@end

@implementation Guestuser

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    status =@"Bride";
    _BrideLbl.hidden =NO;
    _Groomlbl.hidden =YES;
    [self CallingFirstNews];
    // Do any additional setup after loading the view.
}
-(void)CallingFirstNews

{
    [HUD show:YES];

    
    // [HUD hide:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    
       dispatch_async(queue, ^{
    
    if ([status isEqualToString:@"Bride"]) {
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/brides_profiles.php"];
    }
    else{
        
      apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/grooms_profiles.php"];
        
    }
    
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
       
           dispatch_async(dispatch_get_main_queue(), ^{
                if ([status isEqualToString:@"Bride"]) {
            profiles =[dict2 valueForKey:@"brides_profiles"];
                }
                else{
                      profiles =[dict2 valueForKey:@"grooms_profiles"];
                    
                }
              
            ProfileId =[profiles valueForKey:@"profile_id"];
            name =[profiles valueForKey:@"name"];
            age =[profiles valueForKey:@"age"];
            height =[profiles valueForKey:@"education"];
            caste_name =[profiles valueForKey:@"caste_name"];
            image =[profiles valueForKey:@"image"];
            star =[profiles valueForKey:@"star"];
            district =[profiles valueForKey:@"district"];
            subcaste_name =[profiles valueForKey:@"subcaste_name"];
            occupation =[profiles valueForKey:@"occupation"];
            [self.guestblview reloadData];
            
            
            [HUD hide:YES];
     
    
           });
           
           
       });
    
}

- (IBAction)Bride_Button:(id)sender {
     status =@"Bride";
    _BrideLbl.hidden =NO;
    _Groomlbl.hidden =YES;
     [self CallingFirstNews];
}
- (IBAction)Groom_Button:(id)sender {
    _BrideLbl.hidden =YES;
    _Groomlbl.hidden =NO;
   status =@"Groom";
     [self CallingFirstNews];
}

    
- (IBAction)back_button:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}


//MARK:- Table View Delegated & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return name.count;    //count number of row from counting array hear cataGorry is An Array
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    //    cell.backgroundColor = [UIColor colorWithRed:246/255.0f green:245/255.0f blue:245/255.0f alpha:1.0];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"HomeCell";
    
    
    guestuserCell  *cell = (guestuserCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[guestuserCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    _guestblview.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _image1 = (MyImageView*)[cell viewWithTag:1];
     NSString *path=[image objectAtIndex:indexPath.row];
     [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
   
    cell.districtlbl.text =[district objectAtIndex:indexPath.row];
   
    cell.namelbl.text =[name objectAtIndex:indexPath.row];
   
    cell.btnViewProfile.tag = indexPath.row;
    [cell.btnViewProfile addTarget:self action:@selector(yourButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.profileidlbl.text =[ProfileId objectAtIndex:indexPath.row];
    cell.agelbl.text =[NSString stringWithFormat:@"%@",[age objectAtIndex:indexPath.row]];
    cell.heightlbl.text =[NSString stringWithFormat:@"%@",[height objectAtIndex:indexPath.row]];
    
    cell.castlbl.text =[caste_name objectAtIndex:indexPath.row];
 
    
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    
    return 280;
    
}
-(IBAction)yourButtonClicked:(id)sender
{
    [Common AlertShowWithErrorMsg:@"Please login to view profile"];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
