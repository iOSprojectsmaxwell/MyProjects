//
//  contactdetailsvc.m
//  KPJ Matrimony
//
//  Created by user on 20/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "contactdetailsvc.h"

@interface contactdetailsvc ()

@end

@implementation contactdetailsvc

- (void)viewDidLoad {
    [super viewDidLoad];
    [_baseview.layer setMasksToBounds:NO];
    [_baseview.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [_baseview.layer setShadowOpacity:0.6f];
    [_baseview.layer setShadowRadius:10.0f];
    [_baseview.layer setCornerRadius:4.0f];
    [_baseview.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
