//
//  guestuserCell.h
//  KPJ Matrimony
//
//  Created by user on 25/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface guestuserCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UIButton*ViewProfilebtn;
@property(nonatomic,strong)IBOutlet UILabel*namelbl;
@property(nonatomic,strong)IBOutlet UILabel*profileidlbl;
@property(nonatomic,strong)IBOutlet UILabel*agelbl;
@property(nonatomic,strong)IBOutlet UILabel*heightlbl;
@property(nonatomic,strong)IBOutlet UILabel*castlbl;
@property(nonatomic,strong)IBOutlet UILabel*starbl;
@property(nonatomic,strong)IBOutlet UILabel*districtlbl;
@property(nonatomic,strong)IBOutlet UILabel*subcastlblbl;
@property(nonatomic,strong)IBOutlet UILabel*occupationlbl;
@property(nonatomic,strong)IBOutlet UIButton*btnViewProfile;
@end
