//
//  HistoryDetailsVC.m
//  KPJ Matrimony
//
//  Created by user on 02/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "HistoryDetailsVC.h"
#import "ProfileHistoryVC.h"
#import "SWRevealViewController.h"
@interface HistoryDetailsVC ()
{
    NSString *status;
}

@end

@implementation HistoryDetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.navigationController.navigationBar.hidden =NO;
    // Do any additional setup after loading the view.
}

-(IBAction)History_Profiles:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"Profile_History";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
    
}
-(IBAction)History_Contacts:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"Contact_History";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)History_HoroScope:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"Horoscope_History";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)History_ShortListed:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"shortlist_History";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)History_InterestSentHistory:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"InterestSent_History";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
