//
//  CollectionCell.h
//  KPJ Matrimony
//
//  Created by user on 13/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"
@interface CollectionCell : UICollectionViewCell
@property(nonatomic,strong)IBOutlet UILabel *namelbl;
@property(nonatomic,strong)IBOutlet UILabel *Profileidlbl;
@property(nonatomic,strong)IBOutlet UILabel *heightlbl;
@property(nonatomic,strong)IBOutlet UILabel *agelbllbl;
@property(nonatomic,strong)IBOutlet UILabel *Castlbl;
@property(nonatomic,strong)IBOutlet UIImageView *imageviwew;
@property(nonatomic,strong)IBOutlet UIImageView *imafe;
@end
