//
//  CollectionCell.m
//  KPJ Matrimony
//
//  Created by user on 13/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "CollectionCell.h"

@implementation CollectionCell

@end
