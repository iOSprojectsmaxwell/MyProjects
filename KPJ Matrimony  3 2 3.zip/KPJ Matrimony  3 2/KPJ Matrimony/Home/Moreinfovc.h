//
//  Moreinfovc.h
//  KPJ Matrimony
//
//  Created by user on 13/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

@interface Moreinfovc : UIViewController
@property(strong,nonatomic)IBOutlet UIImageView *images;
@property(strong,nonatomic)NSString *imagetrasnfer ;

@property(strong,nonatomic)NSString *name ;
@property(strong,nonatomic)NSString *age ;
@property(strong,nonatomic)NSString *height ;
@property(strong,nonatomic)NSString *star ;
@property(strong,nonatomic)NSString *district ;
@property(strong,nonatomic)NSString *castname ;
@property(strong,nonatomic)NSString *subCastName ;
@property(strong,nonatomic)NSString *occupation ;
@property(strong,nonatomic)NSString *imagess ;
@property(strong,nonatomic)NSString *profile_id ;



@property(strong,nonatomic)IBOutlet UILabel *namelbl ;
@property(strong,nonatomic)IBOutlet UILabel *agelbl ;
@property(strong,nonatomic)IBOutlet UILabel *heightlbl ;
@property(strong,nonatomic)IBOutlet UILabel *starlbl ;
@property(strong,nonatomic)IBOutlet UILabel *districtlbl ;
@property(strong,nonatomic)IBOutlet UILabel *castnamelbl ;
@property(strong,nonatomic)IBOutlet UILabel *subCastNamelbl ;
@property(strong,nonatomic)IBOutlet UILabel *occupationlbl ;
@property(strong,nonatomic)IBOutlet UIImageView *imagessimage ;
@property(strong,nonatomic)IBOutlet UILabel *profile_idlbl ;
@end
