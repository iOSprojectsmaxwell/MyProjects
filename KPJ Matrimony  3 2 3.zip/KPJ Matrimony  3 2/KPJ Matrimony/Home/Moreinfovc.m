//
//  Moreinfovc.m
//  KPJ Matrimony
//
//  Created by user on 13/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "Moreinfovc.h"

@interface Moreinfovc ()

@end

@implementation Moreinfovc


- (void)viewDidLoad {
    [super viewDidLoad];
    
 _profile_id =[_imagetrasnfer valueForKey:@"profile_id"];
    _name =[_imagetrasnfer valueForKey:@"name"];
    _age =[_imagetrasnfer valueForKey:@"age"];
    _height =[_imagetrasnfer valueForKey:@"height"];
    _star =[_imagetrasnfer valueForKey:@"star"];
    _district =[_imagetrasnfer valueForKey:@"district"];
    _castname =[_imagetrasnfer valueForKey:@"caste_name"];
    
    _subCastName =[_imagetrasnfer valueForKey:@"age"];
    _occupation =[_imagetrasnfer valueForKey:@"height"];
    _imagess =[_imagetrasnfer valueForKey:@"image"];
   
 
   _imagessimage.layer.cornerRadius = _imagessimage.frame.size.width / 2;
    _imagessimage.clipsToBounds = YES;
    
    _namelbl.text =_name;
    _agelbl.text =        [NSString stringWithFormat:@"Age           :    %@",_age];
    _heightlbl.text =     [NSString stringWithFormat:@"Height        :    %@",_height];
    _starlbl.text =       [NSString stringWithFormat:@"Star          :    %@",_star];
    _districtlbl.text =   [NSString stringWithFormat:@"District      :    %@",_district];
    _castnamelbl.text =   [NSString stringWithFormat:@"Cast          :    %@",_castname];
    _subCastNamelbl.text =[NSString stringWithFormat:@"SubCast       :    %@",_castname];
    _occupationlbl.text = [NSString stringWithFormat:@"Occupation    :    %@",_occupation];
    
    _profile_idlbl.text = [NSString stringWithFormat:@"ProfileID     :    %@",_profile_id];
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      //  NSString *imgURL = [_imagess objectAtIndex:indexPath.row];
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:_imagess]];
        
        //set your image on main thread.
        dispatch_async(dispatch_get_main_queue(), ^{
            [_imagessimage setImage:[UIImage imageWithData:data]];
        });
    });
    
    
    UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *blurEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    blurEffectView.frame = self.images.bounds;
    blurEffectView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;


   
    
    
    
    
    //ADD BLUR EFFECT VIEW IN MAIN VIEW
    [self.images addSubview:blurEffectView];
    //_images.image =[UIImage imageNamed:_imagetrasnfer];
    // Do any additional setup after loading the view.
}
-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
