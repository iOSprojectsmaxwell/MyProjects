//
//  homevc.m
//  KPJ Matrimony
//
//  Created by Admin on 21/07/2018.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "homevc.h"
#import "SidemenuView.h"
#import "registervc.h"
#import "contactusvc.h"
#import "loginView.h"
#import "Moreinfovc.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "MBProgressHUD.h"
#import "CollectionCell.h"
#import <QuartzCore/QuartzCore.h>
#import "CLPopListView.h"
#import "HomeCell.h"
#import <QuartzCore/CALayer.h>
#import "Common.h"
#import "SWRevealViewController.h"
#import "MyHoroscopeVC.h"
#import "ViewPhoneVC.h"

@interface homevc ()<MBProgressHUDDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSArray *imagesArry;
    NSString *namelbl;
    NSString *castelbl;
    NSString *heightlabl;
    NSString *idlbl;
    SidemenuView *objSideMenuView;
    NSArray *profiles;
    NSDictionary *dict2;
    NSArray *ProfileId;
    NSArray *name;
    NSString *durationStr1;
     NSArray *age;
     NSArray *height;
      NSArray *star;
     NSArray *district;
     MBProgressHUD *HUD;
       NSArray *caste_name;
     NSArray *subcaste_name;
      NSArray *occupation;
      NSArray *image;
    NSArray *Lookingfor;
    NSMutableArray *agestart;
    NSMutableArray *ageend;
    int i;
    NSString *apiURLStr;
    NSArray *search_list;
      NSArray *stardl;
      NSArray *stardetails;
    NSArray *education;
    NSArray *educationdl;
       NSArray *education_id;
    NSDictionary *dict1;
    NSArray *cast;
    NSArray *cast_id;
    NSArray *caste_name1;
    
    NSString *Edu_id;
    NSString *cat_id;
      NSString *User_id;
    
    
     NSString *SelectedProfileID;
}



@property (weak, nonatomic) IBOutlet UITextField *stdfeild;

@property(nonatomic,strong)IBOutlet MyImageView *image1;
@property(nonatomic,strong)IBOutlet UITableView *Tablview;
@end

@implementation homevc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    _sentRequestView.hidden =YES;
    _AlertBlure.hidden =YES;
    _AlertVieww.hidden =YES;
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];

    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    User_id = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"User_id"];
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.BlurView addGestureRecognizer:singleFingerTap];
    Lookingfor =[[NSArray alloc]initWithObjects:@"Bride",@"Groom", nil];
    agestart =[[NSMutableArray alloc]init];
    _BlurView.hidden =YES;
    
    [self GetCategories];
    
    //UIColor *color =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1];
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.navigationController.navigationBar.hidden =NO;
    self.SView_name.layer.cornerRadius = 6.0 ;
    self.SView_name.clipsToBounds = true;
    self.SView_name.layer.borderWidth = 1.0f;
    self.SView_name.layer.borderColor =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    self.SA_from.layer.cornerRadius = 6.0 ;
    self.SA_from.clipsToBounds = true;
    self.SA_from.layer.borderWidth = 1.0f;
    self.SA_from.layer.borderColor =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.SA_to.layer.cornerRadius = 6.0 ;
    self.SA_to.clipsToBounds = true;
    self.SA_to.layer.borderWidth = 1.0f;
    self.SA_to.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    [_AlertVieww.layer setMasksToBounds:NO];
    [_AlertVieww.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [_AlertVieww.layer setShadowOpacity:0.6f];
    [_AlertVieww.layer setShadowRadius:2.0f];
    [_AlertVieww.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
    
    self.starView.layer.cornerRadius = 6.0 ;
    self.starView.clipsToBounds = true;
    self.starView.layer.borderWidth = 1.0f;
    self.starView.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    
    self.Education_view.layer.cornerRadius = 6.0 ;
    self.Education_view.clipsToBounds = true;
    self.Education_view.layer.borderWidth = 1.0f;
    self.Education_view.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.cast_view.layer.cornerRadius = 6.0 ;
    self.cast_view.clipsToBounds = true;
    self.cast_view.layer.borderWidth = 1.0f;
    self.cast_view.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.Submit_button.layer.cornerRadius = 4.0 ;
    self.Submit_button.clipsToBounds = true;
    self.Submit_button.layer.borderWidth = 1.0f;
    self.Submit_button.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    //    [_Searchimageview.layer setMasksToBounds:NO];
    //    [_Searchimageview.layer setShadowColor:[[UIColor grayColor] CGColor]];
    //    [_Searchimageview.layer setShadowOpacity:0.6f];
    //    [_Searchimageview.layer setShadowRadius:20.0f];
    //    [_Searchimageview.layer setShadowOffset: CGSizeMake(10.0f, 10.0f)];
    //
    
    _Searchimageview.layer.shadowColor = [UIColor blackColor].CGColor;
    _Searchimageview.layer.shadowOffset = CGSizeMake(0, 1);
    _Searchimageview.layer.shadowOpacity = 10;
    _Searchimageview.layer.shadowRadius = 30.0;
    _Searchimageview.clipsToBounds = NO;
    
    for( int i = 21; i < 50; ++i )
    {
        [agestart addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:i]]];
        [ageend addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:i]]];
    }
    
    
    
    _SearchVC.hidden =YES;
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    [self CallingFirstNews];
    imagesArry =[NSArray arrayWithObjects:@"1img.jpg",@"2img.jpg",@"3img.jpg",@"4img.jpg",@"5img.jpg", nil];
    
    // Do any additional setup after loading the view, typically from a nib.


}
    - (IBAction)Menu:(id)sender {
        
        
        NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
        
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
        if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
            if ([UIScreen mainScreen].bounds.size.height == 1366) {
                objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
            }
        } else {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
        [self addChildViewController:objSideMenuView];
        
        [objSideMenuView didMoveToParentViewController:self];
        
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [button1 addTarget:self
                    action:@selector(aMethod:)
          forControlEvents:UIControlEventTouchUpInside];
        [button1 setTitle:@"X" forState:UIControlStateNormal];
        button1.frame = CGRectMake(211, -16, 55, 55);
        [objSideMenuView.view addSubview:button1];
        [self.view addSubview:objSideMenuView.view];
        
    }
    
    - (IBAction)aMethod:(id)sender
    {
        
        [objSideMenuView removeFromParentViewController];
        [objSideMenuView.view removeFromSuperview];
        
        
    }



- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:[recognizer.view superview]];
    
    _BlurView.hidden=YES;
  
    //Do stuff here...
}
-(IBAction)search_button:(id)sender{
    
    _BlurView.hidden=NO;
    _searchbtn.layer.cornerRadius = 7; // this value vary as per your desire
    _searchbtn.clipsToBounds = YES;
    [_searchImage.layer setMasksToBounds:NO];
    [_searchImage.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [_searchImage.layer setShadowOpacity:0.6f];
    [_searchImage.layer setShadowRadius:15.0f];
    [_searchImage.layer setCornerRadius:24.0f];
    [_searchImage.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
}
-(void)CallingFirstNews

{
    [HUD show:YES];
    
  
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/new_profiles.php?user_id=%@",User_id];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
       
        dispatch_async(dispatch_get_main_queue(), ^{
             dict2=[sampleURL JSONValue];
            profiles =[dict2 valueForKey:@"profiles"];
             ProfileId =[profiles valueForKey:@"profile_id"];
             name =[profiles valueForKey:@"name"];
             age =[profiles valueForKey:@"age"];
             height =[profiles valueForKey:@"height"];
            caste_name =[profiles valueForKey:@"caste_name"];
            image =[profiles valueForKey:@"image"];
             star =[profiles valueForKey:@"star"];
             district =[profiles valueForKey:@"district"];
           subcaste_name =[profiles valueForKey:@"subcaste_name"];
              occupation =[profiles valueForKey:@"occupation"];
            [self.Tablview reloadData];
        
         
            [HUD hide:YES];
            
        });
    });
    
    
    
}
-(void)GetCategories

{
    [HUD show:YES];
    

  
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/search_category.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict1=[sampleURL JSONValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            
            search_list =[dict1 valueForKey:@"search_list"];
           stardl =[search_list valueForKey:@"star"];
             stardetails =[stardl valueForKey:@"star"];
           education =[search_list valueForKey:@"education"];
        educationdl =[education valueForKey:@"education"];
            education_id =[education valueForKey:@"id"];
            cast =[search_list valueForKey:@"caste"];
             cast_id =[cast valueForKey:@"id"];
            caste_name1 =[cast valueForKey:@"caste_name"];
            [HUD hide:YES];
            
        });
    });
    
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}


//MARK:- Table View Delegated & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return ProfileId.count;    //count number of row from counting array hear cataGorry is An Array
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    //    cell.backgroundColor = [UIColor colorWithRed:246/255.0f green:245/255.0f blue:245/255.0f alpha:1.0];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"HomeCell";
    
  
    HomeCell  *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[HomeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    _Tablview.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _image1=(MyImageView*)[cell viewWithTag:1];
    

    
     [cell.btnSendRequest addTarget:self action:@selector(btnSendRequest:) forControlEvents:UIControlEventTouchUpInside];
    
     [cell.btnViewPhone addTarget:self action:@selector(btnViewPhone:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
      [cell.btnViewHoroscop addTarget:self action:@selector(btnViewHoroscop:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btnShortList.tag = indexPath.row;
    NSString *path=[image objectAtIndex:indexPath.row];
    [cell.btnShortList addTarget:self action:@selector(BtnShortListed:) forControlEvents:UIControlEventTouchUpInside];
    // NSLog(@"path %@",path);
    
//   cell.btnViewProfile.layer.cornerRadius = 10; // this value vary as per your desire
//    cell.btnViewProfile.clipsToBounds = YES;
    cell.namelbl.text =[name objectAtIndex:indexPath.row];
    [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    // cell.listofimgs.image = [UIImage imageNamed:listfimgs[indexPath.row]];
    cell.profileidlbl.text =[ProfileId objectAtIndex:indexPath.row];
    cell.agelbl.text =[NSString stringWithFormat:@"%@",[age objectAtIndex:indexPath.row]];
      cell.heightlbl.text =[NSString stringWithFormat:@"%@",[height objectAtIndex:indexPath.row]];
    
    cell.castlbl.text =[caste_name objectAtIndex:indexPath.row];
    cell.starbl.text =[star objectAtIndex:indexPath.row];
    
    
    cell.districtlbl.text =[district objectAtIndex:indexPath.row];
    cell.subcastlblbl.text =[subcaste_name objectAtIndex:indexPath.row];
     cell.occupationlbl.text =[occupation objectAtIndex:indexPath.row];
    
    return cell;
    
}
- (IBAction)Yes_Button:(id)sender {
    
    if ([_AlertLbl.text isEqualToString:@"Do you want to shortlist this profile?"]) {
   // http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=132&view_profile_id=180643

        
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=%@&view_profile_id=%@",User_id,SelectedProfileID];
        
        //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
        
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
        
        // send a block to the queue - Not in Main thread
        dispatch_async(queue, ^{
            
            
            NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                dict2=[sampleURL JSONValue];
                
                NSString *profile_shortlist_details =[dict2 valueForKey:@"profile_shortlist_details"];
                 NSString *shortlist =[dict2 valueForKey:@"shortlist"];
                if ([shortlist isEqualToString:@"added"]) {
                 [Common AlertShowWithErrorMsg:@"This Profie Have ShortListed!"];
                }
                else{
                    
                [Common AlertShowWithErrorMsg:@"This Profie Have removed from ShortList!"];
                }
                _AlertBlure.hidden =YES;
                
                [HUD hide:YES];
                
            });
        });
        
        
    }
    else{
        
        
    }
    
    
    
}

- (IBAction)No_Button:(id)sender {
    
    _AlertBlure.hidden =YES;
}


- (IBAction)Send_Interest:(id)sender {
//http://www.kpjmatrimony.com/api/interest_sent_details.php?login_user_id=132&view_profile_id=180643

  
        // http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=132&view_profile_id=180643
        
        
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/interest_sent_details.php?login_user_id=%@&view_profile_id=%@",User_id,SelectedProfileID];
        
        //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
        
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
        
        // send a block to the queue - Not in Main thread
        dispatch_async(queue, ^{
            
            
            NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                dict2=[sampleURL JSONValue];
                
                NSString *profile_shortlist_details =[dict2 valueForKey:@"profile_shortlist_details"];
                NSString *shortlist =[dict2 valueForKey:@"shortlist"];
                if ([shortlist isEqualToString:@"added"]) {
                    [Common AlertShowWithErrorMsg:@"This Profie Have Sent Request"];
                }
                else{
                    
                    [Common AlertShowWithErrorMsg:@"This Profie Have removed from Sent Request"];
                }
                _AlertBlure.hidden =YES;
                
                [HUD hide:YES];
                
            });
        });
        
        
    }

    
    
    


- (IBAction)No_interest:(id)sender {
    
    _AlertBlure.hidden =YES;
}





-(void)BtnShortListed:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
    _AlertLbl.text =@"Do you want to shortlist this profile?";
    _sentRequestView.hidden =YES;
    _AlertVieww.hidden =NO;
     _AlertBlure.hidden =NO;
    
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
  
}

-(void)btnViewPhone:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
//    _AlertLbl.text =@"Do you want to shortlist this profile?";
//    _AlertBlure.hidden =NO;
    
   // SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
    ViewPhoneVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhoneVC"];
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}

-(void)btnViewHoroscop:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
  //  _AlertLbl.text =@"Do you want to shortlist this profile?";
   // _AlertBlure.hidden =NO;
    MyHoroscopeVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyHoroscopeVC"];
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}
-(void)btnSendRequest:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
    _AlertLbl.text =@"Do you want to shortlist this profile?";
    _AlertBlure.hidden =NO;
    
    _AlertVieww.hidden =YES;
    _sentRequestView.hidden =NO;
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    
    return 250;
    
}

-(void)SearchAPI
{
    NSString *typee;
   [HUD show:YES];
   
    
    if ([_SF_name.text isEqualToString:@"Groom"]) {
        typee =@"2";
    }
    else{
        typee =@"1";
    }
    
   
    NSString *trimmed = [_StarFeild.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/search_results.php?user_id=%@&type=%@&age_from=%@&age_to=%@&star=%@&education=%@&regid=%@",User_id,typee,_SA_fromtext.text,_AS_totext.text,trimmed,Edu_id,cat_id];
    
  //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
       
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
       
        dispatch_async(dispatch_get_main_queue(), ^{
             dict2=[sampleURL JSONValue];
            profiles =[dict2 valueForKey:@"response"];
            
            ProfileId =[profiles valueForKey:@"profile_id"];
            name =[profiles valueForKey:@"name"];
            age =[profiles valueForKey:@"age"];
            height =[profiles valueForKey:@"height"];
            caste_name =[profiles valueForKey:@"caste_name"];
            image =[profiles valueForKey:@"image"];
            
            [self.Tablview reloadData];
            _BlurView.hidden =YES;
            
            [HUD hide:YES];
            
        });
    });
    
    
    
    
    
}


-(IBAction)submit_search:(id)sender{

    if (_SF_name.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please select your looking for"];
    }
    else if (_SA_fromtext.text.length ==0)
    {
 [Common AlertShowWithErrorMsg:@"Please select Age"];
    }
    else if (_AS_totext.text.length ==0)
    {
[Common AlertShowWithErrorMsg:@"Please select Age"];
    }
    else if (_StarFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Star"];
    }
    else if (_education_txt.text.length ==0)
    {
[Common AlertShowWithErrorMsg:@"Please select Eduction"];
    }
    else if (_Cast_Txt.text.length ==0)
    {
[Common AlertShowWithErrorMsg:@"Please select Caste"];
    }
    else{
        [self SearchAPI] ;
   }
}

-(IBAction)lokkingfor:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Looking For" options:Lookingfor handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=100;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)Cast_Search:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Caste" options:caste_name1 handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=108;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Age:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Age" options:agestart handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=101;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Age1:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Age" options:agestart handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=102;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)star:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Star" options:stardetails handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=103;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)education:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Education" options:educationdl handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=104;
    [lplv showInView:self.view.window animated:YES];
    
    
}



- (void)leveyPopListView:(CLPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    if(popListView.tag==100)
    {
        //btnEventSize.titleLabel.text = [DurationArray objectAtIndex:anIndex];
        durationStr1 = [NSString stringWithFormat:@"%@",[Lookingfor objectAtIndex:anIndex]];

        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];

       // NSString *lower = [durationStr1 uppercaseString];

        _SF_name.text =durationStr1;

    }
    
    else if (popListView.tag==101)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[agestart objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
       // NSString *lower = [durationStr1 uppercaseString];
        
        _SA_fromtext.text =durationStr1;

        
    }
    else if (popListView.tag==102)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[agestart objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _AS_totext.text =durationStr1;
        
        
    }
    else if (popListView.tag==103)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[stardetails objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _StarFeild.text =durationStr1;
        
        
    }
    else if (popListView.tag==104)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[educationdl objectAtIndex:anIndex]];
    
          Edu_id =[NSString stringWithFormat:@"%@",[education_id objectAtIndex:anIndex]];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _education_txt.text =durationStr1;
        
        
    }
    else if (popListView.tag==108)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[caste_name1 objectAtIndex:anIndex]];
        
       cat_id =[NSString stringWithFormat:@"%@",[cast_id objectAtIndex:anIndex]];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Cast_Txt.text =durationStr1;
        
        
    }
}


-(IBAction)Shortlistalert:(id)sender

{
    [Common AlertShowWithErrorMsg:@"Please Call Us:9789888444"];
}
-(IBAction)sendinterestalert:(id)sender

{
    [Common AlertShowWithErrorMsg:@"Please Call Us:9789888444"];
}
-(IBAction)viewphonealert:(id)sender

{
    [Common AlertShowWithErrorMsg:@"Please Call Us:9789888444"];
}
-(IBAction)horoscopealert:(id)sender

{
    [Common AlertShowWithErrorMsg:@"Please Call Us:9789888444"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
