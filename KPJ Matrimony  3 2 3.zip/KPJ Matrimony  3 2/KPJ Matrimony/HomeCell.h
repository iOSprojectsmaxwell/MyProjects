//
//  HomeCell.h
//  LadiesSpecial
//
//  Created by user on 21/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

@interface HomeCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UIView*baseView;
@property(strong,nonatomic)IBOutlet MyImageView *listofimgs;
@property(strong,nonatomic)IBOutlet UILabel *namelbl;
@property(strong,nonatomic)IBOutlet UILabel *profileidlbl;
@property(strong,nonatomic)IBOutlet UILabel *agelbl;

@property(strong,nonatomic)IBOutlet UILabel *heightlbl;
@property(strong,nonatomic)IBOutlet UILabel *starbl;
@property(strong,nonatomic)IBOutlet UILabel *districtlbl;

@property(strong,nonatomic)IBOutlet UILabel *castlbl;
@property(strong,nonatomic)IBOutlet UILabel *subcastlblbl;
@property(strong,nonatomic)IBOutlet UILabel *occupationlbl;

@property(nonatomic,strong)IBOutlet UIView *ShortListView;
@property(strong,nonatomic)IBOutlet UITextView *listoftittles;
@property(strong,nonatomic)IBOutlet UIButton *btnviewprofile;
@property(strong,nonatomic)IBOutlet UIButton *btnShortList;

@property(strong,nonatomic)IBOutlet UIButton *btnSendRequest;
@property(strong,nonatomic)IBOutlet UIButton *btnViewPhone;

@property(strong,nonatomic)IBOutlet UIButton *btnViewHoroscop;



@property(strong,nonatomic)IBOutlet UIButton *btnviews;





@property (weak, nonatomic) IBOutlet MyImageView *profilePic;

@property (weak, nonatomic) IBOutlet UILabel *ContactDetailslbl;
@property (weak, nonatomic) IBOutlet UILabel *ProfileIDLbl;
@property (weak, nonatomic) IBOutlet UILabel *contactnamelbl;
@property (weak, nonatomic) IBOutlet UILabel *agecontactlbl;
@property (weak, nonatomic) IBOutlet UILabel *dateofBirthLbl;
@property (weak, nonatomic) IBOutlet UILabel *Gothramlbl;
@property (weak, nonatomic) IBOutlet UILabel *starLbl;
@property (weak, nonatomic) IBOutlet UILabel *Raasilbl;


@end
