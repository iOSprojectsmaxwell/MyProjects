//
//  HomeCell.m
//  LadiesSpecial
//
//  Created by user on 21/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "HomeCell.h"

@implementation HomeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
 
//    _baseView.backgroundColor = [UIColor whiteColor];
//    _baseView.layer.shadowColor = [UIColor whiteColor].CGColor;
//    _baseView.layer.shadowOffset = CGSizeMake(0, 0);
//    _baseView.layer.shadowOpacity = 0.3;
//    _baseView.layer.shadowRadius = 2.0;
    
    [_baseView.layer setMasksToBounds:NO];
    [_baseView.layer setShadowColor:[[UIColor blackColor] CGColor]];
    [_baseView.layer setShadowOpacity:0.6f];
    [_baseView.layer setShadowRadius:5.0f];
    [_baseView.layer setCornerRadius:5.0f];
    [_baseView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    
   
//      [cell.baseView.layer setMasksToBounds:NO];
//     [cell.baseView.layer setShadowColor:[[UIColor blackColor] CGColor]];
//     [cell.baseView.layer setShadowOpacity:0.6f];
//     [cell.baseView.layer setShadowRadius:10.0f];
//     [cell.baseView.layer setCornerRadius:4.0f];
//     [cell.baseView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
//
    
    
    self.btnviewprofile.layer.borderWidth = 1.0f;
    self.btnviewprofile.layer.borderColor =[UIColor clearColor].CGColor;
    
    self.btnShortList.layer.borderWidth = 1.0f;
    self.btnShortList.layer.borderColor =[UIColor clearColor].CGColor;
    
    self.btnSendRequest.layer.borderWidth = 1.0f;
    self.btnSendRequest.layer.borderColor =[UIColor clearColor].CGColor;
    
    self.btnViewPhone.layer.borderWidth = 1.0f;
    self.btnViewPhone.layer.borderColor =[UIColor clearColor].CGColor;
    
    self.btnViewHoroscop.layer.borderWidth = 1.0f;
    self.btnViewHoroscop.layer.borderColor =[UIColor clearColor].CGColor;
    
  
   
    [_listofimgs.layer setMasksToBounds:NO];
    [_listofimgs.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [_listofimgs.layer setShadowOpacity:0.6f];
    [_listofimgs.layer setShadowRadius:2.0f];
    [_listofimgs.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    _btnShortList.layer.cornerRadius = 7; // this value vary as per your desire
    _btnShortList.clipsToBounds = YES;
    _ShortListView.layer.cornerRadius = 7; // this value vary as per your desire
    _ShortListView.clipsToBounds = YES;
    
    
    
    _btnSendRequest.layer.cornerRadius = 7; // this value vary as per your desire
    _btnSendRequest.clipsToBounds = YES;
    
    
    _btnShortList.layer.cornerRadius = 7; // this value vary as per your desire
    _btnShortList.clipsToBounds = YES;
    
    
    
    
//    _magazineImage.backgroundColor = [UIColor ];
//    _magazineImage.layer.shadowColor = [UIColor whiteColor].CGColor;
//    _magazineImage.layer.shadowOffset = CGSizeMake(0, 0);
//    _magazineImage.layer.shadowOpacity = 0.3;
//    _magazineImage.layer.shadowRadius = 2.0;
    
    // improve performance
//    _baseView.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:_baseView.bounds cornerRadius:4].CGPath;
//    _baseView.layer.shouldRasterize = YES;
//    _baseView.layer.rasterizationScale = [UIScreen mainScreen].scale;
    
   // [_baseView addSubview:self];
    //use Masonry autolayout, self can set corner radius
//    [self makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.equalTo(_baseView);
//    }];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
