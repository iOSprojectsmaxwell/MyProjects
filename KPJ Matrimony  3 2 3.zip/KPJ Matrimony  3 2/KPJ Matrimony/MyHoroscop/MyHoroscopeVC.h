//
//  MyHoroscopeVC.h
//  KPJ Matrimony
//
//  Created by user on 29/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface MyHoroscopeVC : UIViewController
@property(nonatomic,strong)NSString *SelectedProfileID;
@property(nonatomic,strong)NSString *SelectedProfileID1;
@end


