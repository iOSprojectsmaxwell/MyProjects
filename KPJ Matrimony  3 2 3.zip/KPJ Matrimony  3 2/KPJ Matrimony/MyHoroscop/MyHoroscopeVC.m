//
//  MyHoroscopeVC.m
//  KPJ Matrimony
//
//  Created by user on 29/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "MyHoroscopeVC.h"
#import "Json.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Common.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"

@interface MyHoroscopeVC ()<UITextFieldDelegate,MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *Login;
    NSString *user_email;
    NSString *user_name;
    NSString *user_primary_mobile_no;
    NSString *user_id;
    
    NSArray *profile_horoscope_details;
      NSArray *profile_details;
    NSString *horoscope_image;
    NSString *name;
    
    

}
@property(nonatomic,strong)IBOutlet MyImageView *imagaeview;
@property(nonatomic,strong)IBOutlet UILabel *lblname;
@property(nonatomic,strong)NSString *stt;
@end

@implementation MyHoroscopeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    
    [self ViewHoroscope];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    // Do any additional setup after loading the view.
}

- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)ViewHoroscope
{
        [HUD show:YES];
        //user_name
        //pswd
        
        // [HUD hide:YES];
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
//        http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=132&view_profile_id=180643
//    
        // data processing
    NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=%@&view_profile_id=%@",user_id,_SelectedProfileID];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"dicr]t %@",dict2);
            
            
            profile_horoscope_details =[dict2 valueForKey:@"profile_horoscope_details"];
           profile_details =[profile_horoscope_details valueForKey:@"profile_details"];;
           horoscope_image =[[profile_details valueForKey:@"horoscope"]objectAtIndex:0];;
            name =[[profile_details valueForKey:@"name"]objectAtIndex:0];
            
            
            _lblname.text =name;
    
           [_imagaeview addImageFrom:[horoscope_image stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
             [HUD hide:YES];
        });
    };



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
