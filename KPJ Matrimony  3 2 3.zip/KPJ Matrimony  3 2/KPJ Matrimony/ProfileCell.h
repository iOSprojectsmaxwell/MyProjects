//
//  ProfileCell.h
//  KPJ Matrimony
//
//  Created by user on 03/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ProfileCell : UITableViewCell
@property(strong,nonatomic)IBOutlet MyImageView *Profile_Image;
@property(nonatomic,strong)IBOutlet UILabel *profile_id;
@property(nonatomic,strong)IBOutlet UILabel *profile_name;
@property(nonatomic,strong)IBOutlet UILabel *profile_ageHeight;
@property(nonatomic,strong)IBOutlet UILabel *profile_star;
@property(nonatomic,strong)IBOutlet UILabel *profile_Location;
@property(nonatomic,strong)IBOutlet UILabel *profile_Qualification;
@property(nonatomic,strong)IBOutlet UILabel *profile_Caste;
@property(nonatomic,strong)IBOutlet UILabel *profile_Profession;
@property(nonatomic,strong)IBOutlet UIButton *btnviewProfile;

@property(nonatomic,strong)IBOutlet UIButton *BtnViewPhoneNo;

@property(nonatomic,strong)IBOutlet UIButton *btnshortList;
;
@property(nonatomic,strong)IBOutlet UIButton *btninterestSent;
@property(nonatomic,strong)IBOutlet UIButton *btnhoroscope;

@property(nonatomic,strong)IBOutlet UIView *btnshortList_View;
;
@property(nonatomic,strong)IBOutlet UIView *btninterestSent_View;

;

@end

NS_ASSUME_NONNULL_END
