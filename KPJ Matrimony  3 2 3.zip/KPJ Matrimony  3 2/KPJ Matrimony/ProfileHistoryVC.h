//
//  ProfileHistoryVC.h
//  KPJ Matrimony
//
//  Created by user on 02/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProfileHistoryVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)IBOutlet UITableView *tablewvieww;
@property(nonatomic,strong)NSString *Status;;
@property(nonatomic,strong)IBOutlet UILabel*lblname;
@end

NS_ASSUME_NONNULL_END
