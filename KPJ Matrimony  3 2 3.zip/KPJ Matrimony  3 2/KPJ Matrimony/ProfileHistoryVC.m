//
//  ProfileHistoryVC.m
//  KPJ Matrimony
//
//  Created by user on 02/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ProfileHistoryVC.h"
#import "Json.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Common.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "ProfileCell.h"
#import "FullProfileVC.h"
#import "common.h"
#import "ViewPhoneVC.h"
#import "MyHoroscopeVC.h"
@interface ProfileHistoryVC ()<UITextFieldDelegate,MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *Login;
    NSString *user_email;
    NSString *user_name;
    NSString *user_primary_mobile_no;
    NSString *user_id;
    
    NSString *org;
    NSArray *interest;
     NSArray *shortlist;
    NSArray *send_interest_profiles_history;
    NSArray *data;
    NSArray *profile_id;
    NSArray *name;
    NSArray *age;
    NSArray *height;
    NSString *SelectedProfileID;
    NSArray *star;
    NSArray *district;
    NSArray *caste_name;
    NSArray *occupation;
      NSArray *image;
    NSString *apiURLStr;
    
    NSString *interest_status;
    
  NSString *ShortList_status;
    NSString *shortlist_message;
    
       NSString *interest_message;
    
    NSString *sg;

}
@property(nonatomic,strong)IBOutlet MyImageView *imagaeview;


@end

@implementation ProfileHistoryVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    
    
    
  
    
  
    
    
    
    
    
    [self ViewHoroscope];
    
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)ViewHoroscope
{
    
    sg = [[NSUserDefaults standardUserDefaults]
          stringForKey:@"Status"];
    
    
    if ([sg isEqual:[NSNull null]] || sg==nil || [sg isEqualToString:@"<null>"] || [sg isEqualToString:@"(null)"] || sg.length==0 || [sg isEqualToString:@""])
    {
        
        
    }
    else{
        _Status =sg;
        
    }
    [HUD show:YES];
    //user_name
    //pswd
    
    // [HUD hide:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    //        http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=132&view_profile_id=180643
    //
    // data processing
    
    
    if ([_Status isEqualToString:@"Profile_History"]) {
         apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/profile_history.php?user_id=%@",user_id];
        
        _lblname.text =@"Profile History";
    }
    else if ([_Status isEqualToString:@"Contact_History"])
    {
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/contact_history.php?user_id=%@",user_id];
         _lblname.text =@"Contact History";
    }
    else if ([_Status isEqualToString:@"Horoscope_History"])
    {
         apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/horoscope_history.php?user_id=%@",user_id];
         _lblname.text =@"Horoscope History";
    }
    else if ([_Status isEqualToString:@"shortlist_History"])
    {
       apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/shortlisted_profiles_history.php?user_id=%@",user_id];
         _lblname.text =@"ShortListed Profiles History";
    }
    else if ([_Status isEqualToString:@"InterestSent_History"])
    {
       apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/send_interest_profiles_history.php?user_id=%@",user_id];
         _lblname.text =@"Interest Sent History";
    }
    else if ([_Status isEqualToString:@"WhoShort"])
    {
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/who_shortlisted_me_profiles_history.php?user_id=%@",user_id];
          _lblname.text =@"Who Shortlisted my Profile";
    }
    else if ([_Status isEqualToString:@"WhoRequest"])
    {
         apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/who_interest_me_profiles_history.php?user_id=%@",user_id];
         _lblname.text =@"Who Sent Interest to Me";
    }
    else if ([_Status isEqualToString:@"WhoHoroscope"])
    {
         apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/who_viewed_my_horoscope_history.php?user_id=%@",user_id];
         _lblname.text =@"Who viewed my Horoscope";
    }
    else if ([_Status isEqualToString:@"WhoPhone"])
    {
         apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/who_viewed_my_contact_history.php?user_id=%@",user_id];
         _lblname.text =@"Who viewed my Mobile no";
    }
    else if ([_Status isEqualToString:@"MyMatch"])
    {
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/recommended_matches_profiles.php?user_id=%@",user_id];
        _lblname.text =@"Recommended Matches";
    }
    else if ([_Status isEqualToString:@"Join"])
    {
        apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/new_profiles.php?user_id=%@",user_id];
        _lblname.text =@"New profiles";
    }
 
    
    
    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
    
    dict2=[sampleURL JSONValue];
    
    // Interaction with User Interface - Main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSLog(@"dicr]t %@",dict2);
        if ([_Status isEqualToString:@"Profile_History"]) {
            
            send_interest_profiles_history =[dict2 valueForKey:@"profile_history"];
        }
        else if ([_Status isEqualToString:@"Contact_History"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"contact_history"];
        }
        else if ([_Status isEqualToString:@"Horoscope_History"])
        {
             send_interest_profiles_history =[dict2 valueForKey:@"horoscope_history"];
        }
        else if ([_Status isEqualToString:@"shortlist_History"])
        {
             send_interest_profiles_history =[dict2 valueForKey:@"shortlisted_profiles_history"];
        }
        else if ([_Status isEqualToString:@"InterestSent_History"])
        {
           send_interest_profiles_history =[dict2 valueForKey:@"send_interest_profiles_history"];
        }
     
        else if ([_Status isEqualToString:@"WhoShort"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"who_shortlisted_me_profiles_history"];
        }
        else if ([_Status isEqualToString:@"WhoRequest"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"send_interest_profiles_history"];
        }
        else if ([_Status isEqualToString:@"WhoHoroscope"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"who_viewed_my_horoscope_history"];
        }
        else if ([_Status isEqualToString:@"WhoPhone"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"who_viewed_my_contact_history"];
        }
        else if ([_Status isEqualToString:@"MyMatch"])
        {
            send_interest_profiles_history =[dict2 valueForKey:@"recommend_matches_profiles"];
        }
        else if ([_Status isEqualToString:@"Join"])
        {
            data =[dict2 valueForKey:@"profiles"];
        }
        NSString *message_code =[NSString stringWithFormat:@"%@",[send_interest_profiles_history valueForKey:@"message_code"]];
        
        if ([message_code isEqualToString:@"0"]) {
            [Common AlertShowWithErrorMsg:@"Profile not available."];
        }
        else{
           if ([_Status isEqualToString:@"Join"])
            {
                data =[dict2 valueForKey:@"profiles"];
            }
           else{
              data=[send_interest_profiles_history valueForKey:@"data"];
           }
            NSLog(@"data %@",data);
            
            interest =[data valueForKey:@"interest"];
            shortlist =[data valueForKey:@"shortlist"];
        profile_id=[data valueForKey:@"profile_id"];
       name=[data valueForKey:@"name"];
        age=[data valueForKey:@"age"];
        height=[data valueForKey:@"height"];
        
       star=[data valueForKey:@"star"];
        district=[data valueForKey:@"district"];
        caste_name=[data valueForKey:@"caste_name"];
        occupation=[data valueForKey:@"occupation"];
        image=[data valueForKey:@"image"];
        [_tablewvieww reloadData];
        }
     
        [HUD hide:YES];
    });
};
                  
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}


//MARK:- Table View Delegated & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return name.count;    //count number of row from counting array hear cataGorry is An Array
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    //    cell.backgroundColor = [UIColor colorWithRed:246/255.0f green:245/255.0f blue:245/255.0f alpha:1.0];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"ProfileCell";
    
    
    ProfileCell  *cell = (ProfileCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[ProfileCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ProfileCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    _tablewvieww.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
  //  _imagaeview=(MyImageView*)[cell viewWithTag:1];
    [cell.btnviewProfile addTarget:self action:@selector(btnViewProfile:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    
   //  NSString *path =[image objectAtIndex:indexPath.row];
    cell.profile_name.text =[name objectAtIndex:indexPath.row];
   // [_imagaeview addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    NSString *sent_interest =[NSString stringWithFormat:@"%@",[interest objectAtIndex:indexPath.row]];
     NSString *short_list =[NSString stringWithFormat:@"%@",[shortlist objectAtIndex:indexPath.row]];
    
    
  
    
    if ([sent_interest isEqualToString:@"1"]) {
        cell.btninterestSent_View.backgroundColor =[UIColor colorWithRed:26/255.0f
                                                                   green:144.0f/255.0f
                                                                    blue:72.0f/255.0f
                                                                   alpha:1.0f];
    }
    else{
        cell.btninterestSent_View.backgroundColor =[UIColor colorWithRed:211/255.0f
                                                                   green:0/255.0f
                                                                    blue:107/255.0f
                                                                   alpha:1.0f];
    }
    if ([short_list isEqualToString:@"1"]) {
        cell.btnshortList_View.backgroundColor =[UIColor colorWithRed:26.0f/255.0f
                                                                green:144.0f/255.0f
                                                                 blue:72.0f/255.0f
                                                                alpha:1.0f];
    }
    else{
        cell.btnshortList_View.backgroundColor =[UIColor colorWithRed:211/255.0f
                                                                   green:0/255.0f
                                                                    blue:107/255.0f
                                                                   alpha:1.0f];
    }
    
    
    cell.btnshortList.tag = indexPath.row;
    [cell.btnshortList addTarget:self action:@selector(BtnShortListed:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btninterestSent.tag = indexPath.row;
    [cell.btninterestSent addTarget:self action:@selector(BtninterestedSent:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.btnhoroscope.tag = indexPath.row;
    [cell.btnhoroscope addTarget:self action:@selector(BtnView_Horoscope:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.BtnViewPhoneNo.tag = indexPath.row;
    [cell.BtnViewPhoneNo addTarget:self action:@selector(BtnView_Phone:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    
    // cell.listofimgs.image = [UIImage imageNamed:listfimgs[indexPath.row]];
    cell.profile_id.text =[profile_id objectAtIndex:indexPath.row];
    cell.profile_ageHeight.text =[NSString stringWithFormat:@"%@/%@",[age objectAtIndex:indexPath.row],[height objectAtIndex:indexPath.row]];
    cell.profile_star.text =[NSString stringWithFormat:@"%@",[star objectAtIndex:indexPath.row]];
    
    cell.profile_Location.text =[district objectAtIndex:indexPath.row];
    cell.profile_Qualification.text =[occupation objectAtIndex:indexPath.row];
    
    
    cell.profile_Caste.text =[caste_name objectAtIndex:indexPath.row];
    cell.profile_Profession.text =[occupation objectAtIndex:indexPath.row];
   // cell.occupationlbl.text =[occupation objectAtIndex:indexPath.row];
    
    return cell;
    
}


-(void)BtninterestedSent:(UIButton*)sender
{
   
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablewvieww];
    
    NSIndexPath *indexPath = [self.tablewvieww indexPathForRowAtPoint:buttonPosition];
    
    ShortList_status =[NSString stringWithFormat:@"%@",[shortlist objectAtIndex:indexPath.row]];
    SelectedProfileID =[profile_id objectAtIndex:indexPath.row];
    if ([ShortList_status isEqualToString:@"0"]) {
        shortlist_message =@"Do you want to shortlist this profile?";
    }
    else{
        
          shortlist_message =@"Do you want to remove the profile from sent interest ?";
      
    }
    
    [self Get_Alert];
    
    
}



-(void)BtnShortListed:(UIButton*)sender
{
    org =@"Short";
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablewvieww];
    
    NSIndexPath *indexPath = [self.tablewvieww indexPathForRowAtPoint:buttonPosition];

    ShortList_status =[NSString stringWithFormat:@"%@",[shortlist objectAtIndex:indexPath.row]];
    SelectedProfileID =[profile_id objectAtIndex:indexPath.row];
    if ([ShortList_status isEqualToString:@"0"]) {
        shortlist_message =@"Do you want to sent interest to this profile?";
    }
    else{
         shortlist_message =@"Do you want to remove the profile from shortlisted ?";
        
    }
    
    [self Get_Alert];
    
    
}

//Messages
 //  Do you want to remove the profile from shortlisted ?

//Do you want to shortlist this profile?


//Messages
//  Do you want to remove the profile from sent interest ?

//Do you want to sent interest to this profile?





-(void)Get_Alert
{
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"KPJ Matrimony"
                                                                  message:shortlist_message
                                                           preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    if ([org isEqualToString:@"Short"]) {
                                        [self Short_List:nil];
                                    }
                                    else{
                                         [self Send_Interest:nil];
                                    }
                                    
                                    /** What we write here???????? **/
                                    
                                    
                                    [[NSUserDefaults standardUserDefaults] setObject:_Status forKey:@"Status"];
                                    [[NSUserDefaults standardUserDefaults] synchronize];
                                    
                                    }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
    
    
    
}

- (IBAction)Send_Interest:(id)sender {
    //http://www.kpjmatrimony.com/api/interest_sent_details.php?login_user_id=132&view_profile_id=180643
    
    
    // http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=132&view_profile_id=180643
    
    
    apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/interest_sent_details.php?login_user_id=%@&view_profile_id=%@",user_id,SelectedProfileID];
    
    //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            dict2=[sampleURL JSONValue];
            
            NSString *profile_shortlist_details =[dict2 valueForKey:@"sent_interest_details"];
            NSString *shortlist =[profile_shortlist_details valueForKey:@"interest"];
            if ([shortlist isEqualToString:@"added"]) {
                [Common AlertShowWithErrorMsg:@"This Profile Have Sent Request"];
            }
            else{
                
                [Common AlertShowWithErrorMsg:@"This Profile Have removed from Sent Request"];
            }
            
            [self ViewHoroscope];
            [HUD hide:YES];
            
        });
    });
    
    
}


- (IBAction)Short_List:(id)sender {
    //http://www.kpjmatrimony.com/api/interest_sent_details.php?login_user_id=132&view_profile_id=180643
    
    
    // http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=132&view_profile_id=180643
    
    
    apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/profile_shortlist_details.php?login_user_id=%@&view_profile_id=%@",user_id,SelectedProfileID];
    
    //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            dict2=[sampleURL JSONValue];
            
            NSString *profile_shortlist_details =[dict2 valueForKey:@"profile_shortlist_details"];
            NSString *shortlist =[profile_shortlist_details valueForKey:@"shortlist"];
            if ([shortlist isEqualToString:@"added"]) {
                [Common AlertShowWithErrorMsg:@"This Profile Have Sent Request"];
            }
            else{
                
                [Common AlertShowWithErrorMsg:@"This Profile Have removed from Sent Request"];
            }
                [self ViewHoroscope];
            
            [HUD hide:YES];
            
        });
    });
    
    
}





-(void)BtnView_Phone:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablewvieww];
    
    NSIndexPath *indexPath = [self.tablewvieww indexPathForRowAtPoint:buttonPosition];
    //    _AlertLbl.text =@"Do you want to shortlist this profile?";
    //    _AlertBlure.hidden =NO;
    
    // SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
    ViewPhoneVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhoneVC"];
    SelectedProfileID =[profile_id objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}

-(void)BtnView_Horoscope:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablewvieww];
    
    NSIndexPath *indexPath = [self.tablewvieww indexPathForRowAtPoint:buttonPosition];
    //  _AlertLbl.text =@"Do you want to shortlist this profile?";
    // _AlertBlure.hidden =NO;
    MyHoroscopeVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyHoroscopeVC"];
    SelectedProfileID =[profile_id objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}




-(void)btnViewProfile:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tablewvieww];
    
    NSIndexPath *indexPath = [self.tablewvieww indexPathForRowAtPoint:buttonPosition];
    //    _AlertLbl.text =@"Do you want to shortlist this profile?";
    //    _AlertBlure.hidden =NO;
    
    // SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
    FullProfileVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Full"];
    
    SelectedProfileID =[profile_id objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 250;
    
}







/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
