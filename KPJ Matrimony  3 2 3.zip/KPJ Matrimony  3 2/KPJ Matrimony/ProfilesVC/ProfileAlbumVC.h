//
//  ProfileAlbumVC.h
//  KPJ Matrimony
//
//  Created by user on 03/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProfileAlbumVC : UIViewController

@end

NS_ASSUME_NONNULL_END
