//
//  ProfilesList.m
//  KPJ Matrimony
//
//  Created by user on 02/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ProfilesList.h"
#import "SWRevealViewController.h"
#import "ProfileHistoryVC.h"
#import "MyFullProfileVC.h"
#import "MyAlbumVC.h"
#import "MyHoroScopNewVC.h"

@interface ProfilesList ()
{
    NSString *status;
}

@end

@implementation ProfilesList

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
  
    
    //UIColor *color =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1];
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.navigationController.navigationBar.hidden =NO;
    // Do any additional setup after loading the view.
}

-(IBAction)My_Profile:(id)sender{
    MyFullProfileVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyFullProfileVC"];
  
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)My_Horo:(id)sender{
    MyHoroScopNewVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyHoroScopNewVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)My_album:(id)sender{
    MyAlbumVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyAlbumVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)WhoShortListed:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"WhoShort";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
    
}
-(IBAction)WhosentRequest:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"WhoRequest";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)WhoViewed_Horoscope:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"WhoHoroscope";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)WhoViewed_Phone:(id)sender{
    ProfileHistoryVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileHistoryVC"];
    status =@"WhoPhone";
    
    controller.Status =status;
    [self.navigationController pushViewController:controller animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
