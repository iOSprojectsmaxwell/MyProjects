//
//  RzTextField.h
//  YRTextField
//
//  Created by Yogesh Raj on 02/06/17.
//  Copyright © 2017 RzGames. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YRTextField.h"

// Application specific customization.
@interface RzTextField : YRTextField

@end
