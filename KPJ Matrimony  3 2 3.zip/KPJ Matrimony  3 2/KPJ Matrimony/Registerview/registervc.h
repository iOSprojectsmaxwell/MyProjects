//
//  registervc.h
//  KPJ Matrimony
//
//  Created by Admin on 10/07/2018.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registervc : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *mobilenum;
@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UITextField *emailadress;
@property (weak, nonatomic) IBOutlet UITextField *dob;
@property (weak, nonatomic) IBOutlet UITextField *castetxt;
@property (weak, nonatomic) IBOutlet UITextField *cityTxt;
@property (weak, nonatomic) IBOutlet UIButton *homebtn;


@property (weak, nonatomic) IBOutlet UIButton *maleyes;
@property (weak, nonatomic) IBOutlet UIButton *maleno;
@property (weak, nonatomic) IBOutlet UIButton *femaleyes;
@property (weak, nonatomic) IBOutlet UIButton *femalno;
@end
