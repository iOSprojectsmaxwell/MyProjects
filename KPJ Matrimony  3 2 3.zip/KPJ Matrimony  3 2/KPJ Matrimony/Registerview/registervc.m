//
//  registervc.m
//  KPJ Matrimony
//
//  Created by Admin on 10/07/2018.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "registervc.h"
#import "Common.h"
#import "JSON.h"
#import "homevc.h"
#import "SidemenuView.h"
#import "loginView.h"
#import "RzTextField.h"
#import "WSCalendarView.h"

@interface registervc ()<WSCalendarViewDelegate>
{
    NSDictionary *dic2;
     SidemenuView *objSideMenuView;
     NSMutableArray *eventArray;
    WSCalendarView *calendarView;
    WSCalendarView *calendarViewEvent;
    NSString *nameStr;
    NSString *numberStr;
    NSString *emailStr;
}

@end

@implementation registervc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    calendarView = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    //calendarView.dayColor=[UIColor blackColor];
    //calendarView.weekDayNameColor=[UIColor purpleColor];
    //calendarView.barDateColor=[UIColor purpleColor];
    //calendarView.todayBackgroundColor=[UIColor blackColor];
    calendarView.tappedDayBackgroundColor=[UIColor whiteColor];
    calendarView.calendarStyle = WSCalendarStyleDialog;
    calendarView.isShowEvent=false;
    [calendarView setupAppearance];
    [self.view addSubview:calendarView];
    calendarView.delegate=self;
    
    calendarViewEvent = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    calendarViewEvent.calendarStyle = WSCalendarStyleView;
    calendarViewEvent.isShowEvent=true;
    calendarViewEvent.tappedDayBackgroundColor=[UIColor blackColor];
    calendarViewEvent.frame = CGRectMake(35, 145, self.containerView.frame.size.width, self.containerView.frame.size.height);
    [calendarViewEvent setupAppearance];
    calendarViewEvent.delegate=self;
    [self.containerView addSubview:calendarViewEvent];
    
    
    eventArray=[[NSMutableArray alloc] init];
    NSDate *lastDate;
    NSDateComponents *dateComponent=[[NSDateComponents alloc] init];
    for (int i=0; i<10; i++) {
        
        if (!lastDate) {
            lastDate=[NSDate date];
        }
        else{
            [dateComponent setDay:1];
        }
        NSDate *datein = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponent toDate:lastDate options:0];
        lastDate=datein;
        [eventArray addObject:datein];
    }
    [calendarViewEvent reloadCalendar];
    // Do any additional setup after loading the view.
}

-(NSArray *)setupEventForDate{
    return eventArray;
}



-(IBAction)btn_date:(id)sender{
    
    //    _view_bluer.hidden =NO;
    [calendarView ActiveCalendar:sender];
    //return YES;
    //
    //
    //    calendarView.hidden =NO;
    //
    
}
-(void)didTapLabel:(WSLabel *)lblView withDate:(NSDate *)selectedDate




{
    
}

-(void)deactiveWSCalendarWithDate:(NSDate *)selectedDate{
    NSDateFormatter *monthFormatter=[[NSDateFormatter alloc] init];
    [monthFormatter setDateFormat:@"dd-MM-yyyy"];
    NSString *str=[monthFormatter stringFromDate:selectedDate];
    
    
    _dob.text =str;
    
    
   // _calender_feild.text =str;
    // self.Availability.text = str;
    
    //_view_bluer.hidden =YES;
}



- (IBAction)submitbtn:(id)sender {
    
    NSLog(@"username testing %@",_username.text);
    if (_username.text.length==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your name"];
        
    }
    
    else if (_mobilenum.text.length==0){
        
        [Common AlertShowWithErrorMsg:@"Please enter your mobile number"];
    }
    
    else if (_emailadress.text.length==0){
        
        [Common AlertShowWithErrorMsg:@"please enter your Email ID"];
        
    }
    else if (_dob.text.length==0){
    
        [Common AlertShowWithErrorMsg:@"please enter your date of birth"];
    }
    
    else if (_castetxt.text.length==0){
        [Common AlertShowWithErrorMsg:@"please enter your caste"];
    }
    
    else if (_cityTxt.text.length==0){
        [Common AlertShowWithErrorMsg:@"please enter your city"];
    }
    else{
        [self calling_webservices];
    }
    
    
    
}


-(IBAction)Login_button:(id)sender{
    loginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"loginView"];
    [self.navigationController pushViewController:controller animated:YES];
    
}

-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)calling_webservices
{
  

    
    NSString *apiURLStr;
    // data processing
    apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/register.php?name=%@&gender=male&phone=%@&email=%@&dob=%@&caste=%@&city=%@",_username.text,_mobilenum.text,_emailadress.text,_dob.text,_castetxt.text,_cityTxt.text];
    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
   
    
    
    dic2=[sampleURL JSONValue];
    
    NSLog(@"check response %@",dic2);
    
    [Common AlertShowWithErrorMsg:@"Your registration has been successfully completed!Our customer will contact you shortly for your login credentails"];
    loginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"loginView"];
    [self.navigationController pushViewController:controller animated:YES];
}
    
- (IBAction)Menu:(id)sender {
    
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
- (IBAction)genderbtn:(id)sender{
    
    _maleyes.hidden =NO;
    _maleno.hidden =YES;
    
    _femalno.hidden =NO;
    _femaleyes.hidden =YES;
}
- (IBAction)fenal:(id)sender{
    
    _maleyes.hidden =YES;
    _maleno.hidden =NO;
    
    _femalno.hidden =YES;
    _femaleyes.hidden =NO;
}
-(void)ShowPicker {
    
    CGFloat Height = self.view.frame.size.height;
    CGFloat Width = self.view.frame.size.width;
    
    UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, Width, 50)];
    numberToolbar.barStyle = UIBarStyleBlackTranslucent;
    numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleDone target:self action:@selector(PressDone)],
                            [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil]];
    [numberToolbar sizeToFit];
    // txtFiled.inputView = numberToolbar;
    
    UIDatePicker *picker = [[UIDatePicker alloc]initWithFrame:CGRectMake(0, Height-200, Width, 200)];
    picker.backgroundColor = [UIColor greenColor];
    
    [picker addSubview:numberToolbar];
    [self.view addSubview:picker];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
