//
//  SegmentVC.h
//  Gurukula
//
//  Created by user on 02/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SegmentVC : UIViewController

@end
