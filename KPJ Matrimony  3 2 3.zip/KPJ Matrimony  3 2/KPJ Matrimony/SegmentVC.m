//
//  SegmentVC.m
//  Gurukula
//
//  Created by user on 02/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "SegmentVC.h"
#import <CarbonKit/CarbonKit.h>
#import "FirstSegment.h"
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define IS_IPAD_PRO_1366 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1366.0)
#define IS_IPAD_PRO_1024 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1024.0)
#define IS_IPAD_PRO (MAX([[UIScreen mainScreen]bounds].size.width,[[UIScreen mainScreen] bounds].size.height) > 1024)
@interface SegmentVC ()<CarbonTabSwipeNavigationDelegate> {
    NSArray *items;
    CarbonTabSwipeNavigation *carbonTabSwipeNavigation;
    NSString *tittlename;
}

@end

@implementation SegmentVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    ///Users/user/Documents/Gurukula sanbox/Gurukula/Assets.xcassets/baccc.imageset/baccc.png
    UIImage* image3 = [UIImage imageNamed:@"gmailBack.png"];
    CGRect frameimg = CGRectMake(0, 0, 10, 10);
    
    
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    someButton.contentEdgeInsets =UIEdgeInsetsMake(25, 0, 0, 0);
   // someButton.contentEdgeInsets = UIEdgeInsets(top: 12, left: 16, bottom: 12, right: 16);
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
  
    

   
    
    
    
    tittlename = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"tittle"];
 self.navigationController.navigationBar.hidden =NO;
    items = @[
              @"AUDIO",
              @"VIDEO",
              @"STORY",
              @"COMICS",
              ];
    
    
    carbonTabSwipeNavigation = [[CarbonTabSwipeNavigation alloc] initWithItems:items delegate:self];
    [carbonTabSwipeNavigation insertIntoRootViewController:self];
    
    [self style];
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)style {
      self.navigationController.navigationBar.hidden =NO;
    self.navigationController.navigationBar.titleTextAttributes = @{
                                                                    NSFontAttributeName:[UIFont fontWithName:@"Arial" size:21],
                                                                    NSForegroundColorAttributeName: [UIColor blackColor]
                                                                    };
//    UIColor *color = [UIColor whiteColor];
//    self.navigationController.navigationBar.translucent = NO;
//    self.navigationController.navigationBar.tintColor = [UIColor grayColor];
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
//    self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
 
//    carbonTabSwipeNavigation.toolbar.translucent = NO;
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
                [carbonTabSwipeNavigation setTabExtraWidth:60];
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
                [carbonTabSwipeNavigation setTabExtraWidth:35];
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
                
                [carbonTabSwipeNavigation setTabExtraWidth:52];
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
                 case 2208:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
                [carbonTabSwipeNavigation setTabExtraWidth:45];
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
                [carbonTabSwipeNavigation setTabExtraWidth:34];
                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }
        [carbonTabSwipeNavigation setNormalColor:[[UIColor blackColor] colorWithAlphaComponent:0.6]
                                            font:[UIFont boldSystemFontOfSize:14]];
    }
    
  
    else{
          if (IS_IPAD_PRO_1366) {
        
        [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
        [carbonTabSwipeNavigation setTabExtraWidth:160];
        
        [carbonTabSwipeNavigation setNormalColor:[[UIColor blackColor] colorWithAlphaComponent:0.6]
                                            font:[UIFont boldSystemFontOfSize:30]];
              
          }
          else{
              
              [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1]];
              [carbonTabSwipeNavigation setTabExtraWidth:93];
              
              [carbonTabSwipeNavigation setNormalColor:[[UIColor blackColor] colorWithAlphaComponent:0.6]
                                                  font:[UIFont boldSystemFontOfSize:30]];
              
          }
    }
  
 
 
//    
//    // Custimize segmented control
   
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - CarbonTabSwipeNavigation Delegate
// required
- (nonnull UIViewController *)carbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbontTabSwipeNavigation
                                 viewControllerAtIndex:(NSUInteger)index {
    
    
 
    switch (index) {
        case 0:
            [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"FirstSegment"];
            
        case 1:
            [[NSUserDefaults standardUserDefaults] setObject:@"2" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"FirstSegment"];
        case 2:
            [[NSUserDefaults standardUserDefaults] setObject:@"3" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"Details"];
        default:
            return [self.storyboard instantiateViewControllerWithIdentifier:@"ComicsVC"];
    }
   
}

// optional
- (void)carbonTabSwipeNavigation:(CarbonTabSwipeNavigation *)carbonTabSwipeNavigation willMoveAtIndex:(NSUInteger)index {
 
    switch (index) {
            
            
        case 0:
            self.title = tittlename;
            break;
        case 1:
            self.title = tittlename;
            break;
        case 2:
            self.title = tittlename;
            break;
        default:
            self.title = tittlename;
            break;
    }
}

- (void)carbonTabSwipeNavigation:(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation
                  didMoveAtIndex:(NSUInteger)index {
    NSLog(@"Did move at index: %ld", index+1);
    
    if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
      [carbonTabSwipeNavigation setSelectedColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1] font:[UIFont boldSystemFontOfSize:30]];
    }else{
       [carbonTabSwipeNavigation setSelectedColor:[UIColor colorWithRed:107/255.0 green:0/255.0 blue:31/255.0 alpha:1] font:[UIFont boldSystemFontOfSize:14]];
    }
    
    
}

- (UIBarPosition)barPositionForCarbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation {
    return UIBarPositionTop; // default UIBarPositionTop
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
