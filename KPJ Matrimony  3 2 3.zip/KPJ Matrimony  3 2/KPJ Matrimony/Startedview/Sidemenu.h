//
//  Sidemenu.h
//  Pregnancyapp
//
//  Created by Admin on 01/12/2017.
//  Copyright © 2017 Amol. All rights reserved.
//

#import <UIKit/UIKit.h>



#define WIDTH_SIDEMENU 280
#define HEIGHT_SIDEMENU  700
@interface Sidemenu : UIViewController
{
    Sidemenu *objesidemenuView;
    
}
@end
