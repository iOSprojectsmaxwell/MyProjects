//
//  Sidemenu.m
//  Pregnancyapp
//
//  Created by Admin on 01/12/2017.
//  Copyright © 2017 Amol. All rights reserved.
//

#import "Sidemenu.h"
#import "loginView.h"
#import "KicksListView.h"
#import "WeeklyTraker.h"

@interface Sidemenu ()
@property(nonatomic,weak)IBOutlet UIImageView *image;
@end

@implementation Sidemenu

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _image.layer.cornerRadius = self.image.frame.size.width / 2;
    _image.clipsToBounds = YES;

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)signout:(id)sender {
    
    
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"name"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSUserDefaults standardUserDefaults] setObject:@"null" forKey:@"user_id"];
    [[NSUserDefaults standardUserDefaults] synchronize];
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"emil_id"];
    [[NSUserDefaults standardUserDefaults] synchronize];
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    loginView *myVC = (loginView *)[storyboard instantiateViewControllerWithIdentifier:@"loginView"];
    [self presentViewController:myVC animated:YES completion:nil];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"pregnanyapp" message:@"you have successfully logout."delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
}
- (IBAction)Kickes_List:(id)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    KicksListView *myVC = (KicksListView *)[storyboard instantiateViewControllerWithIdentifier:@"KicksListView"];
    [self presentViewController:myVC animated:YES completion:nil];
   
}

- (IBAction)Home_button:(id)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    WeeklyTraker *myVC = (WeeklyTraker *)[storyboard instantiateViewControllerWithIdentifier:@"WeeklyTraker"];
    [self presentViewController:myVC animated:YES completion:nil];
    
    
}

@end
