//
//  SidemenuView.m
//  AllParkTickets
//
//  Created by Admin on 7/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "SidemenuView.h"
#import "contactusvc.h"
#import "homevc.h"
#import "loginView.h"
#import "registervc.h"
#import "aboutusvc.h"
#import "Common.h"






@interface SidemenuView ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *Scrowl;

@end

@implementation SidemenuView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



-(IBAction)home_button:(id)sender{
    
    homevc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"homevc"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)contact_button:(id)sender{
    
    contactusvc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"contactusvc"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)register_button:(id)sender{
    
    registervc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"registervc"];
    
    [self.navigationController pushViewController:controller animated:YES];
}



-(void) viewDidLayoutSubviews
{
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        _Scrowl.contentSize = CGSizeMake(_Scrowl.frame.size.width, 800);
    } else {
        _Scrowl.contentSize = CGSizeMake(_Scrowl.frame.size.width, 600);
    }
    ;
}

-(IBAction)aboutus_button:(id)sender{
    
    aboutusvc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"aboutusvc"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)logout:(id)sender {
    NSLog(@"logout");
    
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"Login"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"Logout"
                                                                  message:@"Are You Sure?"
                                                           preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes Please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    /** What we write here???????? **/
                                    loginView *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"loginView"];
                                    [self.navigationController pushViewController:controller animated:YES];
                                    
                                    // call method whatever u need
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
