//
//  aboutusvc.h
//  KPJ Matrimony
//
//  Created by user on 30/07/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface aboutusvc : UIViewController

@end
