//
//  aboutusvc.m
//  KPJ Matrimony
//
//  Created by user on 30/07/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "aboutusvc.h"
#import "SidemenuView.h"

@interface aboutusvc ()
{
    
    
    SidemenuView *objSideMenuView;
}

@end

@implementation aboutusvc

- (void)viewDidLoad {
    [super viewDidLoad];
}
    - (IBAction)Menu:(id)sender {
        
        
        NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
        
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
        if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
            if ([UIScreen mainScreen].bounds.size.height == 1366) {
                objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
            }
        } else {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
        [self addChildViewController:objSideMenuView];
        
        [objSideMenuView didMoveToParentViewController:self];
        
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [button1 addTarget:self
                    action:@selector(aMethod:)
          forControlEvents:UIControlEventTouchUpInside];
        [button1 setTitle:@"X" forState:UIControlStateNormal];
        button1.frame = CGRectMake(211, -16, 55, 55);
        [objSideMenuView.view addSubview:button1];
        [self.view addSubview:objSideMenuView.view];
        
    }
    - (IBAction)aMethod:(id)sender
    {
        
        [objSideMenuView removeFromParentViewController];
        [objSideMenuView.view removeFromSuperview];
        
        
    }
    // Do any additional setup after loading the view.


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
