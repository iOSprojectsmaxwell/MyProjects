//
//  contactusvc.h
//  KPJ Matrimony
//
//  Created by Admin on 21/07/2018.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface contactusvc : UIViewController
@property(weak,nonatomic) IBOutlet UITextField *namefield;
@property(weak,nonatomic) IBOutlet UITextField *emailfield;
@property(weak,nonatomic) IBOutlet UITextField *mobilenofield;
@property(weak,nonatomic) IBOutlet UITextView *commenttext;
@property(weak,nonatomic) IBOutlet UIButton *submitbtn;

@end
