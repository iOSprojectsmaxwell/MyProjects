//
//  contactusvc.m
//  KPJ Matrimony
//
//  Created by Admin on 21/07/2018.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "contactusvc.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "SidemenuView.h"
#import "homevc.h"
#import "Common.h"


@interface contactusvc ()<UIScrollViewDelegate,UITextViewDelegate>
{
    NSDictionary *dict;
    NSString *response;
    MBProgressHUD *HUD;
    SidemenuView *objSideMenuView;
    NSString *nameStr;
    NSString *numberStr;
    NSString *emailStr;
}
@property (weak, nonatomic) IBOutlet UIScrollView *ScrowlView;
@end

@implementation contactusvc

- (void)viewDidLoad {
    [super viewDidLoad];
  
    nameStr = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"user_name"];
    numberStr = [[NSUserDefaults standardUserDefaults]
                 stringForKey:@"user_primary_mobile_no"];
    emailStr = [[NSUserDefaults standardUserDefaults]
                stringForKey:@"user_email"];
    _namefield.text =nameStr;
   _emailfield.text =emailStr;
    _mobilenofield.text =numberStr;
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    _commenttext.text = @"Comment";
    _commenttext.textColor = [UIColor lightGrayColor];
    _commenttext.delegate = self;
    // Do any additional setup after loading the view.
}
-(void) viewDidLayoutSubviews
{
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        _ScrowlView.contentSize = CGSizeMake(_ScrowlView.frame.size.width, 1100);
    } else {
        _ScrowlView.contentSize = CGSizeMake(_ScrowlView.frame.size.width, 1300);
    }
    ;
    
}


-(IBAction)submitbtn:(id)sender
{
    if (_namefield.text.length==0) {
        [Common AlertShowWithErrorMsg:@"Please Enter Your Name"];
      
    }
    
    else if (_emailfield.text.length==0){
        [Common AlertShowWithErrorMsg:@"Please Enter Your Emailid"];
    }
    
    else if (_mobilenofield.text.length==0){
        [Common AlertShowWithErrorMsg:@"Please Enter Your MobileNumber"];
    }
    
    else if (_commenttext.text.length==0){
        [Common AlertShowWithErrorMsg:@"Please Give your valueble Comment"];
    }
    
    
    else{
        [HUD show:YES];
        
        
        NSString *trimmedString =   [_commenttext.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
        
        // send a block to the queue - Not in Main thread
        dispatch_async(queue, ^{
            // data processing
            
            NSString *apiURLStr =[NSString stringWithFormat:@"http://gnaritusglobal.com/clients/rdatv.co.uk/api/feedback.php?name=%@&email=%@&phone=%@&comment=%@",_namefield.text,_emailfield.text,_mobilenofield.text,trimmedString];
            
            
            NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                dict=[sampleURL JSONValue];
                response = [dict valueForKey:@"response"];
                
                [Common AlertShowWithErrorMsg:@"Thank You for Giving FeedBack"];
                
                _namefield.text =@"";
                _emailfield.text =@"";
                _mobilenofield.text =@"";
                _commenttext.textColor = [UIColor lightGrayColor];
                _commenttext.text = @"Comment";
                [_commenttext resignFirstResponder];
                [HUD hide:YES];
            });
        });
    }
}
- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    _commenttext.text = @"";
    _commenttext.textColor = [UIColor blackColor];
    return YES;
}

-(void) textViewDidChange:(UITextView *)textView
{
    
    if(_commenttext.text.length == 0){
        _commenttext.textColor = [UIColor lightGrayColor];
        _commenttext.text = @"Comment";
        [_commenttext resignFirstResponder];
    }
}

-(void) textViewShouldEndEditing:(UITextView *)textView
{
    
    if(_commenttext.text.length == 0){
        _commenttext.textColor = [UIColor lightGrayColor];
        _commenttext.text = @"Comment";
        [_commenttext resignFirstResponder];
    }
}

- (IBAction)Menu:(id)sender {
    
    
    NSString *deviceModel = (NSString*)[UIDevice currentDevice].model;
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuView *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuView"];
    if ([[deviceModel substringWithRange:NSMakeRange(0, 4)] isEqualToString:@"iPad"]) {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        if ([UIScreen mainScreen].bounds.size.height == 1366) {
            objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
        }
    } else {
        objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+20, WIDTH_SIDEMENU, HEIGHT_SIDEMENU);
    }
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
