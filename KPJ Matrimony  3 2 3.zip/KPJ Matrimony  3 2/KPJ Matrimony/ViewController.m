//
//  ViewController.m
//  LadiesSpecial
//
//  Created by user on 21/08/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ViewController.h"
#import <CarbonKit/CarbonKit.h>
#import "WebManager.h"
#import "MBProgressHUD.h"
#import "Common.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "JSON.h"
#import "FirstSegment.h"

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define IS_IPAD_PRO_1366 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1366.0)
#define IS_IPAD_PRO_1024 (IS_IPAD && MAX(SCREEN_WIDTH,SCREEN_HEIGHT) == 1024.0)
#define IS_IPAD_PRO (MAX([[UIScreen mainScreen]bounds].size.width,[[UIScreen mainScreen] bounds].size.height) > 1024)
@interface ViewController ()<CarbonTabSwipeNavigationDelegate,MBProgressHUDDelegate> {
    NSArray *items;
    CarbonTabSwipeNavigation *carbonTabSwipeNavigation;
    NSString *tittlename;
    

        MBProgressHUD *HUD;
        NSDictionary *dict2;
        NSArray *response;
        NSString *User_name;
        NSString *dept_name;
        NSString *company_name;
        NSString *emp_no;
        NSString *designation;
        NSString *userid;
        
   
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    UIImage* image3 = [UIImage imageNamed:@"backk"];
    CGRect frameimg = CGRectMake(0, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
    
    
    
    
    
    
    
    tittlename = [[NSUserDefaults standardUserDefaults]
                  stringForKey:@"tittle"];
    self.navigationController.navigationBar.hidden =NO;
    items = @[
              @"Home",
              @"About us",
              ];
    
    
    carbonTabSwipeNavigation = [[CarbonTabSwipeNavigation alloc] initWithItems:items delegate:self];
    [carbonTabSwipeNavigation insertIntoRootViewController:self];
    
    [self style];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)style {
    self.navigationController.navigationBar.hidden =NO;
    self.navigationController.navigationBar.titleTextAttributes = @{
                                                                    NSFontAttributeName:[UIFont fontWithName:@"Arial" size:21],
                                                                    NSForegroundColorAttributeName: [UIColor blackColor]
                                                                    };
    //    UIColor *color = [UIColor whiteColor];
    //    self.navigationController.navigationBar.translucent = NO;
    //    self.navigationController.navigationBar.tintColor = [UIColor grayColor];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:(215/255.0) green:(45/255.0) blue:(141/255.0) alpha:1];
    //    self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
    
    //    carbonTabSwipeNavigation.toolbar.translucent = NO;
    
    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {
        
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
                
            case 1136:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
                [carbonTabSwipeNavigation setTabExtraWidth:5];
                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
                [carbonTabSwipeNavigation setTabExtraWidth:30];
                printf("iPhone 6/6S/7/8");
                
                break;
            case 1920:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
                
                [carbonTabSwipeNavigation setTabExtraWidth:23];
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2208:
                
                [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
                [carbonTabSwipeNavigation setTabExtraWidth:23];
                printf("iPhone 6+/6S+/7+/8+");
                
                break;
            case 2436
                
                
                :   [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
                [carbonTabSwipeNavigation setTabExtraWidth:86];
                
                [carbonTabSwipeNavigation setNormalColor:[[UIColor whiteColor] colorWithAlphaComponent:0.6]
                                                    font:[UIFont boldSystemFontOfSize:30]];
                
             
                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }
        [carbonTabSwipeNavigation setNormalColor:[[UIColor whiteColor] colorWithAlphaComponent:0.6]
                                            font:[UIFont boldSystemFontOfSize:14]];
    }
    
    
    else{
        if (IS_IPAD_PRO_1366) {
            
            [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
            [carbonTabSwipeNavigation setTabExtraWidth:86];
            
            [carbonTabSwipeNavigation setNormalColor:[[UIColor whiteColor] colorWithAlphaComponent:0.6]
                                                font:[UIFont boldSystemFontOfSize:30]];
            
        }
        else{
            
            [carbonTabSwipeNavigation setIndicatorColor:[UIColor whiteColor]];
            [carbonTabSwipeNavigation setTabExtraWidth:86];
            
            [carbonTabSwipeNavigation setNormalColor:[[UIColor whiteColor] colorWithAlphaComponent:0.6]
                                                font:[UIFont boldSystemFontOfSize:20]];
            
        }
    }
    
    
    
    //
    //    // Custimize segmented control
    
    
}


// required
- (nonnull UIViewController *)carbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbontTabSwipeNavigation
                                 viewControllerAtIndex:(NSUInteger)index {
    
    
    
    switch (index) {
        case 0:
            [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"FirstSegment"];
            
        case 1:
            [[NSUserDefaults standardUserDefaults] setObject:@"2" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"FirstSegment"];
        case 2:
            [[NSUserDefaults standardUserDefaults] setObject:@"3" forKey:@"cato"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return [self.storyboard instantiateViewControllerWithIdentifier:@"contactus"];
        default:
            return [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
    }
    
}

// optional
- (void)carbonTabSwipeNavigation:(CarbonTabSwipeNavigation *)carbonTabSwipeNavigation willMoveAtIndex:(NSUInteger)index {
    
    switch (index) {
            
            
        case 0:
            self.title = tittlename;
            break;
        case 1:
            self.title = tittlename;
            break;
        case 2:
            self.title = tittlename;
            break;
        default:
            self.title = tittlename;
            break;
    }
}

- (void)carbonTabSwipeNavigation:(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation
                  didMoveAtIndex:(NSUInteger)index {
    NSLog(@"Did move at index: %ld", index+1);
    
    if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
        [carbonTabSwipeNavigation setSelectedColor:[UIColor whiteColor] font:[UIFont boldSystemFontOfSize:30]];
    }else{
        [carbonTabSwipeNavigation setSelectedColor:[UIColor whiteColor]];
    }
    
    
}

- (UIBarPosition)barPositionForCarbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation {
    return UIBarPositionTop; // default UIBarPositionTop
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
