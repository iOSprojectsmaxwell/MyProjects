//
//  ViewPhoneVC.h
//  KPJ Matrimony
//
//  Created by user on 29/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewPhoneVC : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic,strong)NSString *SelectedProfileID;

@property (weak, nonatomic) IBOutlet UITableView *tablview;



@end

NS_ASSUME_NONNULL_END
