//
//  ViewPhoneVC.m
//  KPJ Matrimony
//
//  Created by user on 29/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ViewPhoneVC.h"
#import "Json.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Common.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "HomeCell.h"
@interface ViewPhoneVC ()<UITextFieldDelegate,MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
 

    
    NSArray *profile_contact_details;
    
     NSArray *profile_details;
    
    NSArray *profile_id;
    
    NSArray *name;
    
    NSArray *age;
    NSString * user_id;
    NSArray *primary_mobile;
    NSArray *star;
     NSArray *gothram;
    NSArray *rasi;
     NSArray *image;
    
//profile_contact_details: {
//payment: "paid",
//profile_details: [
//    {
//        id: "46",
//    profile_id: "180643",
//    name: "S.NAGARAJAN (SREEKUTTAN)",
//    age: 27,
//    primary_mobile: "9994670992",
//    secondary_mobile: "N / A",
//    height: "165 Cms",
//    star: "Moolam / Moola",
//    rasi: "Dhanus",
//    lagnam: "Makara",
//    gothram: "Siva gothram",
//    district: "KANIYAKUMARI",
//    caste_name: "N / A",
//    subcaste_name: null,
//    occupation: "Private Employment Office",
//    image: "http://www.kpjmatrimony.com/images/male.png",
//    }
//                  ],
//}

    
    
    
}
@property(nonatomic,strong)IBOutlet MyImageView *imagaeview;
@property(nonatomic,strong)IBOutlet UILabel *lblname;
@property(nonatomic,strong)IBOutlet MyImageView *image1;

@end

@implementation ViewPhoneVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    
  //  user_id = [[NSUserDefaults standardUserDefaults]
              // stringForKey:@"User_id"];
    
   [self ViewPhoneNumber];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)ViewPhoneNumber
{
    [HUD show:YES];
    //user_name
    //pswd

    // [HUD hide:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    //        http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=132&view_profile_id=180643
    //
    // data processing
    NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/profile_contact_details.php?login_user_id=%@&view_profile_id=%@",user_id,_SelectedProfileID];


    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];

    dict2=[sampleURL JSONValue];

    // Interaction with User Interface - Main thread
    dispatch_async(dispatch_get_main_queue(), ^{

        NSLog(@"dicr]t %@",dict2);

    
        
        profile_contact_details =[dict2 valueForKey:@"profile_contact_details"];
        profile_details =[profile_contact_details valueForKey:@"profile_details"];;
        profile_id =[profile_details valueForKey:@"profile_id"];;
        name =[profile_details valueForKey:@"name"];
 age =[profile_details valueForKey:@"age"];
 primary_mobile =[profile_details valueForKey:@"primary_mobile"];
         star =[profile_details valueForKey:@"star"];
        gothram =[profile_details valueForKey:@"gothram"];
        rasi =[profile_details valueForKey:@"rasi"];
        image =[profile_details valueForKey:@"image"];
        
        [self.tablview reloadData];

        [HUD hide:YES];
    });
};

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}


//MARK:- Table View Delegated & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return profile_id.count;    //count number of row from counting array hear cataGorry is An Array
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    //    cell.backgroundColor = [UIColor colorWithRed:246/255.0f green:245/255.0f blue:245/255.0f alpha:1.0];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"HomeCell";
    
    
    HomeCell  *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[HomeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    _tablview.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _image1=(MyImageView*)[cell viewWithTag:1];
    
    
   
    
    
    //   cell.btnViewProfile.layer.cornerRadius = 10; // this value vary as per your desire
    //    cell.btnViewProfile.clipsToBounds = YES;
  
    [_image1 addImageFrom:[[image objectAtIndex:indexPath.row] stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    // cell.listofimgs.image = [UIImage imageNamed:listfimgs[indexPath.row]];
    cell.ProfileIDLbl.text =[profile_id objectAtIndex:indexPath.row];
    cell.contactnamelbl.text =[name objectAtIndex:indexPath.row];
    
    cell.agecontactlbl.text =[NSString stringWithFormat:@"%@",[age objectAtIndex:indexPath.row]];
    cell.Gothramlbl.text =[NSString stringWithFormat:@"%@",[gothram objectAtIndex:indexPath.row]];
    
    cell.Raasilbl.text =[rasi objectAtIndex:indexPath.row];
    cell.starLbl.text =[star objectAtIndex:indexPath.row];
    
    
    cell.ContactDetailslbl.text =[primary_mobile objectAtIndex:indexPath.row];
  
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 381;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
