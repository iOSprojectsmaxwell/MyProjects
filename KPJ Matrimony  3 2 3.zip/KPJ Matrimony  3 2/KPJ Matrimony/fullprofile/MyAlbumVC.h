//
//  MyAlbumVC.h
//  KPJ Matrimony
//
//  Created by user on 06/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyAlbumVC : UIViewController

@end

NS_ASSUME_NONNULL_END
