//
//  MyAlbumVC.m
//  KPJ Matrimony
//
//  Created by user on 06/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "MyAlbumVC.h"
#import "Json.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "Common.h"
#import "JSON.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "CustomCell.h"
#import "MyProfileDetailsVC.h"
@interface MyAlbumVC ()
<UITextFieldDelegate,MBProgressHUDDelegate,UICollectionViewDataSource,UICollectionViewDelegate>
{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *profile_details;
    NSString *user_email;
    NSString *user_name;
    NSArray *album_details;
     NSArray *profile_photo;
    NSString *user_id;
     CGFloat width;
    NSArray *profile_horoscope_details;
   
    NSString *horoscope_image;
    NSString *name;
    NSString *horo_Code;
    
 NSArray *album;
    
}
@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property(nonatomic,strong)IBOutlet MyImageView *imagaeview;
@property(nonatomic,strong)IBOutlet UILabel *lblname;
@property(nonatomic,strong)IBOutlet UIView *View1;
@end

@implementation MyAlbumVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIImage* image3 = [UIImage imageNamed:@"Backorg"];
    CGRect frameimg = CGRectMake(-10, 0, 20, 20);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(sendmail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem=mailbutton;
    
    
    user_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    
    [self ViewHoroscope];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    _View1.layer.borderColor =[UIColor lightGrayColor].CGColor;
    _View1.layer.borderWidth =2.0;
    _View1.layer.cornerRadius =8.0;
    // Do any additional setup after loading the view.
}
- (IBAction)sendmail
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ViewHoroscope
{
    [HUD show:YES];
    //user_name
    //pswd
//    http://www.kpjmatrimony.com/api/myalbum.php?login_user_id=132
    // [HUD hide:YES];
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    //        http://www.kpjmatrimony.com/api/profile_horoscope_details.php?login_user_id=132&view_profile_id=180643
    //
    // data processing
    NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/myalbum.php?login_user_id=132"];
    
    
    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
    
    dict2=[sampleURL JSONValue];
    
    // Interaction with User Interface - Main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSLog(@"dicr]t %@",dict2);
     
        
        profile_horoscope_details =[dict2 valueForKey:@"album_details"];
        horo_Code  =[NSString stringWithFormat:@"%@",[profile_horoscope_details valueForKey:@"album_code"]];
        if ([horo_Code isEqualToString:@"0"]) {
            _collectionView.hidden =YES;
            _View1.hidden =NO;
        }
        else{
            _View1.hidden =NO;
            _collectionView.hidden =NO;
            album  =[[profile_horoscope_details valueForKey:@"album"]objectAtIndex:0];
          [_collectionView reloadData];
            
          //  [_imagaeview addImageFrom:[image stringByURLDecode] isRound:YES isActivityIndicator:YES];
            
        }
     
           profile_details =[profile_horoscope_details valueForKey:@"profile_photo"];;
        [_imagaeview addImageFrom:[profile_details stringByURLDecode] isRound:YES isActivityIndicator:YES];
        
     
        [HUD hide:YES];
    });
};


-(IBAction)ProfileDeatails:(id)sender{
    
    MyProfileDetailsVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyProfileDetailsVC"];
    controller.imagestr =profile_details;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}




- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath {

    CGFloat height = self.view.frame.size.height;

    if([[UIDevice currentDevice]userInterfaceIdiom]==UIUserInterfaceIdiomPhone) {

        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {

            case 1136:
                width  = self.view.frame.size.width+20;

                printf("iPhone 5 or 5S or 5C");
                break;
            case 1334:
                width  = self.view.frame.size.width+50;

                printf("iPhone 6/6S/7/8");

                break;
            case 1920:

                width  = self.view.frame.size.width+55;
                printf("iPhone 6+/6S+/7+/8+");

                break;
            case 2208:

                width  = self.view.frame.size.width+60;
                printf("iPhone 6+/6S+/7+/8+");

                break;
            case 2436:

                printf("iPhone X");
                break;
            default:
                printf("unknown");
        }

    }
    //width  = self.view.frame.size.width+60;
    // in case you you want the cell to be 40% of your controllers view
    return CGSizeMake(width * 0.4, height * 0.3);
}
#pragma mark - collectionView


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ReuseIdentifier = @"CustomMainCell";
    CustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ReuseIdentifier forIndexPath:indexPath];

    // _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[album objectAtIndex:indexPath.row];

    // NSLog(@"path %@",path);

    //[_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];

    dispatch_async(dispatch_get_global_queue(0,0), ^{
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:path]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            // WARNING: is the cell still using the same data by this point??
            cell.imageView.image = [UIImage imageWithData: data];
        });

    });


    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return album.count;
}


- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 2.0, 10, 2.0);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {

    MyProfileDetailsVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyProfileDetailsVC"];
    controller.imagestr =[album objectAtIndex:indexPath.row];;
    [self.navigationController pushViewController:controller animated:YES];


}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
