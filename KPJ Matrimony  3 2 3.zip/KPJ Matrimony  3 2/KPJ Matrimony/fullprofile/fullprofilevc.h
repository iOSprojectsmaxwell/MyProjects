//
//  fullprofilevc.h
//  KPJ Matrimony
//
//  Created by user on 20/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface fullprofilevc : UIViewController
@property(nonatomic,strong)NSString *SelectedProfileID;
@end
