//
//  MemberShipVC.h
//  KPJ Matrimony
//
//  Created by user on 11/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MemberShipVC : UIViewController
<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *scrowlView;
@property (weak, nonatomic) IBOutlet UIView *Gold_view;
@property (weak, nonatomic) IBOutlet UIView *Platinum_view;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;
@end

NS_ASSUME_NONNULL_END
