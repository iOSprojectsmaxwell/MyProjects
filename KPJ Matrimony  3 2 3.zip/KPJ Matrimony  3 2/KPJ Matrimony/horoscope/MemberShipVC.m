//
//  MemberShipVC.m
//  KPJ Matrimony
//
//  Created by user on 11/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "MemberShipVC.h"
#import "SWRevealViewController.h"
#import "Common.h"
@interface MemberShipVC ()

@end

@implementation MemberShipVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    
    
    //UIColor *color =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1];
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.navigationController.navigationBar.hidden =NO;
    _Gold_view.layer.shadowColor = [UIColor blackColor].CGColor;
    _Gold_view.layer.shadowOffset = CGSizeMake(0, 1);
    _Gold_view.layer.shadowOpacity = 10;
    _Gold_view.layer.shadowRadius = 30.0;
    _Gold_view.clipsToBounds = NO;
    _Gold_view.layer.cornerRadius = 8.0;
    
    _Platinum_view.layer.shadowColor = [UIColor blackColor].CGColor;
    _Platinum_view.layer.shadowOffset = CGSizeMake(0, 1);
    _Platinum_view.layer.shadowOpacity = 10;
    _Platinum_view.layer.shadowRadius = 30.0;
    _Platinum_view.clipsToBounds = NO;
    _Platinum_view.layer.cornerRadius = 8.0;
    // Do any additional setup after loading the view.
}
-(void) viewDidLayoutSubviews
{
    
    
    self.scrowlView.contentSize = CGSizeMake(self.scrowlView.frame.size.width,2000);
}

-(IBAction)gol_payment:(id)sender{
    
    [Common AlertShowWithErrorMsg:@"Please Setup in your apple account"];
}
-(IBAction)Platinum_payment:(id)sender{
    
    [Common AlertShowWithErrorMsg:@"Please Setup in your apple account"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
