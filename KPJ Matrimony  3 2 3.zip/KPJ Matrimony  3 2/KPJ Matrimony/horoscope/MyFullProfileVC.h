//
//  MyFullProfileVC.h
//  KPJ Matrimony
//
//  Created by user on 04/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyFullProfileVC : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)IBOutlet UIScrollView *scrowlView;

@end

NS_ASSUME_NONNULL_END
