//
//  SearchVCNew.h
//  KPJ Matrimony
//
//  Created by user on 10/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchVCNew : UIViewController
@property(strong,nonatomic)IBOutlet UIImageView *images;
@property(strong,nonatomic)IBOutlet UILabel *namelbl;
@property(strong,nonatomic)IBOutlet UILabel *idlbl;
@property(strong,nonatomic)IBOutlet UILabel *castelbl;
@property(strong,nonatomic)IBOutlet UILabel *heightlbl;

@property (weak, nonatomic) IBOutlet UIView *SearchVC;
@property (weak, nonatomic) IBOutlet UIImageView *Searchimageview;
@property (weak, nonatomic) IBOutlet UITextField *LookingFor;
@property (weak, nonatomic) IBOutlet UITextField *AgeFeild;
@property (weak, nonatomic) IBOutlet UITextField *AgeFeild2;
@property (weak, nonatomic) IBOutlet UITextField *EductionFeild;
@property (weak, nonatomic) IBOutlet UITextField *StarFeild;
@property (weak, nonatomic) IBOutlet UITextField *RegisterFeild;


@property (weak, nonatomic) IBOutlet UIView *BlurView;

@property (weak, nonatomic) IBOutlet UIView *searchImage;
@property (weak, nonatomic) IBOutlet UIButton *searchbtn;


@property (weak, nonatomic) IBOutlet UIView *SView_name;
@property (weak, nonatomic) IBOutlet UITextField *SF_name;
@property (weak, nonatomic) IBOutlet UIView *SA_from;
@property (weak, nonatomic) IBOutlet UITextField *SA_fromtext;
@property (weak, nonatomic) IBOutlet UIView *SA_to;
@property (weak, nonatomic) IBOutlet UITextField *AS_totext;
@property (weak, nonatomic) IBOutlet UIView *starView;
@property (weak, nonatomic) IBOutlet UITextField *starFeild;
@property (weak, nonatomic) IBOutlet UIView *Education_view;
@property (weak, nonatomic) IBOutlet UITextField *education_txt;

@property (weak, nonatomic) IBOutlet UIView *cast_view;
@property (weak, nonatomic) IBOutlet UITextField *Cast_Txt;

@property (weak, nonatomic) IBOutlet UIButton *Submit_button;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;

NS_ASSUME_NONNULL_END

@end
