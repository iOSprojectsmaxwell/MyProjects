//
//  SearchVCNew.m
//  KPJ Matrimony
//
//  Created by user on 10/10/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "SearchVCNew.h"
#import "JSON.h"
#import "registervc.h"
#import "contactusvc.h"
#import "loginView.h"
#import "Moreinfovc.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "MBProgressHUD.h"
#import "CollectionCell.h"
#import <QuartzCore/QuartzCore.h>
#import "CLPopListView.h"
#import "HomeCell.h"
#import <QuartzCore/CALayer.h>
#import "Common.h"
#import "SWRevealViewController.h"
#import "MyHoroscopeVC.h"
#import "ViewPhoneVC.h"
@interface SearchVCNew ()<MBProgressHUDDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSArray *imagesArry;
    NSString *namelbl;
    NSString *castelbl;
    NSString *heightlabl;
    NSString *idlbl;
    MBProgressHUD *HUD;
    NSArray *profiles;
    NSDictionary *dict2;
    NSArray *ProfileId;
    NSArray *name;
    NSString *durationStr1;
    NSArray *age;
    NSArray *height;
    NSArray *star;
    NSArray *district;
    NSString *SelectedProfileID;
    NSArray *caste_name;
    NSArray *subcaste_name;
    NSArray *occupation;
    NSArray *image;
    NSArray *Lookingfor;
    NSMutableArray *agestart;
    NSMutableArray *ageend;
    int i;
    NSString *apiURLStr;
    NSArray *search_list;
    NSArray *stardl;
    NSArray *stardetails;
    NSArray *education;
    NSArray *educationdl;
    NSArray *education_id;
    NSDictionary *dict1;
    NSArray *cast;
    NSArray *cast_id;
    NSArray *caste_name1;
    
    
    NSArray *search_results;
    NSString *Edu_id;
    NSString *cat_id;
    NSString *User_id;
    
    
    
    
    
    
    
    
}
@property(nonatomic,strong)IBOutlet MyImageView *image1;
@property(nonatomic,strong)IBOutlet UITableView *Tablview;

@end

@implementation SearchVCNew

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    User_id = [[NSUserDefaults standardUserDefaults]
               stringForKey:@"User_id"];
    UIImageView* imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Tittle"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    UIView* titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 130, 44)];
    imageView.frame = titleView.bounds;
    [titleView addSubview:imageView];
    
    self.navigationItem.titleView = titleView;
    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    bar.barTintColor = [UIColor colorWithRed:31/255.0f
                                       green:115/255.0f
                                        blue:170/255.0f
                                       alpha:1.0f];
    
    [self.navigationController.navigationBar setTitleTextAttributes:  @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    
    
    //UIColor *color =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1];
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        self.sidebarButton.tintColor =[UIColor whiteColor];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.navigationController.navigationBar.hidden =NO;
    [self GetCategories];
    
    //UIColor *color =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1];
    
    Lookingfor =[[NSArray alloc]initWithObjects:@"Bride",@"Groom", nil];
    agestart =[[NSMutableArray alloc]init];
    self.SView_name.layer.cornerRadius = 6.0 ;
    self.SView_name.clipsToBounds = true;
    self.SView_name.layer.borderWidth = 1.0f;
    self.SView_name.layer.borderColor =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    self.SA_from.layer.cornerRadius = 6.0 ;
    self.SA_from.clipsToBounds = true;
    self.SA_from.layer.borderWidth = 1.0f;
    self.SA_from.layer.borderColor =[UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.SA_to.layer.cornerRadius = 6.0 ;
    self.SA_to.clipsToBounds = true;
    self.SA_to.layer.borderWidth = 1.0f;
    self.SA_to.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    
    self.starView.layer.cornerRadius = 6.0 ;
    self.starView.clipsToBounds = true;
    self.starView.layer.borderWidth = 1.0f;
    self.starView.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    
    self.Education_view.layer.cornerRadius = 6.0 ;
    self.Education_view.clipsToBounds = true;
    self.Education_view.layer.borderWidth = 1.0f;
    self.Education_view.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.cast_view.layer.cornerRadius = 6.0 ;
    self.cast_view.clipsToBounds = true;
    self.cast_view.layer.borderWidth = 1.0f;
    self.cast_view.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    
    self.Submit_button.layer.cornerRadius = 4.0 ;
    self.Submit_button.clipsToBounds = true;
    self.Submit_button.layer.borderWidth = 1.0f;
    self.Submit_button.layer.borderColor = [UIColor colorWithRed:(12/255.0) green:(95/255.0) blue:(159/255.0) alpha:1].CGColor;
    //    [_Searchimageview.layer setMasksToBounds:NO];
    //    [_Searchimageview.layer setShadowColor:[[UIColor grayColor] CGColor]];
    //    [_Searchimageview.layer setShadowOpacity:0.6f];
    //    [_Searchimageview.layer setShadowRadius:20.0f];
    //    [_Searchimageview.layer setShadowOffset: CGSizeMake(10.0f, 10.0f)];
    //
    
    _Searchimageview.layer.shadowColor = [UIColor blackColor].CGColor;
    _Searchimageview.layer.shadowOffset = CGSizeMake(0, 1);
    _Searchimageview.layer.shadowOpacity = 10;
    _Searchimageview.layer.shadowRadius = 30.0;
    _Searchimageview.clipsToBounds = NO;
    
    for( int i = 21; i < 50; ++i )
    {
        [agestart addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:i]]];
        [ageend addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:i]]];
    }
    
    _BlurView.hidden=NO;
    _searchbtn.layer.cornerRadius = 7; // this value vary as per your desire
    _searchbtn.clipsToBounds = YES;
    [_searchImage.layer setMasksToBounds:NO];
    [_searchImage.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [_searchImage.layer setShadowOpacity:0.6f];
    [_searchImage.layer setShadowRadius:15.0f];
    [_searchImage.layer setCornerRadius:24.0f];
    [_searchImage.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    // Do any additional setup after loading the view.
}
-(void)GetCategories

{
  //  [HUD show:YES];
    
    
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/search_category.php"];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict1=[sampleURL JSONValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            
            search_list =[dict1 valueForKey:@"search_list"];
            stardl =[search_list valueForKey:@"star"];
            stardetails =[stardl valueForKey:@"star"];
            education =[search_list valueForKey:@"education"];
            educationdl =[education valueForKey:@"education"];
            education_id =[education valueForKey:@"id"];
            cast =[search_list valueForKey:@"caste"];
            cast_id =[cast valueForKey:@"id"];
            caste_name1 =[cast valueForKey:@"caste_name"];
         
            
          [HUD hide:YES];
            
        });
    });
    
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}


//MARK:- Table View Delegated & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return ProfileId.count;    //count number of row from counting array hear cataGorry is An Array
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    //    cell.backgroundColor = [UIColor colorWithRed:246/255.0f green:245/255.0f blue:245/255.0f alpha:1.0];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"HomeCell";
    
    
    HomeCell  *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[HomeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    _Tablview.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _image1=(MyImageView*)[cell viewWithTag:1];
    
    
    
    [cell.btnSendRequest addTarget:self action:@selector(btnSendRequest:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell.btnViewPhone addTarget:self action:@selector(btnViewPhone:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    [cell.btnViewHoroscop addTarget:self action:@selector(btnViewHoroscop:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btnShortList.tag = indexPath.row;
    NSString *path=[image objectAtIndex:indexPath.row];
    [cell.btnShortList addTarget:self action:@selector(BtnShortListed:) forControlEvents:UIControlEventTouchUpInside];
    // NSLog(@"path %@",path);
    
    //   cell.btnViewProfile.layer.cornerRadius = 10; // this value vary as per your desire
    //    cell.btnViewProfile.clipsToBounds = YES;
    cell.namelbl.text =[name objectAtIndex:indexPath.row];
    [_image1 addImageFrom:[path stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    // cell.listofimgs.image = [UIImage imageNamed:listfimgs[indexPath.row]];
    cell.profileidlbl.text =[ProfileId objectAtIndex:indexPath.row];
    cell.agelbl.text =[NSString stringWithFormat:@"%@",[age objectAtIndex:indexPath.row]];
    cell.heightlbl.text =[NSString stringWithFormat:@"%@",[height objectAtIndex:indexPath.row]];
    
    cell.castlbl.text =[caste_name objectAtIndex:indexPath.row];
    cell.starbl.text =[star objectAtIndex:indexPath.row];
    
    
    cell.districtlbl.text =[district objectAtIndex:indexPath.row];
    cell.subcastlblbl.text =[subcaste_name objectAtIndex:indexPath.row];
    cell.occupationlbl.text =[occupation objectAtIndex:indexPath.row];
    
    return cell;
    
}

-(IBAction)search_Button:(id)sender{
    _BlurView.hidden =NO;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    
    return 250;
    
}


-(void)btnViewPhone:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
    //    _AlertLbl.text =@"Do you want to shortlist this profile?";
    //    _AlertBlure.hidden =NO;
    
    // SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
    ViewPhoneVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhoneVC"];
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    controller.SelectedProfileID =SelectedProfileID;
    [self.navigationController pushViewController:controller animated:YES];
    
    
}

-(void)btnViewHoroscop:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
    //  _AlertLbl.text =@"Do you want to shortlist this profile?";
    // _AlertBlure.hidden =NO;
    MyHoroscopeVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MyHoroscopeVC"];
    
   
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    

    [self.navigationController pushViewController:controller animated:YES];
    
    
}
-(void)btnSendRequest:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.Tablview];
    
    NSIndexPath *indexPath = [self.Tablview indexPathForRowAtPoint:buttonPosition];
//    _AlertLbl.text =@"Do you want to shortlist this profile?";
//    _AlertBlure.hidden =NO;
//
//    _AlertVieww.hidden =YES;
//    _sentRequestView.hidden =NO;
    SelectedProfileID =[ProfileId objectAtIndex:indexPath.row];
    
}










-(void)SearchAPI
{
    NSString *typee;
  //  [HUD show:YES];
    
    
    if ([_SF_name.text isEqualToString:@"Groom"]) {
        typee =@"2";
    }
    else{
        typee =@"1";
    }
    
    
    NSString *trimmed = [_StarFeild.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/search_results.php?user_id=%@&type=%@&age_from=%@&age_to=%@&star=%@&education=%@&regid=%@",User_id,typee,_SA_fromtext.text,_AS_totext.text,trimmed,Edu_id,cat_id];
    
    //  http://www.kpjmatrimony.com/api/search_results.php?user_id=132&type=1&age_from=20&age_to=30&star=&education=&regid=
    
    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    
    // send a block to the queue - Not in Main thread
    dispatch_async(queue, ^{
        
        
        
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            dict2=[sampleURL JSONValue];
            profiles =[dict2 valueForKey:@"response"];
            search_results =[profiles valueForKey:@"search_results"];
            ProfileId =[search_results valueForKey:@"profile_id"];
            name =[search_results valueForKey:@"name"];
            age =[search_results valueForKey:@"age"];
            height =[search_results valueForKey:@"height"];
            caste_name =[search_results valueForKey:@"caste_name"];
            image =[search_results valueForKey:@"image"];
            
            //[self.Tablview reloadData];
            _BlurView.hidden =YES;
               [self.Tablview reloadData];
          [HUD hide:YES];
            
        });
    });
    
    
    
    
    
}

-(IBAction)submit_search:(id)sender{
    
    if (_SF_name.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please select your looking for"];
    }
    else if (_SA_fromtext.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Age"];
    }
    else if (_AS_totext.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Age"];
    }
    else if (_StarFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Star"];
    }
    else if (_education_txt.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Eduction"];
    }
    else if (_Cast_Txt.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please select Caste"];
    }
    else{
        [self SearchAPI] ;
    }
}

-(IBAction)lokkingfor:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Looking For" options:Lookingfor handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=100;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)Cast_Search:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Caste" options:caste_name1 handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=108;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Age:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Age" options:agestart handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=101;
    [lplv showInView:self.view.window animated:YES];
    
    
}
-(IBAction)Age1:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Age" options:agestart handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=102;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)star:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Star" options:stardetails handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=103;
    [lplv showInView:self.view.window animated:YES];
    
    
}

-(IBAction)education:(id)sender{
    
    
    
    CLPopListView *lplv = [[CLPopListView alloc] initWithTitle:@"Education" options:educationdl handler:^(NSInteger anIndex) {
    }];
    lplv.delegate = self;
    lplv.allowScroll = YES;
    lplv.selectedIndex = 0;
    //    lplv.backgroundColor =[UIColor grayColor];
    lplv.tag=104;
    [lplv showInView:self.view.window animated:YES];
    
    
}



- (void)leveyPopListView:(CLPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    if(popListView.tag==100)
    {
        //btnEventSize.titleLabel.text = [DurationArray objectAtIndex:anIndex];
        durationStr1 = [NSString stringWithFormat:@"%@",[Lookingfor objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _SF_name.text =durationStr1;
        
    }
    
    else if (popListView.tag==101)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[agestart objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _SA_fromtext.text =durationStr1;
        
        
    }
    else if (popListView.tag==102)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[agestart objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _AS_totext.text =durationStr1;
        
        
    }
    else if (popListView.tag==103)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[stardetails objectAtIndex:anIndex]];
        
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _StarFeild.text =durationStr1;
        
        
    }
    else if (popListView.tag==104)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[educationdl objectAtIndex:anIndex]];
        
        Edu_id =[NSString stringWithFormat:@"%@",[education_id objectAtIndex:anIndex]];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _education_txt.text =durationStr1;
        
        
    }
    else if (popListView.tag==108)
    {
        
        durationStr1 = [NSString stringWithFormat:@"%@",[caste_name1 objectAtIndex:anIndex]];
        
        cat_id =[NSString stringWithFormat:@"%@",[cast_id objectAtIndex:anIndex]];
        //  for_id =[NSString stringWithFormat:@"%@",[category_id objectAtIndex:anIndex]];
        
        // NSString *lower = [durationStr1 uppercaseString];
        
        _Cast_Txt.text =durationStr1;
        
        
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
