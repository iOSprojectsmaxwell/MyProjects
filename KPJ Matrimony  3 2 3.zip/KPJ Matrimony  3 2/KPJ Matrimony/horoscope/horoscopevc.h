//
//  horoscopevc.h
//  KPJ Matrimony
//
//  Created by user on 20/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface horoscopevc : UIViewController
@property(strong,nonatomic)IBOutlet UIView *baseview;


@end
