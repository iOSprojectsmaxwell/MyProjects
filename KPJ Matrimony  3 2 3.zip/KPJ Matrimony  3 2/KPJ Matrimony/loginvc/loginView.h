//
//  loginView.h
//  KPJ Matrimony
//
//  Created by user on 03/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface loginView : UIViewController
@property(nonatomic,strong)IBOutlet UITextField *emailIdfeild;
@property(nonatomic,strong)IBOutlet UITextField *passwordFeild;
@property(nonatomic,strong)IBOutlet UITextField *forgetPassword;
@property(nonatomic,strong)IBOutlet UIView *forgetPasswordView;
@end
