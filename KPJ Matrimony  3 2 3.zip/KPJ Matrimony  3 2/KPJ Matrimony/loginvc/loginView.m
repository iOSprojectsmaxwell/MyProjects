//
//  loginView.m
//  KPJ Matrimony
//
//  Created by user on 03/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "loginView.h"
#import "WebManager.h"
#import "Common.h"
#import "MBProgressHUD.h"
#import "JSON.h"
#import "homevc.h"
#import "registervc.h"
#import "Guestuser.h"
#import "ViewController.h"
#import "SegmentVC.h"


@interface loginView ()<UITextFieldDelegate,MBProgressHUDDelegate>

@end

@implementation loginView{
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    NSString *Login;
    NSString *user_email;
    NSString *user_name;
    NSString *user_primary_mobile_no;
    
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
      _forgetPasswordView.hidden =YES;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    
    self.navigationController.navigationBar.hidden =YES;

    // Do any additional setup after loading the view.
}

-(IBAction)loginBtn:(id)sender{
    
    if (_emailIdfeild.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your Email ID or User ID"];
    }
    
    else if (_passwordFeild.text.length ==0)
    {
        [Common AlertShowWithErrorMsg:@"Please enter your Password"];
    }
    
    else{
        
        [HUD show:YES];
        //user_name
        //pswd

        // [HUD hide:YES];
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
        
   NSString *trimmed = [_emailIdfeild.text stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSString *trimmed1 = [_passwordFeild.text stringByReplacingOccurrencesOfString:@"#" withString:@","];
        
            // data processing
            NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/login.php?user_name=%@&pswd=%@",trimmed,trimmed1];
            
            
            NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
            
            dict2=[sampleURL JSONValue];
            
            // Interaction with User Interface - Main thread
            dispatch_async(dispatch_get_main_queue(), ^{
           
                NSLog(@"dicr]t %@",dict2);
                
                NSArray *login =[dict2 valueForKey:@"login"];
               
                NSString *result =[login valueForKey:@"result"];
                NSString *user_email =[login valueForKey:@"user_email"];
                NSString *user_name=[login valueForKey:@"user_name"];
                  NSString *auto_increment_id=[login valueForKey:@"auto_increment_id"];
                
                NSString *user_primary_mobile_no=[login valueForKey:@"user_primary_mobile_no"];
                
               
                
                

                if ([result isEqualToString:@"failed"]){

                      [Common AlertShowWithErrorMsg:@"Incorrect User ID or Password"];
                     [HUD hide:YES];
                }
                else{
                    NSString *auto_increment_id =[login valueForKey:@"auto_increment_id"];
                    [[NSUserDefaults standardUserDefaults] setObject:@" " forKey:@"Notification"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [[NSUserDefaults standardUserDefaults] setObject:user_email forKey:@"user_email"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [[NSUserDefaults standardUserDefaults] setObject:user_name forKey:@"user_name"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [[NSUserDefaults standardUserDefaults] setObject:user_primary_mobile_no forKey:@"user_primary_mobile_no"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [[NSUserDefaults standardUserDefaults] setObject:auto_increment_id forKey:@"User_id"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    [Common AlertShowWithErrorMsg:@"You Have Successfully Logged In"];
                    homevc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"homevc"];
                    [self.navigationController pushViewController:controller animated:YES];
                     [HUD hide:YES];
             }
                 
            
            });
        };
        
        
        
        
        
        
        
        
        
        
        // [HUD hide:YES];
        
    }
    
    
-(IBAction)register_button:(id)sender{
    registervc *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"registervc"];
    [self.navigationController pushViewController:controller animated:YES];
    
}
-(IBAction)guest_button:(id)sender{
    Guestuser *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Guestuser"];
    [self.navigationController pushViewController:controller animated:YES];
    
}
- (void) threadStartAnimating {
    [HUD show:YES];
}
-(void) onSuccess:(NSDictionary *)dict{
    NSLog(@"%@",dict);
    
    
    
}

-(IBAction)forget_password:(id)sender{
     _forgetPasswordView.hidden =NO;
    
}

-(IBAction)cancel:(id)sender{
     _forgetPasswordView.hidden =YES;
    
}
-(IBAction)forgetpassward:(id)sender{
    if (_forgetPassword.text.length ==0) {
        [Common AlertShowWithErrorMsg:@"Please enter your email Address"];
    }
    else{
        
        [HUD show:YES];
        
        // [HUD hide:YES];
        dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
       
        
        // data processing
        NSString *apiURLStr =[NSString stringWithFormat:@"http://www.kpjmatrimony.com/api/forgot_password.php?email_id=%@",_forgetPassword.text];
        
        
        NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
        
        dict2=[sampleURL JSONValue];
        
        // Interaction with User Interface - Main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"dicr]t %@",dict2);
            NSString *response;
            [HUD hide:YES];
            response =[dict2 valueForKey:@"response"];
            
            if ([response isEqualToString:@"success"]) {
                
                [Common AlertShowWithErrorMsg:@"Password sent to your Email ID.. Please check your Email"];
            }
            else{
                [Common AlertShowWithErrorMsg:@"Please enter a Valid Email ID"];
            }
            
            
            
        });
    };
        
        
    }
  




-(void) onFailure:(NSDictionary *)dict{
    NSLog(@"%@",dict);
    //  [HUD hide:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
