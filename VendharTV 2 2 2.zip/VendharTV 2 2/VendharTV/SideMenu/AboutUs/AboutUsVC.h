//
//  AboutUsVC.h
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsVC : UIViewController

@end
