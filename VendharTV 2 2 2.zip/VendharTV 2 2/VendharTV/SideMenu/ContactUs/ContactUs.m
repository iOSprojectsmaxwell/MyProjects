//
//  ContactUs.m
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ContactUs.h"
#import "SidemenuVC.h"
#import <MapKit/MapKit.h>

@interface ContactUs ()
{
    IBOutlet MKMapView *mapview;
    
    SidemenuVC *objSideMenuView;
}


@end

@implementation ContactUs
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuVC *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuVC"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+25, 250, 700);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
     [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(13.0258989, 80.206786);
    
    MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
    MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setTitle:@"3r Main, Kalaimagal Nagar"];
    [annotation setSubtitle:@"Chennai,600032"];
    [annotation setCoordinate:coord];
    
    [mapview setRegion:region];
    [mapview addAnnotation:annotation];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
