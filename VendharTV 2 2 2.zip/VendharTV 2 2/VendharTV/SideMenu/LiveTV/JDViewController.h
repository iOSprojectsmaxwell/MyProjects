//
//  JDViewController.h
//  JDPlayerPro
//
//  Created by depa on 2017/3/23.
//  Copyright © 2017年 depa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDViewController : UIViewController
@property(nonatomic,strong)NSString *urlstr;
@end
