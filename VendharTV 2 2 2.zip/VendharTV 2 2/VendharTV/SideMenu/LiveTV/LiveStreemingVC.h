//
//  LiveStreemingVC.h
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LiveStreemingVC : UIViewController
@property(nonatomic,strong)IBOutlet UIView *viewww;
@property(nonatomic,strong)NSString *urlstr;
@end
