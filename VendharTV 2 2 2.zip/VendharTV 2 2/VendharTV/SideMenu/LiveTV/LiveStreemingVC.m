//
//  LiveStreemingVC.m
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "LiveStreemingVC.h"
#import <MediaPlayer/MediaPlayer.h>
#import "MBProgressHUD.h"
#import "Common.h"
@interface LiveStreemingVC ()<MBProgressHUDDelegate>
{
    NSTimer *t;
     MBProgressHUD *HUD;
}
@property (strong, nonatomic) MPMoviePlayerController *streamPlayer;

@end

@implementation LiveStreemingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(orientationChanged:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD show:YES];
   // @"http://45.79.203.234:1935/vendharm/myStream/playlist.m3u8"
    NSURL *streamURL = [NSURL URLWithString:_urlstr];
    NSLog(@"nslog %@",_urlstr);
    _streamPlayer = [[MPMoviePlayerController alloc] initWithContentURL:streamURL];
   
t = [NSTimer scheduledTimerWithTimeInterval: 2.0
                                                  target: self
                                                selector:@selector(onTick:)
                                                userInfo: nil repeats:NO];
    // depending on your implementation your view may not have it's bounds set here
    // in that case consider calling the following 4 msgs later
    [self.streamPlayer.view setFrame: self.view.bounds];
    self.streamPlayer.controlStyle = MPMovieControlStyleEmbedded;
    _streamPlayer.controlStyle = MPMovieControlStyleDefault;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(doneButtonClick:)
                                                 name:MPMoviePlayerWillExitFullscreenNotification
                                               object:nil];
    
    if ([self.streamPlayer respondsToSelector:@selector(loadState)]) {
        // Set movie player layout
        self.streamPlayer .controlStyle = MPMovieControlStyleEmbedded;
       // self.streamPlayer .scalingMode = MPMovieScalingModeAspectFill;
        self.streamPlayer .shouldAutoplay = YES;
       
        [self.streamPlayer prepareToPlay];
        [self.streamPlayer  setFullscreen:YES animated:YES];
        
        // Register that the load state changed (movie is ready)
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayerLoadStateChanged:)
                                                     name:MPMoviePlayerLoadStateDidChangeNotification
                                                   object:nil];
    } else {
        // Register to receive a notification when the movie is in memory and ready to play.
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePreloadDidFinish:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:nil];
    }
    
    
    
    _streamPlayer.shouldAutoplay = YES;

   
    [_streamPlayer setFullscreen:YES animated:YES];
  
    // Do any additional setup after loading the view.
}
- (BOOL)shouldAutorotate {
    return NO;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationLandscapeLeft; // or Right of course
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}
- (void)orientationChanged:(NSNotification *)notification
{
    // Get device orientation
    UIDeviceOrientation deviceOrientation   = [UIDevice currentDevice].orientation;
    
    if (UIDeviceOrientationIsPortrait(deviceOrientation))
    {
        UIDeviceOrientationIsLandscape(deviceOrientation);
    }
    else if(UIDeviceOrientationIsLandscape(deviceOrientation))
    {
        UIDeviceOrientationIsLandscape(deviceOrientation);
    }
}
-(void)doneButtonClick:(NSNotification*)aNotification{
    NSNumber *reason = [aNotification.userInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey];
    [self.navigationController popViewControllerAnimated:YES];
    if ([reason intValue] == MPMovieFinishReasonUserExited) {
       NSLog(@"Pressend Done...");
    }
}
- (void) moviePlayBackDidFinish:(NSNotification*)notification {
    NSLog(@"playback finished...");
    NSLog(@"End Playback Time: %f", _streamPlayer.endPlaybackTime);
    int reason = [[[notification userInfo] valueForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey] intValue];
    if (reason == MPMovieFinishReasonPlaybackEnded) {
        NSLog(@"Reason: movie finished playing");
    }else if (reason == MPMovieFinishReasonUserExited) {
        NSLog(@"Reason: user hit done button");
    }else if (reason == MPMovieFinishReasonPlaybackError) {
        NSLog(@"Reason: error");
        [HUD hide:YES];
        [Common AlertShowWithErrorMsg:@"Sorry! Unable to play this time"];
        
        [self.navigationController popViewControllerAnimated:YES];
    }
   
}

- (void) moviePlayerLoadStateChanged:(NSNotification*)notification {
    NSLog(@"moviePlayerLoadStateChanged");
    
     [HUD hide:YES];
    // Unless state is unknown, start playback
    if ([_streamPlayer loadState] != MPMovieLoadStateUnknown) {
        // Remove observer
        [[NSNotificationCenter defaultCenter]  removeObserver:self
                                                         name:MPMoviePlayerLoadStateDidChangeNotification
                                                       object:nil];
        
        [self.view addSubview: self.streamPlayer.view];
        
        [self.streamPlayer play];
        
        // Set frame of movie player
    
    }
}

-(void)onTick:(NSTimer *)timer {

}



- (void)handleMPMoviePlayerPlaybackDidFinish:(NSNotification *)notification
{
    NSDictionary *notificationUserInfo = [notification userInfo];
    NSNumber *resultValue = [notificationUserInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey];
    MPMovieFinishReason reason = [resultValue intValue];
    if (reason == MPMovieFinishReasonPlaybackError)
    {
        NSError *mediaPlayerError = [notificationUserInfo objectForKey:@"error"];
        if (mediaPlayerError)
        {
            
            NSLog(@"playback failed with error description: %@", [mediaPlayerError localizedDescription]);
        }
        else
        {
            NSLog(@"playback failed without any given reason");
        }
    }
      [HUD hide:YES];
}
-(IBAction)back_button:(id)sender

{
      [self.streamPlayer stop];
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
