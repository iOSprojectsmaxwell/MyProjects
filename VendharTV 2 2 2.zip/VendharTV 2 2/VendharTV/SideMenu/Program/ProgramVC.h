//
//  ProgramVC.h
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProgramVC : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tablviewww;
@property (weak, nonatomic) NSString *photo_id;
@property (weak, nonatomic) NSString *photo_Tittle;

@end
