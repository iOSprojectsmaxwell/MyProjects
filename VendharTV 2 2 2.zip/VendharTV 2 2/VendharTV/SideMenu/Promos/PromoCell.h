//
//  PromoCell.h
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"
#import "NSString+HTML.h"

@interface PromoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet MyImageView *imagevieww;
@property (weak, nonatomic) IBOutlet UILabel *Tiitle;
@end
