//
//  PromosVC.m
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "PromosVC.h"
#import "Common.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "WebManager.h"
#import "MyImageView.h"
#import "NSString+HTML.h"
#import "SidemenuVC.h"
#import "PromoCell.h"
#import "LiveStreemingVC.h"
#import "JDViewController.h"
@interface PromosVC ()
<MBProgressHUDDelegate,UITableViewDelegate,UITableViewDataSource>
{
    
    NSString *apiURLStr;
    NSString *result;
    NSArray *tittles;
    MBProgressHUD *HUD;
    NSDictionary *dict2;
    
    SidemenuVC *objSideMenuView;
    NSArray *promo;
     NSArray *title;
    NSArray *image;
    NSArray *url;

   
    
}
@property(nonatomic,strong)IBOutlet MyImageView *image1;
@end

@implementation PromosVC

- (void)viewDidLoad {
    [super viewDidLoad];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Loading...";
    [HUD hide:YES];
    [self CallingWebServices];
    
    // Do any additional setup after loading the view.
}
- (IBAction)Menu:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuVC *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuVC"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+25, 250, 700);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
     [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}


-(void)CallingWebServices

{
    
    NSString *data;
    NSString *urlstring;
    
    
    
    [HUD show:YES];
    //http://gnaritusglobal.com/clients/desikan/api/comments.php?name=Ramesh&phone=9677127700&email=rame sh@maxwellglobalsoftware.com&comment=testing
    
    //    ;
    //    dispatch_queue_t queue = dispatch_queue_create("data_process", 0);
    //
    //    // send a block to the queue - Not in Main thread
    //    dispatch_async(queue, ^{
    //        // data processing
    NSString *apiURLStr  =[NSString stringWithFormat:@"http://www.vendharmedia.in/Vendhar_App/api/promos.php"];
    NSString *sampleURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiURLStr] encoding:NSUTF8StringEncoding error:nil];
    
    dict2=[sampleURL JSONValue];
    // Interaction with User Interface - Main thread
    //        dispatch_async(dispatch_get_main_queue(), ^{
    promo =[dict2 valueForKey:@"promo"];
   title =[promo valueForKey:@"title"];
   image =[promo valueForKey:@"image"];
    url =[promo valueForKey:@"url"];
    [self.tablviewww reloadData];
    [HUD hide:YES];
    
    //
    //        });
    //    });
    
}




- (IBAction)aMethod:(id)sender
{
    
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"view will Appear");
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;    //count of section
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 250;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [title  count];    //count number of row from counting array hear cataGorry is An Array
}

-(IBAction)back_button:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.backgroundColor =[UIColor clearColor];
    static NSString *CellClassName = @"PromoCell";
    
    PromoCell  *cell = (PromoCell *)[tableView dequeueReusableCellWithIdentifier: CellClassName];
    
    if (cell == nil)
    {
        cell = [[PromoCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellClassName];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeCell"
                                                     owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
    _image1=(MyImageView*)[cell viewWithTag:1];
    NSString *path=[image objectAtIndex:indexPath.row];
    
    NSString *demo;
    demo = [path stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSLog(@"path %@",demo);
    
    [_image1 addImageFrom:[demo stringByURLDecode] isRound:YES isActivityIndicator:YES];
    
    cell.Tiitle.text =[title objectAtIndex:indexPath.row];
   
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger row = [indexPath row];
    
    NSString  *urlw =[url objectAtIndex:row];
     NSString  *titllee =[title objectAtIndex:row];
    
    JDViewController* jdVC = [[JDViewController alloc]init];
    jdVC.urlstr =urlw;
    [self.navigationController pushViewController:jdVC animated:YES];
    
    
   
    // NSString  *sr1 =[title objectAtIndex:row];
  
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
