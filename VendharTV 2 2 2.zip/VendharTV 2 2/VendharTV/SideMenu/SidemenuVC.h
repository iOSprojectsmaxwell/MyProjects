//
//  SidemenuVC.h
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import <UIKit/UIKit.h>
#define WIDTH_SIDEMENU  250
#define HEIGHT_SIDEMENU  700
@interface SidemenuVC : UIViewController

@end
