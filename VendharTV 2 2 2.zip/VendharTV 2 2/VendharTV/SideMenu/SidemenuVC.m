//
//  SidemenuVC.m
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "SidemenuVC.h"
#import "LiveStreemingVC.h"
#import "ViewController.h"
#import "AboutUsVC.h"
#import "ContactUs.h"
#import "PromosVC.h"
#import "ProgramVC.h"
#import "JDViewController.h"


@interface SidemenuVC ()
{
    SidemenuVC *objesidemenuView;
    
}

@end

@implementation SidemenuVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(IBAction)live_tv:(id)sender{
    
    JDViewController* jdVC = [[JDViewController alloc]init];
    jdVC.urlstr =@"http://45.79.203.234:1935/vendharm/myStream/playlist.m3u8";
    [self.navigationController pushViewController:jdVC animated:YES];
}

-(IBAction)home:(id)sender{
    
    ViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)Promo:(id)sender{
    
    PromosVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"PromosVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)Aboutus:(id)sender{
    
    AboutUsVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"AboutUsVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)contactus:(id)sender{
    
    ContactUs *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactUs"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

-(IBAction)Program_VC:(id)sender{
    
    ProgramVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProgramVC"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
-(IBAction)news:(id)sender{
    
    JDViewController* jdVC = [[JDViewController alloc]init];
    jdVC.urlstr =@"http://45.79.203.234:1935/vendharnews/myStream/playlist.m3u8";
    [self.navigationController pushViewController:jdVC animated:YES];
    

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
