//
//  ViewController.m
//  VendharTV
//
//  Created by user on 26/07/18.
//  Copyright © 2018 Maxwell. All rights reserved.
//

#import "ViewController.h"
#import "SidemenuVC.h"
#import "LiveStreemingVC.h"
#import "ProgramVC.h"
#import "JDViewController.h"



@interface ViewController ()
{
    
    
    SidemenuVC *objSideMenuView;
}


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _btnLiveVideo.enabled =YES;
    _viewws.layer.cornerRadius = 5;
    _viewws.layer.masksToBounds = true;
    [self. navigationController setNavigationBarHidden:YES];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)Menu:(id)sender {
      _btnLiveVideo.enabled =NO;
     _btnLiveVideo.hidden =YES;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    objSideMenuView = (SidemenuVC *)[storyboard instantiateViewControllerWithIdentifier:@"SidemenuVC"];
    objSideMenuView.view.frame = CGRectMake(0 , self.navigationController.navigationBar.frame.size.height+25, 250, 700);
    [self addChildViewController:objSideMenuView];
    
    [objSideMenuView didMoveToParentViewController:self];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 addTarget:self
                action:@selector(aMethod:)
      forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"X" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button1.frame = CGRectMake(211, -16, 55, 55);
    [objSideMenuView.view addSubview:button1];
    [self.view addSubview:objSideMenuView.view];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"view will Appear");
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
}
-(IBAction)LiveTv:(id)sender{

    JDViewController* jdVC = [[JDViewController alloc]init];
    jdVC.urlstr =@"http://45.79.203.234:1935/vendharm/myStream/playlist.m3u8";
    [self.navigationController pushViewController:jdVC animated:YES];
}


-(IBAction)LiveNews:(id)sender{
    
    JDViewController* jdVC = [[JDViewController alloc]init];
    jdVC.urlstr =@"http://45.79.203.234:1935/vendharnews/myStream/playlist.m3u8";
    [self.navigationController pushViewController:jdVC animated:YES];
}




-(IBAction)ProgramVC:(id)sender{
    
    ProgramVC *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ProgramVC"];
    [self.navigationController pushViewController:controller animated:YES];
}
- (IBAction)aMethod:(id)sender
{
    [objSideMenuView removeFromParentViewController];
    [objSideMenuView.view removeFromSuperview];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
